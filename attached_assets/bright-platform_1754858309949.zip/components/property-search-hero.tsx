"use client"

import { useState } from "react"
import { Search, MapPin, Filter, Home } from "lucide-react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent } from "@/components/ui/card"

export default function PropertySearchHero() {
  const [searchType, setSearchType] = useState("buy")

  return (
    <section className="relative min-h-[80vh] bg-gradient-to-br from-bright-black via-bright-black/95 to-bright-black/90 overflow-hidden">
      {/* Background Pattern - Fixed SVG URL syntax */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              'url(\'data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fillRule="evenodd"%3E%3Cg fill="%23FFE100" fillOpacity="0.1"%3E%3Ccircle cx="30" cy="30" r="2"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\')',
            backgroundRepeat: "repeat",
          }}
        ></div>
      </div>

      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center px-4 py-2 bg-bright-yellow/10 border border-bright-yellow/20 rounded-full mb-6"
          >
            <Home className="h-4 w-4 text-bright-yellow mr-2" />
            <span className="text-bright-yellow font-medium">Premium Real Estate Platform</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl md:text-6xl font-bold text-bright-white mb-6"
          >
            Buy, rent, or sell your{" "}
            <span className="text-bright-yellow relative">
              property
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </span>{" "}
            easily
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg text-bright-white/70 mb-8 max-w-2xl mx-auto"
          >
            A great platform to buy, sell, or even rent your properties with immersive virtual tours and cutting-edge
            technology.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex items-center justify-center gap-8 mb-8"
          >
            <div className="text-center">
              <div className="text-2xl font-bold text-bright-yellow">10k+</div>
              <div className="text-sm text-bright-white/60">properties</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-bright-yellow">5k+</div>
              <div className="text-sm text-bright-white/60">happy clients</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-bright-yellow">100+</div>
              <div className="text-sm text-bright-white/60">virtual tours</div>
            </div>
          </motion.div>
        </div>

        {/* Search Interface */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="max-w-4xl mx-auto"
        >
          <Card className="bg-bright-white/95 backdrop-blur-sm border-0 shadow-2xl">
            <CardContent className="p-6">
              {/* Search Type Tabs */}
              <div className="flex gap-2 mb-6">
                {["buy", "rent", "sell"].map((type) => (
                  <Button
                    key={type}
                    variant={searchType === type ? "default" : "ghost"}
                    className={`capitalize ${
                      searchType === type
                        ? "bg-bright-yellow text-bright-black hover:bg-bright-yellow/90"
                        : "text-gray-600 hover:text-bright-black hover:bg-gray-100"
                    }`}
                    onClick={() => setSearchType(type)}
                  >
                    {type}
                  </Button>
                ))}
              </div>

              {/* Search Form */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-2 relative">
                  <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <Input
                    placeholder="Search location (e.g., Kampala, Kololo, Bugolobi)"
                    className="pl-10 h-12 border-gray-200 focus:border-bright-yellow focus:ring-bright-yellow"
                  />
                </div>

                <Select>
                  <SelectTrigger className="h-12 border-gray-200 focus:border-bright-yellow focus:ring-bright-yellow">
                    <SelectValue placeholder="Property Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="apartment">Apartment</SelectItem>
                    <SelectItem value="house">House</SelectItem>
                    <SelectItem value="villa">Villa</SelectItem>
                    <SelectItem value="duplex">Duplex</SelectItem>
                    <SelectItem value="penthouse">Penthouse</SelectItem>
                  </SelectContent>
                </Select>

                <Select>
                  <SelectTrigger className="h-12 border-gray-200 focus:border-bright-yellow focus:ring-bright-yellow">
                    <SelectValue placeholder="Price Range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="50k-100k">$50k - $100k</SelectItem>
                    <SelectItem value="100k-200k">$100k - $200k</SelectItem>
                    <SelectItem value="200k-500k">$200k - $500k</SelectItem>
                    <SelectItem value="500k+">$500k+</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 mt-6">
                <Button className="flex-1 h-12 bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 font-medium">
                  <Search className="mr-2 h-5 w-5" />
                  Search Properties
                </Button>
                <Button variant="outline" className="h-12 border-gray-200 text-gray-600 hover:bg-gray-50">
                  <Filter className="mr-2 h-4 w-4" />
                  Advanced Filters
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  )
}
