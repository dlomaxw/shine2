"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Building2, Home, Waves, Eye, Star } from "lucide-react"

export default function Icon180Hero() {
  return (
    <section className="relative min-h-screen bg-bright-black overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/placeholder.svg?height=1080&width=1920"
          alt="Icon 180 - Modern Living with Breathtaking Lakeview"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-bright-black via-bright-black/80 to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 min-h-screen flex items-center">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            {/* Developer Badge */}
            <div className="inline-flex items-center px-4 py-2 bg-bright-yellow/10 border border-bright-yellow/20 rounded-full">
              <Star className="h-4 w-4 text-bright-yellow mr-2" />
              <span className="text-bright-yellow font-medium">Luxury Lakefront Living</span>
            </div>

            {/* Main Heading */}
            <div>
              <h1 className="text-4xl md:text-6xl font-bold text-bright-white mb-4">
                <span className="relative inline-block">
                  <span className="relative z-10">Icon</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </span>
                <br />
                <span className="text-bright-yellow">180</span>
              </h1>
              <h2 className="text-xl md:text-2xl text-bright-yellow/80 font-medium mb-2">Your Home in the Skyline</h2>
              <p className="text-lg text-bright-white/70 italic">"Modern living with breathtaking lakeview"</p>
            </div>

            {/* Key Features */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <div className="flex items-center">
                  <Home className="h-5 w-5 text-bright-yellow mr-2" />
                  <span className="text-bright-white font-medium">Unit Types</span>
                </div>
                <p className="text-bright-white/70">4-bedroom duplexes & 3-bedroom apartments</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center">
                  <Waves className="h-5 w-5 text-bright-yellow mr-2" />
                  <span className="text-bright-white font-medium">Views</span>
                </div>
                <p className="text-bright-white/70">Breathtaking lakeview panoramas</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center">
                  <Building2 className="h-5 w-5 text-bright-yellow mr-2" />
                  <span className="text-bright-white font-medium">Architecture</span>
                </div>
                <p className="text-bright-white/70">Contemporary skyline design</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center">
                  <Eye className="h-5 w-5 text-bright-yellow mr-2" />
                  <span className="text-bright-white font-medium">Lifestyle</span>
                </div>
                <p className="text-bright-white/70">Luxury lakefront living</p>
              </div>
            </div>

            {/* Description */}
            <div className="space-y-4">
              <p className="text-bright-white/80 text-lg leading-relaxed">
                Experience the pinnacle of modern living at Icon 180, where contemporary architecture meets the serene
                beauty of lakefront views. Choose from spacious{" "}
                <span className="text-bright-yellow font-medium">4-bedroom duplexes</span> or elegant{" "}
                <span className="text-bright-yellow font-medium">3-bedroom apartments</span>, each designed to maximize
                the stunning lake panoramas.
              </p>

              <div className="bg-bright-yellow/10 border border-bright-yellow/20 rounded-lg p-6">
                <h3 className="text-bright-yellow font-bold text-xl mb-2">Ready to live in the lap of luxury?</h3>
                <p className="text-bright-white/80">
                  Discover your perfect home where modern sophistication meets natural beauty, creating an unparalleled
                  living experience in the heart of the skyline.
                </p>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 font-medium">
                Schedule Viewing
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-bright-white text-bright-white hover:bg-bright-white/10"
              >
                Explore Floor Plans
              </Button>
            </div>
          </motion.div>

          {/* Right Content - Feature Highlights */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="hidden lg:block"
          >
            <div className="space-y-6">
              {/* Lakeview Feature */}
              <div className="bg-bright-black/60 backdrop-blur-sm border border-bright-yellow/20 rounded-lg p-6">
                <div className="flex items-center mb-3">
                  <Waves className="h-6 w-6 text-bright-yellow mr-3" />
                  <h3 className="text-bright-white font-bold text-lg">Breathtaking Lakeview</h3>
                </div>
                <p className="text-bright-white/70">
                  Wake up to stunning lake panoramas every morning. Floor-to-ceiling windows frame the natural beauty,
                  creating a serene living environment.
                </p>
              </div>

              {/* Duplex Feature */}
              <div className="bg-bright-black/60 backdrop-blur-sm border border-bright-yellow/20 rounded-lg p-6">
                <div className="flex items-center mb-3">
                  <Home className="h-6 w-6 text-bright-yellow mr-3" />
                  <h3 className="text-bright-white font-bold text-lg">Spacious Duplexes</h3>
                </div>
                <p className="text-bright-white/70">
                  4-bedroom duplexes offer expansive living spaces across two levels, perfect for families seeking
                  luxury and comfort.
                </p>
              </div>

              {/* Modern Living Feature */}
              <div className="bg-bright-black/60 backdrop-blur-sm border border-bright-yellow/20 rounded-lg p-6">
                <div className="flex items-center mb-3">
                  <Building2 className="h-6 w-6 text-bright-yellow mr-3" />
                  <h3 className="text-bright-white font-bold text-lg">Modern Architecture</h3>
                </div>
                <p className="text-bright-white/70">
                  Contemporary design elements and premium finishes create a sophisticated living environment that
                  defines modern luxury.
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Floating Info Cards */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 hidden md:flex space-x-4">
        <div className="bg-bright-black/80 backdrop-blur-sm border border-bright-yellow/20 rounded-lg px-4 py-2">
          <p className="text-bright-white/70 text-sm">Duplexes</p>
          <p className="text-bright-yellow font-medium">4 Bedrooms</p>
        </div>
        <div className="bg-bright-black/80 backdrop-blur-sm border border-bright-yellow/20 rounded-lg px-4 py-2">
          <p className="text-bright-white/70 text-sm">Apartments</p>
          <p className="text-bright-yellow font-medium">3 Bedrooms</p>
        </div>
        <div className="bg-bright-black/80 backdrop-blur-sm border border-bright-yellow/20 rounded-lg px-4 py-2">
          <p className="text-bright-white/70 text-sm">Views</p>
          <p className="text-bright-yellow font-medium">Lakeview</p>
        </div>
      </div>
    </section>
  )
}
