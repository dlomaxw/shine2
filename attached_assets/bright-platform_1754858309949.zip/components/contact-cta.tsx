import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function ContactCTA() {
  return (
    <section className="py-20 px-4 md:px-6 lg:px-8 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-r from-bright-black via-bright-black/95 to-bright-black z-0" />

      {/* Yellow accent shapes */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-bright-yellow rounded-full filter blur-3xl opacity-10 -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-bright-yellow rounded-full filter blur-3xl opacity-10 translate-x-1/2 translate-y-1/2" />

      <div className="container mx-auto relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-5xl font-bold mb-6 text-bright-yellow">Ready to Transform Your Business?</h2>
          <p className="text-xl text-bright-white/80 mb-10">
            Let's discuss how Bright's immersive technology solutions can help you achieve your business goals.
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Button size="lg" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 group">
              <Link href="/contact" className="flex items-center">
                Contact Us <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-bright-yellow text-bright-yellow hover:bg-bright-yellow hover:text-bright-black ml-4"
            >
              <Link href="/book-demo" className="flex items-center">
                Book a Demo <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-bright-yellow text-bright-yellow hover:bg-bright-yellow hover:text-bright-black"
            >
              <Link href="/portfolio">View Our Work</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
