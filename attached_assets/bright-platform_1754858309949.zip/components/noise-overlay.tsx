export default function NoiseOverlay() {
  return <div className="noise" aria-hidden="true" />
}
