"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { ChevronLeft, ChevronRight, Play, Pause, Volume2, VolumeX } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"

interface VideoCarouselProps {
  videos: {
    src: string
    alt: string
    title?: string
    description?: string
    owner?: string
  }[]
  autoplay?: boolean
  interval?: number
  className?: string
  fullWidth?: boolean
  height?: string
  showControls?: boolean
  showIndicators?: boolean
  overlay?: boolean
  showOwnerCard?: boolean
}

export default function VideoCarousel({
  videos,
  autoplay = true,
  interval = 5000,
  className,
  fullWidth = true,
  height = "h-screen",
  showControls = true,
  showIndicators = true,
  overlay = true,
  showOwnerCard = false,
}: VideoCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isHovering, setIsHovering] = useState(false)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const [isPlaying, setIsPlaying] = useState(true)
  const [isMuted, setIsMuted] = useState(true)
  const [isVideoLoaded, setIsVideoLoaded] = useState(false)
  const [hasError, setHasError] = useState(false)
  const timerRef = useRef<NodeJS.Timeout | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)

  const nextSlide = () => {
    if (isTransitioning) return
    setIsTransitioning(true)
    setIsVideoLoaded(false)
    setHasError(false)
    setCurrentIndex((prevIndex) => (prevIndex === videos.length - 1 ? 0 : prevIndex + 1))
    setTimeout(() => setIsTransitioning(false), 500)
  }

  const prevSlide = () => {
    if (isTransitioning) return
    setIsTransitioning(true)
    setIsVideoLoaded(false)
    setHasError(false)
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? videos.length - 1 : prevIndex - 1))
    setTimeout(() => setIsTransitioning(false), 500)
  }

  const goToSlide = (index: number) => {
    if (isTransitioning || index === currentIndex) return
    setIsTransitioning(true)
    setIsVideoLoaded(false)
    setHasError(false)
    setCurrentIndex(index)
    setTimeout(() => setIsTransitioning(false), 500)
  }

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause()
      } else {
        videoRef.current.play().catch(console.error)
      }
      setIsPlaying(!isPlaying)
    }
  }

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted
      setIsMuted(!isMuted)
    }
  }

  const handleVideoLoad = () => {
    setIsVideoLoaded(true)
    setHasError(false)
    if (videoRef.current && isPlaying) {
      videoRef.current.play().catch((error) => {
        console.error("Video play error:", error)
        setHasError(true)
      })
    }
  }

  const handleVideoError = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
    console.error("Video loading error:", e)
    setHasError(true)
    setIsVideoLoaded(true)
  }

  useEffect(() => {
    if (autoplay && !isHovering && isPlaying && !hasError) {
      timerRef.current = setInterval(nextSlide, interval)
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [autoplay, interval, isHovering, isPlaying, hasError])

  useEffect(() => {
    setIsVideoLoaded(false)
    setHasError(false)
  }, [currentIndex])

  if (!videos || videos.length === 0) {
    return (
      <div className={cn("flex items-center justify-center bg-gray-100", height, className)}>
        <p className="text-gray-500">No videos available</p>
      </div>
    )
  }

  return (
    <div
      className={cn("relative overflow-hidden group", fullWidth ? "w-full" : "w-auto", height, className)}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full h-full"
        >
          <div className="relative w-full h-full bg-bright-black">
            {!isVideoLoaded && !hasError && (
              <div className="absolute inset-0 bg-bright-black flex items-center justify-center z-20">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-bright-yellow mx-auto mb-4"></div>
                  <p className="text-bright-white/70">Loading video...</p>
                </div>
              </div>
            )}

            {hasError && (
              <div className="absolute inset-0 bg-bright-black flex items-center justify-center z-20">
                <div className="text-center">
                  <div className="w-16 h-16 bg-bright-yellow/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Play className="h-8 w-8 text-bright-yellow" />
                  </div>
                  <p className="text-bright-white mb-2">Video unavailable</p>
                  <p className="text-bright-white/70 text-sm">
                    {videos[currentIndex].title || videos[currentIndex].alt}
                  </p>
                </div>
              </div>
            )}

            <video
              ref={videoRef}
              className="object-cover w-full h-full"
              autoPlay={isPlaying}
              loop
              muted={isMuted}
              playsInline
              preload="metadata"
              onLoadedData={handleVideoLoad}
              onError={handleVideoError}
              onCanPlay={() => setIsVideoLoaded(true)}
              style={{ display: hasError ? "none" : "block" }}
            >
              <source src={videos[currentIndex].src} type="video/webm" />
              <source src={videos[currentIndex].src.replace(".webm", ".mp4")} type="video/mp4" />
              Your browser does not support the video tag.
            </video>

            {overlay && !hasError && (
              <div className="absolute inset-0 bg-gradient-to-t from-bright-black/80 via-bright-black/40 to-bright-black/30" />
            )}

            {/* Owner Card */}
            {showOwnerCard && videos[currentIndex] && !hasError && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="absolute bottom-4 left-4 right-4 sm:bottom-8 sm:left-8 sm:right-auto sm:max-w-md z-30"
              >
                <div className="bg-bright-black/80 backdrop-blur-sm border border-bright-yellow/30 rounded-lg p-4 sm:p-6">
                  <h3 className="text-lg sm:text-xl font-bold text-bright-yellow mb-2">
                    {videos[currentIndex].title || videos[currentIndex].alt}
                  </h3>
                  {videos[currentIndex].description && (
                    <p className="text-sm sm:text-base text-bright-white/90 mb-3">{videos[currentIndex].description}</p>
                  )}
                  {videos[currentIndex].owner && (
                    <div className="flex items-center text-xs sm:text-sm text-bright-white/70">
                      <span className="mr-2">Project by:</span>
                      <span className="text-bright-yellow font-medium">{videos[currentIndex].owner}</span>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Video Controls */}
      <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-30">
        <Button
          variant="ghost"
          size="icon"
          className="bg-bright-black/50 backdrop-blur-sm text-bright-white hover:bg-bright-black/70 h-10 w-10 rounded-full"
          onClick={togglePlayPause}
        >
          {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
          <span className="sr-only">{isPlaying ? "Pause" : "Play"}</span>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="bg-bright-black/50 backdrop-blur-sm text-bright-white hover:bg-bright-black/70 h-10 w-10 rounded-full"
          onClick={toggleMute}
        >
          {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
          <span className="sr-only">{isMuted ? "Unmute" : "Mute"}</span>
        </Button>
      </div>

      {/* Navigation Arrows */}
      {showControls && videos.length > 1 && (
        <>
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 bg-bright-yellow/20 backdrop-blur-sm text-bright-black hover:bg-bright-yellow/40 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 sm:h-10 sm:w-10 rounded-full z-30"
            onClick={prevSlide}
            disabled={isTransitioning}
          >
            <ChevronLeft className="h-4 w-4 sm:h-6 sm:w-6" />
            <span className="sr-only">Previous slide</span>
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 bg-bright-yellow/20 backdrop-blur-sm text-bright-black hover:bg-bright-yellow/40 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 sm:h-10 sm:w-10 rounded-full z-30"
            onClick={nextSlide}
            disabled={isTransitioning}
          >
            <ChevronRight className="h-4 w-4 sm:h-6 sm:w-6" />
            <span className="sr-only">Next slide</span>
          </Button>
        </>
      )}

      {/* Indicators */}
      {showIndicators && videos.length > 1 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-1 sm:space-x-2 z-30">
          {videos.map((_, index) => (
            <button
              key={index}
              className={`w-1.5 h-1.5 sm:w-2.5 sm:h-2.5 rounded-full transition-all ${
                index === currentIndex ? "bg-bright-yellow w-4 sm:w-8" : "bg-bright-white/50 hover:bg-bright-white"
              }`}
              onClick={() => goToSlide(index)}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  )
}
