"use client"

import { useState } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight, Quote } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function TestimonialSection() {
  const testimonials = [
    {
      quote:
        "Bright transformed our property showings with their VR tours. We've seen a 40% increase in qualified leads since implementation.",
      author: "Sarah Johnson",
      role: "Marketing Director, Luxury Homes",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "The training simulations developed by Bright have reduced our onboarding time by 30% while improving knowledge retention.",
      author: "Michael Chen",
      role: "Head of L&D, Enterprise Corp",
      image: "/placeholder.svg?height=100&width=100",
    },
    {
      quote:
        "Our interactive media campaign created with Bright's team exceeded engagement targets by 250%. The results speak for themselves.",
      author: "Priya Patel",
      role: "Creative Director, Media Innovations",
      image: "/placeholder.svg?height=100&width=100",
    },
  ]

  const [activeIndex, setActiveIndex] = useState(0)

  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev === testimonials.length - 1 ? 0 : prev + 1))
  }

  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev === 0 ? testimonials.length - 1 : prev - 1))
  }

  return (
    <section className="py-20 px-4 md:px-6 lg:px-8 bg-bright-black relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="animated-bg" />
      </div>

      <div className="container mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 text-bright-yellow">What Our Clients Say</h2>
          <p className="text-lg text-bright-white/70 max-w-3xl mx-auto">
            We've helped businesses across industries transform their operations and customer experiences.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-none shadow-lg bg-bright-black/50 backdrop-blur-sm border border-bright-yellow/10">
            <CardContent className="p-8 md:p-12">
              <Quote className="h-16 w-16 text-bright-yellow/20 mb-6" />
              <p className="mb-8 text-xl md:text-2xl text-bright-white leading-relaxed">
                {testimonials[activeIndex].quote}
              </p>
              <div className="flex items-center">
                <div className="mr-4 rounded-full overflow-hidden w-16 h-16 relative border-2 border-bright-yellow">
                  <Image
                    src={testimonials[activeIndex].image || "/placeholder.svg"}
                    alt={testimonials[activeIndex].author}
                    fill
                    className="object-cover"
                  />
                </div>
                <div>
                  <p className="font-semibold text-bright-yellow">{testimonials[activeIndex].author}</p>
                  <p className="text-sm text-bright-white/70">{testimonials[activeIndex].role}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center mt-8 space-x-2">
            <Button
              variant="outline"
              size="icon"
              onClick={prevTestimonial}
              className="rounded-full border-bright-yellow/30 text-bright-yellow hover:bg-bright-yellow hover:text-bright-black"
            >
              <ChevronLeft className="h-5 w-5" />
              <span className="sr-only">Previous testimonial</span>
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={nextTestimonial}
              className="rounded-full border-bright-yellow/30 text-bright-yellow hover:bg-bright-yellow hover:text-bright-black"
            >
              <ChevronRight className="h-5 w-5" />
              <span className="sr-only">Next testimonial</span>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
