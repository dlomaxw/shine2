"use client"
import { CheckCircle2, Circle, Clock, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

// Simplified categories for progress tracking
const categories = [
  {
    name: "Core Structure",
    tasks: [
      { name: "Project Setup", status: "completed" },
      { name: "Layout & Navigation", status: "completed" },
      { name: "Theming & Styling", status: "completed" },
    ],
  },
  {
    name: "Pages",
    tasks: [
      { name: "Homepage", status: "completed" },
      { name: "About Page", status: "completed" },
      { name: "Contact Page", status: "completed" },
      { name: "Portfolio Page", status: "completed" },
      { name: "Real Estate Page", status: "completed" },
      { name: "Media Page", status: "completed" },
      { name: "Training Page", status: "completed" },
      { name: "Corporate Page", status: "completed" },
      { name: "Digital Page", status: "completed" },
      { name: "Custom Solutions Page", status: "completed" },
      { name: "Blog Page", status: "completed" },
      { name: "Careers Page", status: "completed" },
      { name: "Login Page", status: "completed" },
      { name: "Architecture Page", status: "completed" },
      { name: "Interior Design Page", status: "completed" },
      { name: "Admin Dashboard", status: "completed" },
      { name: "Content Editor", status: "completed" },
      { name: "Media Manager", status: "completed" },
      { name: "Admin Blog Manager", status: "completed" },
      { name: "Admin Services Manager", status: "completed" },
      { name: "Admin Typography Settings", status: "completed" },
      { name: "Admin Components Settings", status: "completed" },
      { name: "Book Demo Page", status: "completed" },
    ],
  },
  {
    name: "Components",
    tasks: [
      { name: "Hero Section", status: "completed" },
      { name: "Footer", status: "completed" },
      { name: "Contact Form", status: "completed" },
      { name: "Image Carousel", status: "completed" },
      { name: "Standalone Carousel", status: "completed" },
      { name: "3D Building Viewer", status: "completed" },
      { name: "Testimonial Section", status: "completed" },
      { name: "Feature Section", status: "completed" },
      { name: "Industry Cards", status: "completed" },
      { name: "Contact CTA", status: "completed" },
      { name: "Project Gallery", status: "completed" },
      { name: "3D Showcase Section", status: "completed" },
      { name: "Animated Text", status: "completed" },
      { name: "Marquee", status: "completed" },
      { name: "Custom Cursor", status: "completed" },
      { name: "AI Chatbot", status: "completed" },
      { name: "Animated Cards", status: "completed" },
      { name: "Futuristic Cards", status: "completed" },
      { name: "Futuristic Navbar", status: "completed" },
      { name: "Admin Layout", status: "completed" },
      { name: "Admin Dashboard Widgets", status: "completed" },
      { name: "Media Upload Component", status: "completed" },
    ],
  },
  {
    name: "Features",
    tasks: [
      { name: "Responsive Design", status: "completed" },
      { name: "Dark Mode", status: "completed" },
      { name: "Form Validation", status: "completed" },
      { name: "API Integration", status: "completed" },
      { name: "Animation Effects", status: "completed" },
      { name: "3D Interaction", status: "completed" },
      { name: "Content Management", status: "completed" },
      { name: "Media Management", status: "completed" },
      { name: "User Authentication", status: "completed" },
      { name: "Admin Login Redirect", status: "completed" },
      { name: "Media Upload Functionality", status: "completed" },
    ],
  },
  {
    name: "Assets",
    tasks: [
      { name: "Original Images", status: "completed" },
      { name: "New Architecture Images", status: "completed" },
      { name: "Interior Design Images", status: "completed" },
      { name: "Residential Building Images", status: "completed" },
      { name: "Commercial Building Images", status: "completed" },
      { name: "Resort & Hotel Images", status: "completed" },
    ],
  },
  {
    name: "Optimization",
    tasks: [
      { name: "Image Optimization", status: "completed" },
      { name: "Code Splitting", status: "completed" },
      { name: "Performance Audit", status: "in-progress" },
      { name: "Accessibility", status: "in-progress" },
      { name: "SEO Optimization", status: "in-progress" },
      { name: "Error Page Handling", status: "completed" },
    ],
  },
  {
    name: "Future Enhancements",
    tasks: [
      { name: "Advanced Analytics", status: "pending" },
      { name: "Multilingual Support", status: "pending" },
      { name: "Payment Integration", status: "pending" },
      { name: "Advanced 3D Model Editor", status: "pending" },
    ],
  },
]

// Calculate overall progress
const allTasks = categories.flatMap((category) => category.tasks)
const completedTasks = allTasks.filter((task) => task.status === "completed").length
const totalTasks = allTasks.length
const progressPercentage = Math.round((completedTasks / totalTasks) * 100)

// Helper function to render status icon
const getStatusIcon = (status: string) => {
  switch (status) {
    case "completed":
      return <CheckCircle2 className="h-4 w-4 text-green-500" />
    case "in-progress":
      return <Clock className="h-4 w-4 text-blue-500" />
    case "blocked":
      return <AlertCircle className="h-4 w-4 text-red-500" />
    default:
      return <Circle className="h-4 w-4 text-gray-300" />
  }
}

export default function ProjectProgressTracker() {
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-6">Bright Platform - Project Progress</h1>

      {/* Overall Progress */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium">Overall Progress</span>
          <span className="text-sm font-medium">
            {completedTasks} of {totalTasks} tasks ({progressPercentage}%)
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div className="bg-green-600 h-2.5 rounded-full" style={{ width: `${progressPercentage}%` }}></div>
        </div>
      </div>

      {/* Categories */}
      <div className="space-y-8">
        {categories.map((category, index) => {
          const categoryCompleted = category.tasks.filter((task) => task.status === "completed").length
          const categoryTotal = category.tasks.length
          const categoryPercentage = Math.round((categoryCompleted / categoryTotal) * 100)

          return (
            <div key={index} className="border rounded-lg p-4">
              <h2 className="text-lg font-semibold mb-2">{category.name}</h2>

              {/* Category Progress */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-gray-500">
                    {categoryCompleted} of {categoryTotal} tasks
                  </span>
                  <span className="text-xs font-medium">{categoryPercentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5">
                  <div
                    className={cn("h-1.5 rounded-full", categoryPercentage === 100 ? "bg-green-600" : "bg-blue-600")}
                    style={{ width: `${categoryPercentage}%` }}
                  ></div>
                </div>
              </div>

              {/* Tasks */}
              <ul className="space-y-1">
                {category.tasks.map((task, taskIndex) => (
                  <li key={taskIndex} className="flex items-center gap-2 text-sm">
                    {getStatusIcon(task.status)}
                    <span className={task.status === "completed" ? "line-through text-gray-500" : ""}>{task.name}</span>
                    {task.status === "in-progress" && (
                      <span className="text-xs bg-blue-100 text-blue-800 px-2 py-0.5 rounded">In Progress</span>
                    )}
                    {task.status === "pending" && (
                      <span className="text-xs bg-gray-100 text-gray-800 px-2 py-0.5 rounded">Pending</span>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )
        })}
      </div>
    </div>
  )
}
