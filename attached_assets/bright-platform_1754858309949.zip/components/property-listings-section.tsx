"use client"

import { useState } from "react"
import { Grid, List, SlidersHorizontal, ArrowUpDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import ModernPropertyCard from "@/components/modern-property-card"

export default function PropertyListingsSection() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [sortBy, setSortBy] = useState("newest")

  const properties = [
    {
      id: "horizon-residency",
      title: "The Horizon Residency",
      location: "Luthuli Avenue, Bugolobi",
      price: "$78,000",
      priceType: "total" as const,
      image: "/images/horizon-residency-front.jpeg",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/horizon%20residencyV1-pX4FFwA4bPYXhHK937BJ1oajcitg5A.webm",
      bedrooms: 2,
      bathrooms: 2,
      area: 1200,
      isPopular: true,
      rating: 4.8,
      views: 1250,
    },
    {
      id: "skyrise-apartments",
      title: "Skyrise Apartments",
      location: "Kololo, Kampala",
      price: "$2,700",
      priceType: "month" as const,
      image: "/images/skyrise-aerial-view.jpeg",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/skyriseinsta-ou61xLfPnC9SGnbyqMj0Y5H0vakI8b.webm",
      bedrooms: 3,
      bathrooms: 2,
      area: 1500,
      isFeatured: true,
      rating: 4.9,
      views: 980,
    },
    {
      id: "topaz-court",
      title: "Topaz Court",
      location: "Premium Location",
      price: "$145,000",
      priceType: "total" as const,
      image: "/images/topaz-court-exterior.png",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/topaz%20court-IarahXii0RQiQnxicNfBPprqR1bM6w.webm",
      bedrooms: 3,
      bathrooms: 3,
      area: 1800,
      rating: 4.7,
      views: 756,
    },
    {
      id: "sepal-garden",
      title: "Sepal Garden",
      location: "Garden District",
      price: "$1,600",
      priceType: "month" as const,
      image: "/images/sepal-garden-exterior.png",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/SEPAL%20GARDEN-Jv919x59xk5JOoiioE6rACqtfDf0Mi.webm",
      bedrooms: 2,
      bathrooms: 2,
      area: 1100,
      rating: 4.6,
      views: 642,
    },
    {
      id: "gates-spring",
      title: "Gates Spring",
      location: "Spring Valley",
      price: "$95,000",
      priceType: "total" as const,
      image: "/images/gates-spring-exterior.png",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/gates%20spring%201-6QMh83Ksu3HDdVNpJaIp7banpIRJ6u.webm",
      bedrooms: 2,
      bathrooms: 2,
      area: 1000,
      rating: 4.5,
      views: 523,
    },
    {
      id: "sky-resident",
      title: "Sky Resident",
      location: "City Center",
      price: "$3,200",
      priceType: "month" as const,
      image: "/images/sky-resident-exterior.png",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/sky%20resident%20pre-glYYw1X6QY4LTVLPzsYjEIsVJR4UvI.webm",
      bedrooms: 4,
      bathrooms: 3,
      area: 2200,
      isPopular: true,
      rating: 4.8,
      views: 1100,
    },
  ]

  return (
    <section className="py-20 px-4 md:px-6 lg:px-8 bg-gray-50">
      <div className="container mx-auto">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Featured Properties</h2>
            <p className="text-gray-600">Discover your perfect home from our curated selection</p>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-4 mt-4 md:mt-0">
            <div className="flex items-center gap-2">
              <Button
                variant={viewMode === "grid" ? "default" : "outline"}
                size="icon"
                className={viewMode === "grid" ? "bg-bright-yellow text-bright-black" : ""}
                onClick={() => setViewMode("grid")}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "outline"}
                size="icon"
                className={viewMode === "list" ? "bg-bright-yellow text-bright-black" : ""}
                onClick={() => setViewMode("list")}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <ArrowUpDown className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline" className="border-gray-200">
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Filters
            </Button>
          </div>
        </div>

        {/* Property Grid */}
        <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" : "space-y-6"}>
          {properties.map((property, index) => (
            <ModernPropertyCard key={property.id} {...property} className={viewMode === "list" ? "max-w-none" : ""} />
          ))}
        </div>

        {/* Load More */}
        <div className="text-center mt-12">
          <Button
            variant="outline"
            className="border-bright-yellow text-bright-yellow hover:bg-bright-yellow hover:text-bright-black"
          >
            Load More Properties
          </Button>
        </div>
      </div>
    </section>
  )
}
