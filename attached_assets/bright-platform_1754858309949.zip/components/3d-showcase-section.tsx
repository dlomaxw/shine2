"use client"

import { useState } from "react"
import ThreeDModelViewer from "@/components/3d-building-viewer"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Building, Building2, Home, Landmark } from "lucide-react"

export default function ThreeDShowcaseSection() {
  const [activeModel, setActiveModel] = useState("modern")

  return (
    <section className="py-12 sm:py-16 md:py-20 px-4 md:px-6 lg:px-8 bg-bright-black">
      <div className="container mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 text-bright-yellow">Interactive 3D Experiences</h2>
          <p className="text-lg text-bright-white/70 max-w-3xl mx-auto">
            Explore our architectural designs and construction projects in immersive 3D. Rotate, zoom, and interact with
            our models.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 sm:gap-6 lg:gap-8">
          <div className="lg:col-span-1">
            <Tabs
              defaultValue="modern"
              orientation="vertical"
              value={activeModel}
              onValueChange={setActiveModel}
              className="w-full"
            >
              <TabsList className="flex flex-row lg:flex-col h-auto lg:h-auto w-full justify-between lg:justify-start bg-transparent space-y-0 lg:space-y-2">
                <TabsTrigger
                  value="modern"
                  className="w-full data-[state=active]:bg-bright-yellow data-[state=active]:text-bright-black text-xs sm:text-sm"
                >
                  <div className="flex items-center">
                    <Building2 className="h-4 w-4 sm:h-5 sm:w-5 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Modern Office</span>
                  </div>
                </TabsTrigger>
                <TabsTrigger
                  value="residential"
                  className="w-full data-[state=active]:bg-bright-yellow data-[state=active]:text-bright-black text-xs sm:text-sm"
                >
                  <div className="flex items-center">
                    <Home className="h-4 w-4 sm:h-5 sm:w-5 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Residential</span>
                  </div>
                </TabsTrigger>
                <TabsTrigger
                  value="commercial"
                  className="w-full data-[state=active]:bg-bright-yellow data-[state=active]:text-bright-black text-xs sm:text-sm"
                >
                  <div className="flex items-center">
                    <Building className="h-4 w-4 sm:h-5 sm:w-5 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Commercial</span>
                  </div>
                </TabsTrigger>
                <TabsTrigger
                  value="historical"
                  className="w-full data-[state=active]:bg-bright-yellow data-[state=active]:text-bright-black text-xs sm:text-sm"
                >
                  <div className="flex items-center">
                    <Landmark className="h-4 w-4 sm:h-5 sm:w-5 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Historical</span>
                  </div>
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <div className="mt-6 space-y-4 hidden lg:block">
              <h3 className="text-xl font-semibold text-bright-white">Model Details</h3>
              {activeModel === "modern" && (
                <div className="space-y-2">
                  <p className="text-bright-white/70">
                    Modern office building with glass facade and sustainable design features.
                  </p>
                  <ul className="list-disc list-inside text-bright-white/70">
                    <li>12 floors</li>
                    <li>Solar panels</li>
                    <li>Green roof</li>
                    <li>Smart building systems</li>
                  </ul>
                </div>
              )}
              {activeModel === "residential" && (
                <div className="space-y-2">
                  <p className="text-bright-white/70">
                    Luxury residential complex with modern amenities and spacious layouts.
                  </p>
                  <ul className="list-disc list-inside text-bright-white/70">
                    <li>24 units</li>
                    <li>Swimming pool</li>
                    <li>Fitness center</li>
                    <li>Rooftop garden</li>
                  </ul>
                </div>
              )}
              {activeModel === "commercial" && (
                <div className="space-y-2">
                  <p className="text-bright-white/70">
                    Mixed-use commercial development with retail, office, and entertainment spaces.
                  </p>
                  <ul className="list-disc list-inside text-bright-white/70">
                    <li>Retail ground floor</li>
                    <li>Office spaces</li>
                    <li>Food court</li>
                    <li>Underground parking</li>
                  </ul>
                </div>
              )}
              {activeModel === "historical" && (
                <div className="space-y-2">
                  <p className="text-bright-white/70">
                    Restoration project of a historical building with modern interior updates.
                  </p>
                  <ul className="list-disc list-inside text-bright-white/70">
                    <li>Original facade</li>
                    <li>Modern interior</li>
                    <li>Museum space</li>
                    <li>Cultural center</li>
                  </ul>
                </div>
              )}

              <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                View Project Details
              </Button>
            </div>
          </div>

          <div className="lg:col-span-4 rounded-lg overflow-hidden border border-bright-yellow/20">
            <ThreeDModelViewer modelType={activeModel} />
          </div>

          <div className="lg:hidden mt-4 space-y-4">
            <h3 className="text-xl font-semibold text-bright-white">Model Details</h3>
            {activeModel === "modern" && (
              <div className="space-y-2">
                <p className="text-bright-white/70">
                  Modern office building with glass facade and sustainable design features.
                </p>
                <ul className="list-disc list-inside text-bright-white/70">
                  <li>12 floors</li>
                  <li>Solar panels</li>
                  <li>Green roof</li>
                  <li>Smart building systems</li>
                </ul>
              </div>
            )}
            {activeModel === "residential" && (
              <div className="space-y-2">
                <p className="text-bright-white/70">
                  Luxury residential complex with modern amenities and spacious layouts.
                </p>
                <ul className="list-disc list-inside text-bright-white/70">
                  <li>24 units</li>
                  <li>Swimming pool</li>
                  <li>Fitness center</li>
                  <li>Rooftop garden</li>
                </ul>
              </div>
            )}
            {activeModel === "commercial" && (
              <div className="space-y-2">
                <p className="text-bright-white/70">
                  Mixed-use commercial development with retail, office, and entertainment spaces.
                </p>
                <ul className="list-disc list-inside text-bright-white/70">
                  <li>Retail ground floor</li>
                  <li>Office spaces</li>
                  <li>Food court</li>
                  <li>Underground parking</li>
                </ul>
              </div>
            )}
            {activeModel === "historical" && (
              <div className="space-y-2">
                <p className="text-bright-white/70">
                  Restoration project of a historical building with modern interior updates.
                </p>
                <ul className="list-disc list-inside text-bright-white/70">
                  <li>Original facade</li>
                  <li>Modern interior</li>
                  <li>Museum space</li>
                  <li>Cultural center</li>
                </ul>
              </div>
            )}

            <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
              View Project Details
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
