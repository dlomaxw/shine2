"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Heart, MapPin, Bed, Bath, Square, Eye, Calendar, Star, Scale } from "lucide-react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import VideoPlayer from "@/components/video-player"
import { useComparison } from "@/contexts/comparison-context"

interface PropertyCardProps {
  id: string
  title: string
  location: string
  price: string
  priceType: "month" | "total"
  image: string
  video?: string
  bedrooms: number
  bathrooms: number
  area: number
  isPopular?: boolean
  isFeatured?: boolean
  rating?: number
  views?: number
  className?: string
}

export default function ModernPropertyCard({
  id,
  title,
  location,
  price,
  priceType,
  image,
  video,
  bedrooms,
  bathrooms,
  area,
  isPopular = false,
  isFeatured = false,
  rating,
  views,
  className = "",
}: PropertyCardProps) {
  const [isLiked, setIsLiked] = useState(false)
  const [showVideo, setShowVideo] = useState(false)

  const { addToComparison, removeFromComparison, isInComparison, comparedProperties, maxComparisons } = useComparison()
  const inComparison = isInComparison(id)
  const canAddToComparison = comparedProperties.length < maxComparisons

  const handleCompareToggle = () => {
    const propertyData = {
      id,
      title,
      location,
      price,
      priceType,
      image,
      video,
      bedrooms,
      bathrooms,
      area,
      rating,
      // Add default values for comparison features
      yearBuilt: 2023,
      parkingSpaces: 1,
      floorNumber: 2,
      totalFloors: 10,
      furnished: true,
      petFriendly: false,
      balcony: true,
      gym: true,
      pool: true,
      security: true,
      elevator: true,
      airConditioning: true,
    }

    if (inComparison) {
      removeFromComparison(id)
    } else if (canAddToComparison) {
      addToComparison(propertyData)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className={className}
    >
      <Card className="group overflow-hidden bg-white border border-gray-200 hover:border-bright-yellow/50 hover:shadow-xl transition-all duration-300">
        <div className="relative h-64 overflow-hidden">
          {showVideo && video ? (
            <VideoPlayer src={video} className="h-full" poster={image} onEnded={() => setShowVideo(false)} />
          ) : (
            <Image
              src={image || "/placeholder.svg"}
              alt={title}
              fill
              className="object-cover group-hover:scale-105 transition-transform duration-300"
            />
          )}

          {/* Overlay Badges */}
          <div className="absolute top-4 left-4 flex gap-2">
            {isPopular && <Badge className="bg-bright-yellow text-bright-black font-medium">POPULAR</Badge>}
            {isFeatured && <Badge className="bg-green-500 text-white font-medium">FEATURED</Badge>}
          </div>

          {/* Action Buttons */}
          <div className="absolute top-4 right-4 flex flex-col gap-2">
            <Button
              size="icon"
              variant="secondary"
              className={`h-8 w-8 rounded-full bg-white/90 hover:bg-white ${
                isLiked ? "text-red-500" : "text-gray-600"
              }`}
              onClick={() => setIsLiked(!isLiked)}
            >
              <Heart className={`h-4 w-4 ${isLiked ? "fill-current" : ""}`} />
            </Button>
            {video && (
              <Button
                size="icon"
                variant="secondary"
                className="h-8 w-8 rounded-full bg-white/90 hover:bg-white text-gray-600"
                onClick={() => setShowVideo(!showVideo)}
              >
                <Eye className="h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Price Badge */}
          <div className="absolute bottom-4 left-4">
            <div className="bg-bright-black/80 backdrop-blur-sm text-white px-3 py-1 rounded-full">
              <span className="text-lg font-bold text-bright-yellow">{price}</span>
              <span className="text-sm">/{priceType}</span>
            </div>
          </div>
        </div>

        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-2">
            <h3 className="text-xl font-bold text-gray-900 group-hover:text-bright-yellow transition-colors">
              {title}
            </h3>
            {rating && (
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span className="text-sm font-medium text-gray-600">{rating}</span>
              </div>
            )}
          </div>

          <div className="flex items-center text-gray-600 mb-4">
            <MapPin className="h-4 w-4 mr-1" />
            <span className="text-sm">{location}</span>
          </div>

          {/* Property Details */}
          <div className="flex items-center justify-between mb-4 text-sm text-gray-600">
            <div className="flex items-center gap-4">
              <div className="flex items-center">
                <Bed className="h-4 w-4 mr-1" />
                <span>{bedrooms}</span>
              </div>
              <div className="flex items-center">
                <Bath className="h-4 w-4 mr-1" />
                <span>{bathrooms}</span>
              </div>
              <div className="flex items-center">
                <Square className="h-4 w-4 mr-1" />
                <span>{area} sqft</span>
              </div>
            </div>
            {views && (
              <div className="flex items-center text-xs text-gray-500">
                <Eye className="h-3 w-3 mr-1" />
                <span>{views} views</span>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Link href={`/real-estate/${id}`} className="flex-1">
              <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 font-medium">
                View Details
              </Button>
            </Link>
            <Button
              variant={inComparison ? "default" : "outline"}
              className={`${inComparison ? "bg-bright-yellow text-bright-black" : "border-gray-200 text-gray-600 hover:bg-gray-50"} ${!canAddToComparison && !inComparison ? "opacity-50 cursor-not-allowed" : ""}`}
              onClick={handleCompareToggle}
              disabled={!canAddToComparison && !inComparison}
            >
              <Scale className="h-4 w-4" />
            </Button>
            <Button variant="outline" className="border-gray-200 text-gray-600 hover:bg-gray-50">
              <Calendar className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
