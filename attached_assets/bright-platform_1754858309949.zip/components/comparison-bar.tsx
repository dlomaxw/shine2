"use client"

import { useState } from "react"
import Image from "next/image"
import { X, ArrowRight, Scale } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useComparison } from "@/contexts/comparison-context"
import PropertyComparisonModal from "@/components/property-comparison-modal"

export default function ComparisonBar() {
  const { comparedProperties, removeFromComparison, clearComparison } = useComparison()
  const [showComparison, setShowComparison] = useState(false)

  if (comparedProperties.length === 0) return null

  return (
    <>
      <AnimatePresence>
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          className="fixed bottom-4 left-4 right-4 z-50"
        >
          <Card className="bg-white border border-gray-200 shadow-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <Scale className="h-5 w-5 text-bright-yellow" />
                  <span className="font-medium text-gray-900">Compare Properties ({comparedProperties.length}/4)</span>
                </div>

                <div className="flex gap-2">
                  {comparedProperties.map((property) => (
                    <div key={property.id} className="relative group">
                      <div className="w-12 h-12 rounded-lg overflow-hidden border-2 border-bright-yellow/20">
                        <Image
                          src={property.image || "/placeholder.svg"}
                          alt={property.title}
                          width={48}
                          height={48}
                          className="object-cover w-full h-full"
                        />
                      </div>
                      <button
                        onClick={() => removeFromComparison(property.id)}
                        className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="h-2 w-2" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={clearComparison} className="text-gray-600 border-gray-200">
                  Clear All
                </Button>
                <Button
                  size="sm"
                  onClick={() => setShowComparison(true)}
                  className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90"
                  disabled={comparedProperties.length < 2}
                >
                  Compare Now
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>
      </AnimatePresence>

      <PropertyComparisonModal
        isOpen={showComparison}
        onClose={() => setShowComparison(false)}
        properties={comparedProperties}
      />
    </>
  )
}
