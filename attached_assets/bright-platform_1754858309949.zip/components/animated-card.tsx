"use client"

import type React from "react"

import { useState, useRef } from "react"
import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"

interface AnimatedCardProps {
  title: string
  description: string
  image: string
  category?: string
  href: string
  className?: string
}

export default function AnimatedCard({ title, description, image, category, href, className }: AnimatedCardProps) {
  const [isHovered, setIsHovered] = useState(false)
  const cardRef = useRef<HTMLDivElement>(null)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return

    const rect = cardRef.current.getBoundingClientRect()
    const x = (e.clientX - rect.left) / rect.width - 0.5
    const y = (e.clientY - rect.top) / rect.height - 0.5

    setMousePosition({ x, y })
  }

  return (
    <Link href={href}>
      <motion.div
        ref={cardRef}
        className={cn(
          "group relative overflow-hidden rounded-xl bg-bright-black border border-bright-yellow/10 shadow-md transition-all duration-300 hover:shadow-xl hover:shadow-bright-yellow/10 hover:border-bright-yellow/30",
          className,
        )}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onMouseMove={handleMouseMove}
        animate={{
          transform: isHovered
            ? `perspective(1000px) rotateX(${mousePosition.y * 10}deg) rotateY(${mousePosition.x * -10}deg) scale3d(1.02, 1.02, 1.02)`
            : "perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)",
        }}
        transition={{ duration: 0.2 }}
      >
        <div className="relative h-64 w-full overflow-hidden">
          <Image
            src={image || "/placeholder.svg"}
            alt={title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-bright-black to-transparent opacity-60" />

          {category && (
            <div className="absolute top-4 left-4">
              <motion.span
                className="px-3 py-1 bg-bright-yellow text-bright-black text-xs font-medium rounded-full"
                animate={{
                  y: isHovered ? 0 : -5,
                  opacity: isHovered ? 1 : 0.9,
                }}
                transition={{ duration: 0.3 }}
              >
                {category}
              </motion.span>
            </div>
          )}
        </div>

        <div className="p-6">
          <motion.h3
            className="text-xl font-semibold mb-2 text-bright-white group-hover:text-bright-yellow transition-colors"
            animate={{
              y: isHovered ? 0 : 5,
              opacity: isHovered ? 1 : 0.9,
            }}
            transition={{ duration: 0.3, delay: 0.05 }}
          >
            {title}
          </motion.h3>

          <motion.p
            className="text-muted-foreground mb-4 line-clamp-2"
            animate={{
              y: isHovered ? 0 : 10,
              opacity: isHovered ? 1 : 0.8,
            }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            {description}
          </motion.p>

          <motion.span
            className="text-sm font-medium text-bright-yellow flex items-center"
            initial={{ opacity: 0, x: -10 }}
            animate={{
              opacity: isHovered ? 1 : 0,
              x: isHovered ? 0 : -10,
            }}
            transition={{ duration: 0.3, delay: 0.15 }}
          >
            View Project <ArrowRight className="ml-1 h-3 w-3 group-hover:translate-x-1 transition-transform" />
          </motion.span>
        </div>

        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-bright-yellow/5 to-transparent opacity-0"
          animate={{
            opacity: isHovered ? 1 : 0,
            translateX: isHovered ? mousePosition.x * 10 : 0,
            translateY: isHovered ? mousePosition.y * 10 : 0,
          }}
          transition={{ duration: 0.2 }}
        />
      </motion.div>
    </Link>
  )
}
