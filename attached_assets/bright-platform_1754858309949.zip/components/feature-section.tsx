"use client"

import { useRef, useEffect } from "react"
import Image from "next/image"
import { Check } from "lucide-react"
import { motion, useInView, useAnimation } from "framer-motion"

export default function FeatureSection() {
  const controls = useAnimation()
  const ref = useRef(null)
  const isInView = useInView(ref, { once: false, threshold: 0.3 })

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [controls, isInView])

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  }

  return (
    <section className="py-20 px-4 md:px-6 lg:px-8 bg-gradient-to-b from-bright-black to-bright-black/95 overflow-hidden">
      <div className="container mx-auto">
        <motion.div
          ref={ref}
          initial="hidden"
          animate={controls}
          variants={containerVariants}
          className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center"
        >
          <motion.div variants={itemVariants}>
            <h2 className="text-3xl md:text-5xl font-bold mb-6 text-bright-yellow">
              Immersive Technology for Real-World Impact
            </h2>
            <p className="text-lg text-bright-white/70 mb-8">
              Our solutions bridge the gap between physical and digital experiences, creating meaningful engagement and
              measurable results.
            </p>

            <div className="space-y-4">
              {[
                "Interactive VR/AR experiences for any industry",
                "Seamless integration with existing systems",
                "Mobile-first approach for maximum accessibility",
                "Data-driven insights to measure engagement",
                "Expert support from concept to deployment",
              ].map((feature, index) => (
                <motion.div key={index} variants={itemVariants} className="flex items-start">
                  <div className="mr-3 mt-1 bg-bright-yellow rounded-full p-1">
                    <Check className="h-4 w-4 text-bright-black" />
                  </div>
                  <p className="text-bright-white">{feature}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="relative">
            <div className="relative rounded-xl overflow-hidden shadow-xl border border-bright-yellow/20">
              <div className="aspect-video">
                <Image src="/images/building2.webp" alt="VR Experience" fill className="object-cover" />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-bright-black/50 to-transparent" />
            </div>
            <div className="absolute -bottom-6 -left-6 w-48 h-48 rounded-lg overflow-hidden shadow-lg hidden md:block border border-bright-yellow/20">
              <Image
                src="/images/building7.webp"
                alt="AR Application"
                width={200}
                height={200}
                className="object-cover"
              />
            </div>
            <div className="absolute -top-6 -right-6 w-24 h-24 rounded-full overflow-hidden shadow-lg hidden md:block border-2 border-bright-yellow animate-float">
              <Image src="/images/logo.png" alt="Bright Logo" width={100} height={100} className="object-cover" />
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
