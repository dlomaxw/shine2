"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface StandaloneCarouselProps {
  images: {
    src: string
    alt: string
  }[]
  autoplay?: boolean
  interval?: number
  className?: string
  fullWidth?: boolean
  height?: string
  showControls?: boolean
  showIndicators?: boolean
  overlay?: boolean
}

export default function StandaloneCarousel(props: StandaloneCarouselProps) {
  const {
    images = [],
    autoplay = true,
    interval = 5000,
    className = "",
    fullWidth = true,
    height = "h-screen",
    showControls = true,
    showIndicators = true,
    overlay = true,
  } = props

  const [currentIndex, setCurrentIndex] = useState(0)
  const [isHovering, setIsHovering] = useState(false)
  const [isTransitioning, setIsTransitioning] = useState(false)
  const timerRef = useRef<NodeJS.Timeout | null>(null)

  // Ensure currentIndex is within bounds
  useEffect(() => {
    if (currentIndex >= images.length) {
      setCurrentIndex(0)
    }
  }, [currentIndex, images.length])

  useEffect(() => {
    if (autoplay && !isHovering && images.length > 1) {
      timerRef.current = setInterval(nextSlide, interval)
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [autoplay, interval, isHovering, images.length])

  // Safety check for images
  if (!images || images.length === 0) {
    return (
      <div
        className={cn(
          "relative overflow-hidden bg-bright-black flex items-center justify-center",
          fullWidth ? "w-full" : "w-auto",
          height,
          className,
        )}
      >
        <div className="text-bright-white">No images available</div>
      </div>
    )
  }

  const nextSlide = () => {
    if (isTransitioning) return
    setIsTransitioning(true)
    setCurrentIndex((prevIndex) => (prevIndex === images.length - 1 ? 0 : prevIndex + 1))
    setTimeout(() => setIsTransitioning(false), 500)
  }

  const prevSlide = () => {
    if (isTransitioning) return
    setIsTransitioning(true)
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? images.length - 1 : prevIndex - 1))
    setTimeout(() => setIsTransitioning(false), 500)
  }

  const goToSlide = (index: number) => {
    if (isTransitioning || index === currentIndex || index < 0 || index >= images.length) return
    setIsTransitioning(true)
    setCurrentIndex(index)
    setTimeout(() => setIsTransitioning(false), 500)
  }

  const handleMouseEnter = () => {
    setIsHovering(true)
  }

  const handleMouseLeave = () => {
    setIsHovering(false)
  }

  const handlePrevClick = () => {
    prevSlide()
  }

  const handleNextClick = () => {
    nextSlide()
  }

  const handleIndicatorClick = (index: number) => {
    goToSlide(index)
  }

  const currentImage = images[currentIndex]
  if (!currentImage) {
    return (
      <div
        className={cn(
          "relative overflow-hidden bg-bright-black flex items-center justify-center",
          fullWidth ? "w-full" : "w-auto",
          height,
          className,
        )}
      >
        <div className="text-bright-white">Image not found</div>
      </div>
    )
  }

  return (
    <div
      className={cn("relative overflow-hidden group", fullWidth ? "w-full" : "w-auto", height, className)}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      style={{ maxHeight: "calc(100vh - 80px)" }}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full h-full"
        >
          <div className="relative w-full h-full">
            <Image
              src={currentImage.src || "/placeholder.svg?height=800&width=1200"}
              alt={currentImage.alt || "Carousel image"}
              fill
              className="object-cover"
              priority={currentIndex === 0}
              sizes="100vw"
            />
            {overlay && <div className="absolute inset-0 bg-gradient-to-t from-bright-black/70 to-transparent" />}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation Arrows */}
      {showControls && images.length > 1 && (
        <>
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-2 sm:left-4 top-1/2 -translate-y-1/2 bg-bright-yellow/20 backdrop-blur-sm text-bright-black hover:bg-bright-yellow/40 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 sm:h-10 sm:w-10 rounded-full z-10"
            onClick={handlePrevClick}
            disabled={isTransitioning}
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-4 w-4 sm:h-6 sm:w-6" />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 sm:right-4 top-1/2 -translate-y-1/2 bg-bright-yellow/20 backdrop-blur-sm text-bright-black hover:bg-bright-yellow/40 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 sm:h-10 sm:w-10 rounded-full z-10"
            onClick={handleNextClick}
            disabled={isTransitioning}
            aria-label="Next slide"
          >
            <ChevronRight className="h-4 w-4 sm:h-6 sm:w-6" />
          </Button>
        </>
      )}

      {/* Indicators */}
      {showIndicators && images.length > 1 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-1 sm:space-x-2 z-10">
          {images.map((_, index) => (
            <button
              key={index}
              className={`w-1.5 h-1.5 sm:w-2.5 sm:h-2.5 rounded-full transition-all ${
                index === currentIndex ? "bg-bright-yellow w-4 sm:w-8" : "bg-bright-white/50 hover:bg-bright-white"
              }`}
              onClick={() => handleIndicatorClick(index)}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  )
}
