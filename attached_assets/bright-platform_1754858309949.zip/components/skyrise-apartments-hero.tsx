"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { MapPin, Building2, Home, Users, Calendar, CreditCard } from "lucide-react"

export default function SkyriseApartmentsHero() {
  return (
    <section className="relative min-h-screen bg-bright-black overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/images/skyrise-aerial-view.jpeg"
          alt="Skyrise Apartments - Luxury Living in Kololo, Kampala"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-bright-black via-bright-black/80 to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 min-h-screen flex items-center">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            {/* Developer Badge */}
            <div className="inline-flex items-center px-4 py-2 bg-bright-yellow/10 border border-bright-yellow/20 rounded-full">
              <Building2 className="h-4 w-4 text-bright-yellow mr-2" />
              <span className="text-bright-yellow font-medium">Premium Development</span>
            </div>

            {/* Main Heading */}
            <div>
              <h1 className="text-4xl md:text-6xl font-bold text-bright-white mb-4">
                <span className="relative inline-block">
                  <span className="relative z-10">Skyrise</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </span>
                <br />
                <span className="text-bright-yellow">Apartments</span>
              </h1>
              <h2 className="text-xl md:text-2xl text-bright-yellow/80 font-medium mb-2">
                Luxury Living in Prestigious Kololo
              </h2>
              <p className="text-lg text-bright-white/70 italic">
                "Where luxury meets convenience in the heart of Kampala"
              </p>
            </div>

            {/* Location */}
            <div className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-bright-yellow" />
              <span className="text-bright-white font-medium">Kololo, Kampala</span>
            </div>

            {/* Key Features */}
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <div className="flex items-center">
                  <Home className="h-5 w-5 text-bright-yellow mr-2" />
                  <span className="text-bright-white font-medium">Unit Types</span>
                </div>
                <p className="text-bright-white/70">2 & 3 bedroom luxury apartments</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center">
                  <CreditCard className="h-5 w-5 text-bright-yellow mr-2" />
                  <span className="text-bright-white font-medium">Starting Price</span>
                </div>
                <p className="text-bright-yellow font-bold text-xl">$135,000</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-bright-yellow mr-2" />
                  <span className="text-bright-white font-medium">Payment Plan</span>
                </div>
                <p className="text-bright-white/70">40 Month Flexible Plan</p>
              </div>
              <div className="space-y-2">
                <div className="flex items-center">
                  <Users className="h-5 w-5 text-bright-yellow mr-2" />
                  <span className="text-bright-white font-medium">Total Units</span>
                </div>
                <p className="text-bright-white/70">72 Luxury Apartments</p>
              </div>
            </div>

            {/* Description */}
            <p className="text-bright-white/80 text-lg leading-relaxed">
              Skyrise Apartments presents an exclusive collection of meticulously designed luxury residences in the
              prestigious neighborhood of Kololo. Enjoy{" "}
              <span className="text-bright-yellow font-medium">breathtaking golf course views</span>, expansive layouts,
              and thoughtfully designed interiors that maximize space and functionality.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 font-medium">
                Reserve for $5,000
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-bright-white text-bright-white hover:bg-bright-white/10"
              >
                Download Brochure
              </Button>
            </div>
          </motion.div>

          {/* Right Content - Image Gallery */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="hidden lg:block"
          >
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="relative h-48 rounded-lg overflow-hidden">
                  <Image
                    src="/images/skyrise-rooftop-view.jpeg"
                    alt="Skyrise Apartments Rooftop View"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="relative h-32 rounded-lg overflow-hidden">
                  <Image src="/images/skyrise-pool.jpeg" alt="Skyrise Apartments Pool" fill className="object-cover" />
                </div>
              </div>
              <div className="space-y-4 mt-8">
                <div className="relative h-32 rounded-lg overflow-hidden">
                  <Image
                    src="/images/skyrise-interior.png"
                    alt="Skyrise Apartments Interior"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="relative h-48 rounded-lg overflow-hidden">
                  <Image
                    src="/images/skyrise-aerial-view.jpeg"
                    alt="Skyrise Apartments Aerial View"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Floating Info Cards */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 hidden md:flex space-x-4">
        <div className="bg-bright-black/80 backdrop-blur-sm border border-bright-yellow/20 rounded-lg px-4 py-2">
          <p className="text-bright-white/70 text-sm">Premium Location</p>
          <p className="text-bright-yellow font-medium">Kololo, Kampala</p>
        </div>
        <div className="bg-bright-black/80 backdrop-blur-sm border border-bright-yellow/20 rounded-lg px-4 py-2">
          <p className="text-bright-white/70 text-sm">Reservation</p>
          <p className="text-bright-yellow font-medium">Only $5,000</p>
        </div>
        <div className="bg-bright-black/80 backdrop-blur-sm border border-bright-yellow/20 rounded-lg px-4 py-2">
          <p className="text-bright-white/70 text-sm">Starting From</p>
          <p className="text-bright-yellow font-medium">$135,000</p>
        </div>
      </div>
    </section>
  )
}
