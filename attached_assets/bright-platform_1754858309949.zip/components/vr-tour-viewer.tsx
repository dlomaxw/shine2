"use client"

import { useState, useEffect } from "react"
import { Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface VRTourViewerProps {
  tourUrl: string
  title: string
  fullscreen?: boolean
}

export default function VRTourViewer({ tourUrl, title, fullscreen = false }: VRTourViewerProps) {
  const [isLoading, setIsLoading] = useState(true)
  const [isWebXRSupported, setIsWebXRSupported] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(fullscreen)

  useEffect(() => {
    // Check if WebXR is supported
    if (navigator.xr) {
      navigator.xr
        .isSessionSupported("immersive-vr")
        .then((supported) => {
          setIsWebXRSupported(supported)
        })
        .catch((err) => {
          console.error("Error checking WebXR support:", err)
          setIsWebXRSupported(false)
        })
    }

    // Simulate loading the VR tour
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  const handleEnterVR = () => {
    // This would be implemented with WebXR API in Phase 3
    alert("Entering VR mode - This functionality will be implemented in Phase 3")
  }

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  return (
    <Card className={`overflow-hidden ${isFullscreen ? "fixed inset-0 z-50 rounded-none" : "relative"}`}>
      <CardContent className="p-0">
        <div className="relative">
          {isLoading ? (
            <div
              className="flex items-center justify-center bg-slate-100 w-full"
              style={{ height: isFullscreen ? "100vh" : "400px" }}
            >
              <div className="text-center">
                <Loader2 className="h-10 w-10 animate-spin text-primary mx-auto mb-4" />
                <p>Loading VR Experience...</p>
              </div>
            </div>
          ) : (
            <>
              <div className="relative w-full" style={{ height: isFullscreen ? "100vh" : "400px" }}>
                <iframe
                  src={tourUrl || "about:blank"}
                  title={title}
                  className="w-full h-full border-0"
                  allowFullScreen
                />
              </div>
              <div className="absolute bottom-4 right-4 flex gap-2">
                {isWebXRSupported && (
                  <Button onClick={handleEnterVR} variant="secondary" size="sm">
                    Enter VR
                  </Button>
                )}
                <Button onClick={toggleFullscreen} variant="secondary" size="sm">
                  {isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
                </Button>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
