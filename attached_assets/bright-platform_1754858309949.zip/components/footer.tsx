import Link from "next/link"
import Image from "next/image"
import { Facebook, Instagram, Linkedin, Twitter, MapPin, Phone, Mail } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-bright-black text-bright-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="relative h-8 w-8 sm:h-10 sm:w-10 md:h-12 md:w-12 overflow-hidden">
                <Image src="/images/logo.png" alt="Bright Logo" fill className="object-contain" />
              </div>
              <span className="font-bold text-lg sm:text-xl md:text-2xl text-bright-yellow">BRIGHT</span>
            </div>
            <p className="text-gray-400 mb-6">
              Bridging reality and immersive technology to transform how businesses operate and engage.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-gray-400 hover:text-bright-yellow transition-colors">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-bright-yellow transition-colors">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-bright-yellow transition-colors">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-gray-400 hover:text-bright-yellow transition-colors">
                <Linkedin className="h-5 w-5" />
                <span className="sr-only">LinkedIn</span>
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-bright-yellow">Industries</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/real-estate" className="text-gray-400 hover:text-bright-yellow transition-colors">
                  Real Estate
                </Link>
              </li>
              <li>
                <Link href="/media" className="text-gray-400 hover:text-bright-yellow transition-colors">
                  Media & Entertainment
                </Link>
              </li>
              <li>
                <Link href="/training" className="text-gray-400 hover:text-bright-yellow transition-colors">
                  Training
                </Link>
              </li>
              <li>
                <Link href="/corporate" className="text-gray-400 hover:text-bright-yellow transition-colors">
                  Corporate
                </Link>
              </li>
              <li>
                <Link href="/digital" className="text-gray-400 hover:text-bright-yellow transition-colors">
                  Digital
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-bright-yellow">Company</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-gray-400 hover:text-bright-yellow transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/portfolio" className="text-gray-400 hover:text-bright-yellow transition-colors">
                  Portfolio
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-gray-400 hover:text-bright-yellow transition-colors">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/careers" className="text-gray-400 hover:text-bright-yellow transition-colors">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-bright-yellow transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-bright-yellow">Contact</h3>
            <address className="not-italic text-gray-400 space-y-3">
              <p className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 text-bright-yellow shrink-0 mt-0.5" />
                <span>1St Floor Shop 4, The Square, Plot 10 Third St, Kampala</span>
              </p>
              <p className="flex items-center">
                <Mail className="h-5 w-5 mr-2 text-bright-yellow" />
                <a
                  href="mailto:brightthoughtsservices@gmail.com"
                  className="hover:text-bright-yellow transition-colors"
                >
                  brightthoughtsservices@gmail.com
                </a>
              </p>
              <p className="flex items-center">
                <Phone className="h-5 w-5 mr-2 text-bright-yellow" />
                <a href="tel:+256750421224" className="hover:text-bright-yellow transition-colors">
                  +256 750 421 224
                </a>
              </p>
            </address>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              &copy; {new Date().getFullYear()} Bright Platform. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="/terms" className="text-gray-400 hover:text-bright-yellow text-sm transition-colors">
                Terms of Service
              </Link>
              <Link href="/privacy" className="text-gray-400 hover:text-bright-yellow text-sm transition-colors">
                Privacy Policy
              </Link>
              <Link href="/cookies" className="text-gray-400 hover:text-bright-yellow text-sm transition-colors">
                Cookie Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
