"use client"

import type React from "react"

import { useState } from "react"
import { Check } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { submitInquiry } from "@/lib/api-client"
import { toast } from "@/components/ui/use-toast"

interface ContactFormProps {
  propertyId?: string
  propertyTitle?: string
  serviceType?: string
  simplified?: boolean
}

export default function ContactForm({ propertyId, propertyTitle, serviceType, simplified = false }: ContactFormProps) {
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    phone: "",
    message: propertyTitle ? `I'm interested in ${propertyTitle}` : "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormState((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      const result = await submitInquiry({
        ...formState,
        propertyId,
        serviceType,
      })

      if (result.success) {
        setIsSuccess(true)
        toast({
          title: "Form submitted successfully",
          description: result.message,
        })

        // Reset form after 3 seconds
        setTimeout(() => {
          setIsSuccess(false)
          setFormState({
            name: "",
            email: "",
            phone: "",
            message: propertyTitle ? `I'm interested in ${propertyTitle}` : "",
          })
        }, 3000)
      } else {
        toast({
          title: "Error submitting form",
          description: result.message || "Please try again later.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error submitting form:", error)
      toast({
        title: "Error submitting form",
        description: "An unexpected error occurred. Please try again later.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Full Name</Label>
        <Input id="name" name="name" placeholder="John Doe" required value={formState.name} onChange={handleChange} />
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          name="email"
          type="email"
          placeholder="john@example.com"
          required
          value={formState.email}
          onChange={handleChange}
        />
      </div>

      {!simplified && (
        <div className="space-y-2">
          <Label htmlFor="phone">Phone (optional)</Label>
          <Input
            id="phone"
            name="phone"
            placeholder="+256 750 421 224"
            value={formState.phone}
            onChange={handleChange}
          />
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="message">Message</Label>
        <Textarea
          id="message"
          name="message"
          placeholder="Your message..."
          className={simplified ? "min-h-[80px]" : "min-h-[120px]"}
          value={formState.message}
          onChange={handleChange}
        />
      </div>

      <Button type="submit" className="w-full" disabled={isSubmitting || isSuccess}>
        {isSubmitting ? (
          "Submitting..."
        ) : isSuccess ? (
          <span className="flex items-center">
            <Check className="mr-2 h-4 w-4" /> Submitted
          </span>
        ) : (
          "Submit"
        )}
      </Button>
    </form>
  )
}
