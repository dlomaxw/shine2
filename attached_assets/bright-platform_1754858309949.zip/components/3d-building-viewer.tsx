"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import { Maximize2, Minimize2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ThreeDModelViewerProps {
  modelType: string
  className?: string
  fullscreen?: boolean
  onFullscreenChange?: (isFullscreen: boolean) => void
}

export default function ThreeDModelViewer({
  modelType = "modern",
  className = "",
  fullscreen = false,
  onFullscreenChange,
}: ThreeDModelViewerProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [isFullscreen, setIsFullscreen] = useState(fullscreen)
  const [isDragging, setIsDragging] = useState(false)
  const [rotation, setRotation] = useState({ x: 15, y: 30 })
  const [zoom, setZoom] = useState(1)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [isLoading, setIsLoading] = useState(true)
  const [lightPosition, setLightPosition] = useState({ x: 100, y: 100 })

  // Map model types to images
  const modelImages = {
    modern: "/images/apartment-building.webp",
    residential: "/images/curved-house.webp",
    commercial: "/images/commercial-building.webp",
    historical: "/images/brick-arches.webp",
  }

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [modelType])

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX, y: e.clientY })
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    // Update light position for dynamic shadows
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect()
      const x = ((e.clientX - rect.left) / rect.width) * 200 - 100
      const y = ((e.clientY - rect.top) / rect.height) * 200 - 100
      setLightPosition({ x, y })
    }

    if (!isDragging) return

    const deltaX = e.clientX - dragStart.x
    const deltaY = e.clientY - dragStart.y

    setRotation({
      x: rotation.x + deltaY * 0.5,
      y: rotation.y + deltaX * 0.5,
    })

    setDragStart({ x: e.clientX, y: e.clientY })
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleMouseLeave = () => {
    setIsDragging(false)
  }

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault()
    const newZoom = zoom - e.deltaY * 0.001
    setZoom(Math.min(Math.max(newZoom, 0.5), 2))
  }

  const toggleFullscreen = () => {
    const newState = !isFullscreen
    setIsFullscreen(newState)
    if (onFullscreenChange) {
      onFullscreenChange(newState)
    }
  }

  return (
    <div
      className={`relative ${
        isFullscreen ? "fixed inset-0 z-50 bg-bright-black" : `h-[300px] sm:h-[350px] md:h-[400px] ${className}`
      }`}
    >
      {isLoading ? (
        <div className="absolute inset-0 flex items-center justify-center bg-bright-black/50 z-10">
          <div className="flex flex-col items-center">
            <div className="h-10 w-10 animate-spin rounded-full border-4 border-bright-yellow border-t-transparent"></div>
            <p className="mt-2 text-bright-white">Loading 3D Model...</p>
          </div>
        </div>
      ) : (
        <div
          ref={containerRef}
          className="w-full h-full overflow-hidden bg-gradient-to-b from-bright-black to-bright-black-light cursor-grab"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseLeave}
          onWheel={handleWheel}
          style={{ perspective: "1000px" }}
        >
          <div
            className="w-full h-full flex items-center justify-center transition-transform duration-100"
            style={{
              transform: `scale(${zoom}) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
              transformStyle: "preserve-3d",
            }}
          >
            {/* Building model - using images with CSS 3D transforms */}
            <div className="relative" style={{ transformStyle: "preserve-3d" }}>
              {/* Base */}
              <div
                className="absolute bg-bright-black-light w-64 h-64"
                style={{
                  transform: "translateZ(-10px) translateY(30px)",
                  boxShadow: `${-lightPosition.x / 5}px ${-lightPosition.y / 5}px 15px rgba(0,0,0,0.3)`,
                }}
              ></div>

              {/* Main building */}
              <div className="relative w-48 h-48 transform-gpu">
                {/* Front face */}
                <div
                  className="absolute inset-0 bg-bright-yellow/10 border border-bright-yellow/30 overflow-hidden"
                  style={{
                    transform: "translateZ(24px)",
                    boxShadow: `${-lightPosition.x / 10}px ${-lightPosition.y / 10}px 10px rgba(0,0,0,0.2)`,
                  }}
                >
                  <Image
                    src={modelImages[modelType as keyof typeof modelImages] || "/images/apartment-building.webp"}
                    alt={`${modelType} building`}
                    fill
                    className="object-cover opacity-90"
                  />
                </div>

                {/* Back face */}
                <div
                  className="absolute inset-0 bg-bright-yellow/5 border border-bright-yellow/20"
                  style={{ transform: "translateZ(-24px) rotateY(180deg)" }}
                >
                  <Image
                    src={modelImages[modelType as keyof typeof modelImages] || "/images/apartment-building.webp"}
                    alt={`${modelType} building back`}
                    fill
                    className="object-cover opacity-50"
                  />
                </div>

                {/* Left face */}
                <div
                  className="absolute inset-0 bg-bright-yellow/5 border border-bright-yellow/20"
                  style={{
                    transform: "translateX(-24px) rotateY(-90deg)",
                    width: "48px",
                    transformOrigin: "left",
                    boxShadow: `${lightPosition.x > 0 ? lightPosition.x / 10 : 0}px ${-lightPosition.y / 10}px 10px rgba(0,0,0,0.2)`,
                  }}
                >
                  <div className="w-full h-full bg-gradient-to-r from-bright-black-light to-bright-black"></div>
                </div>

                {/* Right face */}
                <div
                  className="absolute inset-0 bg-bright-yellow/5 border border-bright-yellow/20"
                  style={{
                    transform: "translateX(24px) rotateY(90deg)",
                    width: "48px",
                    transformOrigin: "right",
                    boxShadow: `${lightPosition.x < 0 ? -lightPosition.x / 10 : 0}px ${-lightPosition.y / 10}px 10px rgba(0,0,0,0.2)`,
                  }}
                >
                  <div className="w-full h-full bg-gradient-to-l from-bright-black-light to-bright-black"></div>
                </div>

                {/* Top face */}
                <div
                  className="absolute inset-0 bg-bright-yellow/20 border border-bright-yellow/30"
                  style={{
                    transform: "translateY(-24px) rotateX(90deg)",
                    height: "48px",
                    transformOrigin: "top",
                    boxShadow: `${-lightPosition.x / 10}px ${lightPosition.y > 0 ? lightPosition.y / 10 : 0}px 10px rgba(0,0,0,0.2)`,
                  }}
                >
                  <div className="w-full h-full bg-bright-yellow/10"></div>
                </div>

                {/* Bottom face */}
                <div
                  className="absolute inset-0 bg-bright-black border border-bright-yellow/10"
                  style={{
                    transform: "translateY(24px) rotateX(-90deg)",
                    height: "48px",
                    transformOrigin: "bottom",
                  }}
                >
                  <div className="w-full h-full bg-bright-black"></div>
                </div>
              </div>

              {/* Roof */}
              <div
                className="absolute w-56 h-56 bg-bright-yellow/20 border border-bright-yellow/30"
                style={{
                  transform: "translateY(-48px) rotateX(45deg) scale(0.7, 0.7)",
                  transformOrigin: "center",
                  boxShadow: `${-lightPosition.x / 8}px ${-lightPosition.y / 8}px 15px rgba(0,0,0,0.3)`,
                }}
              ></div>
            </div>
          </div>

          {/* Instructions overlay */}
          <div className="absolute bottom-10 sm:bottom-16 left-2 sm:left-4 bg-bright-black/70 text-bright-white text-xs p-1 sm:p-2 rounded">
            <p>Drag to rotate • Scroll to zoom • Move mouse to change lighting</p>
          </div>
        </div>
      )}

      <Button
        variant="outline"
        size="sm"
        onClick={toggleFullscreen}
        className="absolute bottom-2 sm:bottom-4 right-2 sm:right-4 bg-bright-black/50 border-bright-yellow/50 text-bright-yellow hover:bg-bright-yellow hover:text-bright-black text-xs sm:text-sm"
      >
        {isFullscreen ? (
          <>
            <Minimize2 className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" /> Exit Fullscreen
          </>
        ) : (
          <>
            <Maximize2 className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" /> Fullscreen
          </>
        )}
      </Button>
    </div>
  )
}
