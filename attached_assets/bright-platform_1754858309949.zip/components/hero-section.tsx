"use client"

import { useState } from "react"
import { ArrowRight, Play } from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import ImageCarousel from "@/components/image-carousel"

const carouselImages = [
  { src: "/images/building1.webp", alt: "Modern building with balconies and pool" },
  { src: "/images/building2.webp", alt: "Curved white high-rise building" },
  { src: "/images/building3.webp", alt: "Tall modern building with unique silhouette" },
  { src: "/images/building4.webp", alt: "White building with rounded window openings" },
  { src: "/images/building5.webp", alt: "White corner building with retail space" },
  { src: "/images/building6.webp", alt: "Modern apartment building with large balconies" },
  { src: "/images/building7.webp", alt: "White and red modern office building" },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a0b636bae87bcc2975fca450f582d3fc_high-TlUhD7qnAPEvvgWaJMUdjAsLVapZRn.webp",
    alt: "Contemporary curved edge house",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a1823870bc6ac6aa38e4f0dbb81d9939_high-x1dgCbfVnigzQF0W7PqZ5LAy0W4wq2.webp",
    alt: "Modern house with circular windows",
  },
  {
    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/aa67ef8cee448ed470f7311e5773ad0d_high-rDL21lQPU8UM6iuDU7DctpIMCQ7ssa.webp",
    alt: "Compact modern house with wood elements",
  },
]

export default function HeroSection() {
  const [videoOpen, setVideoOpen] = useState(false)

  return (
    <section className="relative min-h-[60vh] sm:min-h-[70vh] md:min-h-[80vh] overflow-hidden">
      {/* Background Carousel - Standalone */}
      <div className="absolute inset-0 z-0">
        <ImageCarousel images={carouselImages} className="h-full" />
      </div>

      {/* Content - Separate from carousel */}
      <div className="relative z-10 flex items-center justify-center h-full py-16 sm:py-20 md:py-24">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="container mx-auto px-4 text-center"
        >
          <div className="max-w-4xl mx-auto bg-bright-black/40 backdrop-blur-sm p-6 rounded-lg shadow-lg border border-bright-yellow/20">
            <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold mb-4 sm:mb-6 text-bright-white leading-tight">
              <span className="relative inline-block">
                <span className="relative z-10">Where Reality Meets</span>
                <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
              </span>
              <br />
              <span className="text-gradient relative inline-block">
                <span className="relative z-10">Immersive Technology</span>
                <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
              </span>
            </h1>
            <p className="text-base sm:text-lg md:text-xl text-bright-white/90 mb-6 sm:mb-8 max-w-2xl mx-auto">
              Bright delivers seamless experiences that bridge physical spaces and digital innovation across industries.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
              <Button
                size="lg"
                className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 group relative overflow-hidden"
              >
                <span className="relative z-10 flex items-center">
                  Explore Solutions{" "}
                  <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </span>
                <span className="absolute inset-0 bg-white/20 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></span>
              </Button>
              <Dialog open={videoOpen} onOpenChange={setVideoOpen}>
                <DialogTrigger asChild>
                  <Button
                    size="lg"
                    variant="outline"
                    className="border-bright-white text-bright-white hover:bg-bright-white/10 mt-3 sm:mt-0 relative overflow-hidden group"
                  >
                    <span className="relative z-10 flex items-center">
                      <Play className="mr-2 h-5 w-5" /> Watch Demo
                    </span>
                    <span className="absolute inset-0 bg-bright-yellow/20 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></span>
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl p-0 overflow-hidden bg-bright-black">
                  <div className="aspect-video w-full">
                    <div className="w-full h-full flex items-center justify-center text-bright-white">
                      <p>Video demo would play here</p>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Animated Scroll Indicator */}
      <div className="absolute bottom-4 sm:bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <div className="w-6 h-9 sm:w-8 sm:h-12 border-2 border-bright-white/50 rounded-full flex justify-center">
          <div className="w-1 h-2 sm:w-1.5 sm:h-3 bg-bright-yellow rounded-full mt-2 animate-bounce" />
        </div>
      </div>
    </section>
  )
}
