"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X, ChevronDown, LogIn, Settings } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { cn } from "@/lib/utils"

const industries = [
  { name: "Real Estate", href: "/real-estate", description: "Virtual property tours and 3D visualizations" },
  { name: "Architecture", href: "/architecture", description: "Architectural visualization and design" },
  { name: "Interior Design", href: "/interior-design", description: "Interior visualization and virtual staging" },
  { name: "Media & Entertainment", href: "/media", description: "Immersive content creation and video production" },
  { name: "Training", href: "/training", description: "VR/AR training solutions for skills development" },
  { name: "Corporate", href: "/corporate", description: "Virtual meetings and collaborative spaces" },
  { name: "Digital", href: "/digital", description: "Custom digital solutions and web development" },
]

export default function FuturisticNavbar() {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [industriesOpen, setIndustriesOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={cn(
        "fixed top-0 w-full z-50 transition-all duration-500",
        "bg-[#0a0c14] py-4", // Dark background like in the screenshot
      )}
    >
      <div className="container flex items-center justify-between">
        <Link href="/" className="relative z-10 flex items-center space-x-2">
          <div className="relative h-8 w-8 sm:h-9 sm:w-9 md:h-10 md:w-10 overflow-hidden">
            <Image src="/images/logo.png" alt="Bright Logo" fill className="object-contain" />
          </div>
          <motion.span
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="font-bold text-lg sm:text-xl md:text-2xl text-bright-yellow"
          >
            BRIGHT
          </motion.span>
        </Link>

        <div className="hidden md:flex md:flex-1 justify-center">
          <nav className="flex items-center space-x-8">
            <div className="relative group">
              <button
                onClick={() => setIndustriesOpen(!industriesOpen)}
                className="px-4 py-2 text-bright-white hover:text-bright-yellow font-medium flex items-center transition-colors relative overflow-hidden group"
              >
                <span className="relative z-10">Services</span>
                <ChevronDown
                  className={`ml-1 h-4 w-4 transition-transform duration-300 ${industriesOpen ? "rotate-180" : ""}`}
                />
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-bright-yellow group-hover:w-full transition-all duration-300"></span>
              </button>

              <AnimatePresence>
                {industriesOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.2 }}
                    className="absolute top-full left-0 mt-1 w-64 bg-[#0a0c14] border border-bright-yellow/20 rounded-md shadow-lg overflow-hidden z-50"
                    onMouseLeave={() => setIndustriesOpen(false)}
                  >
                    <div className="p-2 grid gap-1">
                      {industries.map((industry) => (
                        <Link
                          key={industry.name}
                          href={industry.href}
                          className="block p-2 rounded-md hover:bg-bright-yellow/10 text-bright-white hover:text-bright-yellow transition-colors"
                        >
                          <div className="font-medium">{industry.name}</div>
                          <div className="text-xs text-bright-white/70">{industry.description}</div>
                        </Link>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <Link href="/media" className="px-4 py-2 text-bright-white font-medium relative overflow-hidden group">
              <span className="relative z-10">Animation</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-bright-yellow group-hover:w-full transition-all duration-300"></span>
            </Link>

            <Link
              href="/architecture"
              className="px-4 py-2 text-bright-white font-medium relative overflow-hidden group"
            >
              <span className="relative z-10">Architecture</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-bright-yellow group-hover:w-full transition-all duration-300"></span>
            </Link>

            <Link href="/about" className="px-4 py-2 text-bright-white font-medium relative overflow-hidden group">
              <span className="relative z-10">About</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-bright-yellow group-hover:w-full transition-all duration-300"></span>
            </Link>

            <Link href="/contact" className="px-4 py-2 text-bright-white font-medium relative overflow-hidden group">
              <span className="relative z-10">Contact</span>
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-bright-yellow group-hover:w-full transition-all duration-300"></span>
            </Link>
          </nav>
        </div>

        <div className="hidden md:flex items-center space-x-4">
          <Button
            variant="outline"
            className="border-bright-yellow text-bright-yellow hover:bg-bright-yellow hover:text-bright-black relative overflow-hidden group"
          >
            <Link href="/admin/dashboard" className="flex items-center">
              <span className="relative z-10 flex items-center">
                <Settings className="mr-2 h-4 w-4" /> Admin
              </span>
              <span className="absolute inset-0 bg-bright-yellow transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></span>
            </Link>
          </Button>
          <Button
            variant="outline"
            className="border-bright-yellow text-bright-yellow hover:bg-bright-yellow hover:text-bright-black relative overflow-hidden group"
          >
            <Link href="/login" className="flex items-center">
              <span className="relative z-10 flex items-center">
                <LogIn className="mr-2 h-4 w-4" /> Client Login
              </span>
              <span className="absolute inset-0 bg-bright-yellow transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></span>
            </Link>
          </Button>
        </div>

        <div className="flex md:hidden">
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden text-bright-white hover:bg-bright-black/20">
                <Menu className="h-5 w-5 sm:h-6 sm:w-6" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent
              side="right"
              className="w-[80vw] max-w-[350px] sm:w-[400px] bg-[#0a0c14] border-bright-yellow/20 p-0"
            >
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-4 border-b border-bright-yellow/10">
                  <Link
                    href="/"
                    className="flex items-center text-lg sm:text-xl font-bold text-bright-yellow"
                    onClick={() => setOpen(false)}
                  >
                    <div className="relative h-8 w-8 sm:h-10 sm:w-10 mr-2 overflow-hidden">
                      <Image src="/images/logo.png" alt="Bright Logo" fill className="object-contain" />
                    </div>
                    BRIGHT
                  </Link>
                  <Button variant="ghost" size="icon" onClick={() => setOpen(false)} className="text-bright-white">
                    <X className="h-5 w-5" />
                  </Button>
                </div>

                <nav className="flex-1 overflow-auto py-4">
                  <div className="px-4 py-2">
                    <div className="text-xs uppercase tracking-wider text-bright-white/50 mb-2">Services</div>
                    <div className="space-y-1 pl-2">
                      {industries.map((industry) => (
                        <Link
                          key={industry.name}
                          href={industry.href}
                          className="block py-2 text-bright-white hover:text-bright-yellow transition-colors"
                          onClick={() => setOpen(false)}
                        >
                          {industry.name}
                        </Link>
                      ))}
                    </div>
                  </div>

                  <div className="px-4 py-2 border-t border-bright-yellow/10 mt-2">
                    <div className="text-xs uppercase tracking-wider text-bright-white/50 mb-2">Navigation</div>
                    <div className="space-y-3 pl-2">
                      <Link
                        href="/media"
                        className="block py-2 text-bright-white hover:text-bright-yellow transition-colors"
                        onClick={() => setOpen(false)}
                      >
                        Animation
                      </Link>
                      <Link
                        href="/architecture"
                        className="block py-2 text-bright-white hover:text-bright-yellow transition-colors"
                        onClick={() => setOpen(false)}
                      >
                        Architecture
                      </Link>
                      <Link
                        href="/about"
                        className="block py-2 text-bright-white hover:text-bright-yellow transition-colors"
                        onClick={() => setOpen(false)}
                      >
                        About
                      </Link>
                      <Link
                        href="/contact"
                        className="block py-2 text-bright-white hover:text-bright-yellow transition-colors"
                        onClick={() => setOpen(false)}
                      >
                        Contact
                      </Link>
                    </div>
                  </div>
                </nav>

                <div className="p-4 border-t border-bright-yellow/10">
                  <div className="grid gap-2">
                    <Button
                      variant="outline"
                      className="w-full border-bright-yellow/50 text-bright-yellow hover:bg-bright-yellow hover:text-bright-black"
                      onClick={() => setOpen(false)}
                    >
                      <Link href="/admin/dashboard" className="flex items-center w-full justify-center">
                        <Settings className="mr-2 h-4 w-4" /> Admin Dashboard
                      </Link>
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full border-bright-yellow text-bright-yellow hover:bg-bright-yellow hover:text-bright-black"
                      onClick={() => setOpen(false)}
                    >
                      <Link href="/login" className="flex items-center w-full justify-center">
                        <LogIn className="mr-2 h-4 w-4" /> Client Login
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  )
}
