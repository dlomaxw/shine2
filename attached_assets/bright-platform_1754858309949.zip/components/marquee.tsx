"use client"

import type { ReactNode } from "react"
import { cn } from "@/lib/utils"

interface MarqueeProps {
  children: ReactNode
  direction?: "left" | "right"
  speed?: "slow" | "normal" | "fast"
  pauseOnHover?: boolean
  className?: string
  repeat?: number
}

export default function Marquee({
  children,
  direction = "left",
  speed = "normal",
  pauseOnHover = true,
  className,
  repeat = 2,
}: MarqueeProps) {
  const speedMap = {
    slow: "animate-[marquee_40s_linear_infinite]",
    normal: "animate-[marquee_25s_linear_infinite]",
    fast: "animate-[marquee_15s_linear_infinite]",
  }

  const directionClass = direction === "right" ? "flex-row-reverse" : "flex-row"
  const animationClass = speedMap[speed]
  const pauseClass = pauseOnHover ? "hover:[animation-play-state:paused]" : ""

  return (
    <div className={cn("overflow-hidden", className)}>
      <div className={cn("flex whitespace-nowrap", directionClass)}>
        {Array(repeat)
          .fill(0)
          .map((_, i) => (
            <div
              key={i}
              className={cn(
                "flex min-w-full shrink-0 items-center justify-around gap-2 sm:gap-4",
                animationClass,
                pauseClass,
              )}
            >
              {children}
            </div>
          ))}
      </div>
    </div>
  )
}
