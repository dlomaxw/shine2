"use client"

import { useState } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { ChevronLeft, ChevronRight, Maximize2, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface ProjectGalleryProps {
  images: {
    src: string
    alt: string
    description?: string
    category?: string
  }[]
  className?: string
}

export default function ProjectGallery({ images, className }: ProjectGalleryProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [isHovering, setIsHovering] = useState(false)

  const nextImage = () => {
    setCurrentIndex((prevIndex) => (prevIndex === images.length - 1 ? 0 : prevIndex + 1))
  }

  const prevImage = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? images.length - 1 : prevIndex - 1))
  }

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-lg",
        isFullscreen ? "fixed inset-0 z-50 bg-bright-black/90 flex items-center justify-center" : "",
        className,
      )}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className={cn("relative w-full", isFullscreen ? "h-screen max-w-7xl px-4" : "aspect-video")}
        >
          <Image
            src={images[currentIndex].src || "/placeholder.svg"}
            alt={images[currentIndex].alt}
            fill
            className="object-cover"
            priority
          />

          {/* Image info overlay */}
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-bright-black/80 to-transparent p-2 sm:p-4">
            <h3 className="text-bright-white text-base sm:text-lg font-bold">{images[currentIndex].alt}</h3>
            {images[currentIndex].description && (
              <p className="text-bright-white/80 text-xs sm:text-sm">{images[currentIndex].description}</p>
            )}
            {images[currentIndex].category && (
              <span className="inline-block mt-1 sm:mt-2 px-2 py-0.5 sm:py-1 bg-bright-yellow text-bright-black text-xs font-medium rounded-full">
                {images[currentIndex].category}
              </span>
            )}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation controls */}
      <div
        className={cn(
          "absolute inset-0 flex items-center justify-between p-2 sm:p-4 transition-opacity duration-300",
          isHovering || isFullscreen ? "opacity-100" : "opacity-0",
        )}
      >
        <Button
          variant="ghost"
          size="icon"
          onClick={prevImage}
          className="bg-bright-black/30 backdrop-blur-sm text-bright-white hover:bg-bright-yellow/70 hover:text-bright-black rounded-full h-8 w-8 sm:h-10 sm:w-10"
        >
          <ChevronLeft className="h-4 w-4 sm:h-6 sm:w-6" />
          <span className="sr-only">Previous</span>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          onClick={nextImage}
          className="bg-bright-black/30 backdrop-blur-sm text-bright-white hover:bg-bright-yellow/70 hover:text-bright-black rounded-full h-8 w-8 sm:h-10 sm:w-10"
        >
          <ChevronRight className="h-4 w-4 sm:h-6 sm:w-6" />
          <span className="sr-only">Next</span>
        </Button>
      </div>

      {/* Fullscreen toggle */}
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleFullscreen}
        className={cn(
          "absolute top-2 sm:top-4 right-2 sm:right-4 bg-bright-black/30 backdrop-blur-sm text-bright-white hover:bg-bright-yellow/70 hover:text-bright-black rounded-full transition-opacity duration-300 h-8 w-8 sm:h-10 sm:w-10",
          isHovering || isFullscreen ? "opacity-100" : "opacity-0",
        )}
      >
        {isFullscreen ? <X className="h-4 w-4 sm:h-5 sm:w-5" /> : <Maximize2 className="h-4 w-4 sm:h-5 sm:w-5" />}
        <span className="sr-only">{isFullscreen ? "Exit fullscreen" : "View fullscreen"}</span>
      </Button>

      {/* Pagination indicators */}
      <div
        className={cn(
          "absolute bottom-16 left-1/2 -translate-x-1/2 flex space-x-1.5 transition-opacity duration-300",
          isHovering || isFullscreen ? "opacity-100" : "opacity-0",
        )}
      >
        {images.map((_, index) => (
          <button
            key={index}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentIndex ? "bg-bright-yellow w-4" : "bg-bright-white/50 hover:bg-bright-white"
            }`}
            onClick={() => setCurrentIndex(index)}
            aria-label={`Go to image ${index + 1}`}
          />
        ))}
      </div>
    </div>
  )
}
