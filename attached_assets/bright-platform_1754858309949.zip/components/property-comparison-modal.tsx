"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import {
  MapPin,
  Bed,
  Bath,
  Square,
  Star,
  Check,
  Minus,
  Calendar,
  Car,
  Wifi,
  Dumbbell,
  Waves,
  Shield,
  CableCarIcon as Elevator,
  Snowflake,
  Heart,
  Eye,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import VideoPlayer from "@/components/video-player"

interface Property {
  id: string
  title: string
  location: string
  price: string
  priceType: "month" | "total"
  image: string
  video?: string
  bedrooms: number
  bathrooms: number
  area: number
  rating?: number
  amenities?: string[]
  yearBuilt?: number
  parkingSpaces?: number
  floorNumber?: number
  totalFloors?: number
  furnished?: boolean
  petFriendly?: boolean
  balcony?: boolean
  gym?: boolean
  pool?: boolean
  security?: boolean
  elevator?: boolean
  airConditioning?: boolean
}

interface PropertyComparisonModalProps {
  isOpen: boolean
  onClose: () => void
  properties: Property[]
}

export default function PropertyComparisonModal({ isOpen, onClose, properties }: PropertyComparisonModalProps) {
  const [activeTab, setActiveTab] = useState("overview")

  const getFeatureIcon = (feature: string) => {
    const icons: { [key: string]: any } = {
      gym: Dumbbell,
      pool: Waves,
      security: Shield,
      elevator: Elevator,
      airConditioning: Snowflake,
      wifi: Wifi,
      parking: Car,
    }
    return icons[feature] || Check
  }

  const formatPrice = (price: string, type: string) => {
    return `${price}${type === "month" ? "/month" : ""}`
  }

  const getComparisonValue = (property: Property, feature: string) => {
    switch (feature) {
      case "price":
        return { value: property.price, type: property.priceType }
      case "bedrooms":
        return { value: property.bedrooms, unit: "BR" }
      case "bathrooms":
        return { value: property.bathrooms, unit: "BA" }
      case "area":
        return { value: property.area, unit: "sqft" }
      case "rating":
        return { value: property.rating || 0, unit: "★" }
      case "yearBuilt":
        return { value: property.yearBuilt || "N/A", unit: "" }
      case "parking":
        return { value: property.parkingSpaces || 0, unit: "spaces" }
      case "floor":
        return { value: property.floorNumber || "N/A", unit: `/${property.totalFloors || "N/A"}` }
      default:
        return { value: "N/A", unit: "" }
    }
  }

  const getBestValue = (properties: Property[], feature: string) => {
    if (feature === "price") {
      const prices = properties.map((p) => Number.parseFloat(p.price.replace(/[$,]/g, "")))
      return Math.min(...prices)
    }
    if (feature === "rating") {
      const ratings = properties.map((p) => p.rating || 0)
      return Math.max(...ratings)
    }
    if (feature === "area") {
      const areas = properties.map((p) => p.area)
      return Math.max(...areas)
    }
    return null
  }

  const isBestValue = (property: Property, feature: string) => {
    const bestValue = getBestValue(properties, feature)
    if (bestValue === null) return false

    if (feature === "price") {
      return Number.parseFloat(property.price.replace(/[$,]/g, "")) === bestValue
    }
    if (feature === "rating") {
      return (property.rating || 0) === bestValue
    }
    if (feature === "area") {
      return property.area === bestValue
    }
    return false
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden p-0">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-2xl font-bold text-gray-900">Property Comparison</DialogTitle>
        </DialogHeader>

        <div className="overflow-auto max-h-[calc(90vh-100px)]">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 mx-6 mb-6">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="amenities">Amenities</TabsTrigger>
              <TabsTrigger value="media">Media</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="px-6">
              <div className="grid gap-6" style={{ gridTemplateColumns: `repeat(${properties.length}, 1fr)` }}>
                {properties.map((property) => (
                  <Card key={property.id} className="overflow-hidden">
                    <div className="relative h-48">
                      <Image
                        src={property.image || "/placeholder.svg"}
                        alt={property.title}
                        fill
                        className="object-cover"
                      />
                      {property.rating && (
                        <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full flex items-center gap-1">
                          <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                          <span className="text-xs font-medium">{property.rating}</span>
                        </div>
                      )}
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-bold text-lg mb-2">{property.title}</h3>
                      <div className="flex items-center text-gray-600 mb-3">
                        <MapPin className="h-4 w-4 mr-1" />
                        <span className="text-sm">{property.location}</span>
                      </div>
                      <div className="text-2xl font-bold text-bright-yellow mb-4">
                        {formatPrice(property.price, property.priceType)}
                        {isBestValue(property, "price") && (
                          <Badge className="ml-2 bg-green-100 text-green-800">Best Price</Badge>
                        )}
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div className="text-center">
                          <Bed className="h-4 w-4 mx-auto mb-1 text-gray-400" />
                          <div className="font-medium">{property.bedrooms}</div>
                          <div className="text-gray-500">Bedrooms</div>
                        </div>
                        <div className="text-center">
                          <Bath className="h-4 w-4 mx-auto mb-1 text-gray-400" />
                          <div className="font-medium">{property.bathrooms}</div>
                          <div className="text-gray-500">Bathrooms</div>
                        </div>
                        <div className="text-center">
                          <Square className="h-4 w-4 mx-auto mb-1 text-gray-400" />
                          <div className="font-medium">{property.area}</div>
                          <div className="text-gray-500">Sq Ft</div>
                        </div>
                      </div>
                      <div className="mt-4 flex gap-2">
                        <Link href={`/real-estate/${property.id}`} className="flex-1">
                          <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                            View Details
                          </Button>
                        </Link>
                        <Button variant="outline" size="icon">
                          <Heart className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="details" className="px-6">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-4 font-medium text-gray-900">Feature</th>
                      {properties.map((property) => (
                        <th key={property.id} className="text-center p-4 font-medium text-gray-900 min-w-48">
                          {property.title}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { key: "price", label: "Price", icon: "💰" },
                      { key: "bedrooms", label: "Bedrooms", icon: "🛏️" },
                      { key: "bathrooms", label: "Bathrooms", icon: "🚿" },
                      { key: "area", label: "Area (sq ft)", icon: "📐" },
                      { key: "rating", label: "Rating", icon: "⭐" },
                      { key: "yearBuilt", label: "Year Built", icon: "🏗️" },
                      { key: "parking", label: "Parking Spaces", icon: "🚗" },
                      { key: "floor", label: "Floor", icon: "🏢" },
                    ].map((feature) => (
                      <tr key={feature.key} className="border-b hover:bg-gray-50">
                        <td className="p-4 font-medium text-gray-900">
                          <span className="mr-2">{feature.icon}</span>
                          {feature.label}
                        </td>
                        {properties.map((property) => {
                          const value = getComparisonValue(property, feature.key)
                          const isBest = isBestValue(property, feature.key)
                          return (
                            <td key={property.id} className="p-4 text-center">
                              <div className={`${isBest ? "text-green-600 font-bold" : "text-gray-900"}`}>
                                {feature.key === "price"
                                  ? formatPrice(value.value as string, value.type as string)
                                  : `${value.value}${value.unit ? ` ${value.unit}` : ""}`}
                                {isBest && <Badge className="ml-2 bg-green-100 text-green-800">Best</Badge>}
                              </div>
                            </td>
                          )
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            <TabsContent value="amenities" className="px-6">
              <div className="grid gap-6" style={{ gridTemplateColumns: `repeat(${properties.length}, 1fr)` }}>
                {properties.map((property) => (
                  <Card key={property.id}>
                    <CardHeader>
                      <h3 className="font-bold text-lg">{property.title}</h3>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {[
                          { key: "furnished", label: "Furnished", icon: "🪑" },
                          { key: "petFriendly", label: "Pet Friendly", icon: "🐕" },
                          { key: "balcony", label: "Balcony", icon: "🏡" },
                          { key: "gym", label: "Gym", icon: "💪" },
                          { key: "pool", label: "Swimming Pool", icon: "🏊" },
                          { key: "security", label: "24/7 Security", icon: "🔒" },
                          { key: "elevator", label: "Elevator", icon: "🛗" },
                          { key: "airConditioning", label: "Air Conditioning", icon: "❄️" },
                        ].map((amenity) => (
                          <div key={amenity.key} className="flex items-center justify-between">
                            <span className="flex items-center">
                              <span className="mr-2">{amenity.icon}</span>
                              {amenity.label}
                            </span>
                            {property[amenity.key as keyof Property] ? (
                              <Check className="h-4 w-4 text-green-500" />
                            ) : (
                              <Minus className="h-4 w-4 text-gray-300" />
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="media" className="px-6">
              <div className="grid gap-6" style={{ gridTemplateColumns: `repeat(${properties.length}, 1fr)` }}>
                {properties.map((property) => (
                  <Card key={property.id}>
                    <CardHeader>
                      <h3 className="font-bold text-lg">{property.title}</h3>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="relative h-48 rounded-lg overflow-hidden">
                          <Image
                            src={property.image || "/placeholder.svg"}
                            alt={property.title}
                            fill
                            className="object-cover"
                          />
                        </div>
                        {property.video && (
                          <div className="relative h-48 rounded-lg overflow-hidden">
                            <VideoPlayer src={property.video} className="h-full" poster={property.image} />
                          </div>
                        )}
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="flex-1">
                            <Eye className="h-4 w-4 mr-2" />
                            Virtual Tour
                          </Button>
                          <Button variant="outline" size="sm" className="flex-1">
                            <Calendar className="h-4 w-4 mr-2" />
                            Schedule Visit
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  )
}
