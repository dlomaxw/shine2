"use client"

import { useRef, useEffect, type ReactNode } from "react"
import { cn } from "@/lib/utils"

interface ParallaxSectionProps {
  children: ReactNode
  className?: string
  speed?: number
  direction?: "up" | "down" | "left" | "right"
}

export default function ParallaxSection({ children, className, speed = 0.5, direction = "up" }: ParallaxSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const section = sectionRef.current
    if (!section) return

    const handleScroll = () => {
      const scrollPosition = window.scrollY
      const sectionTop = section.offsetTop
      const sectionHeight = section.offsetHeight
      const windowHeight = window.innerHeight

      // Check if section is in viewport
      if (scrollPosition + windowHeight > sectionTop && scrollPosition < sectionTop + sectionHeight) {
        const relativeScroll = scrollPosition - sectionTop + windowHeight
        const percentage = relativeScroll / (sectionHeight + windowHeight)

        let translateValue = percentage * 100 * speed

        // Limit the translation to avoid too much movement
        translateValue = Math.max(-50, Math.min(translateValue, 50))

        let transform = ""
        switch (direction) {
          case "up":
            transform = `translateY(${-translateValue}px)`
            break
          case "down":
            transform = `translateY(${translateValue}px)`
            break
          case "left":
            transform = `translateX(${-translateValue}px)`
            break
          case "right":
            transform = `translateX(${translateValue}px)`
            break
        }

        section.style.transform = transform
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [speed, direction])

  return (
    <div ref={sectionRef} className={cn("transition-transform duration-300 ease-out", className)}>
      {children}
    </div>
  )
}
