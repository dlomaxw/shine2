"use client"

import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { ArrowRight } from "lucide-react"

interface FuturisticCardProps {
  title: string
  description: string
  category: string
  image: string
  href: string
  glowColor?: string
}

export default function FuturisticCard({
  title,
  description,
  category,
  image,
  href,
  glowColor = "rgba(255, 255, 255, 0.2)",
}: FuturisticCardProps) {
  return (
    <Link href={href} className="block w-full h-full">
      <motion.div
        whileHover={{ y: -5 }}
        transition={{ duration: 0.2 }}
        className="relative h-full overflow-hidden rounded-lg group cursor-pointer"
      >
        {/* Image */}
        <div className="relative h-64 w-full overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-t from-bright-black to-transparent opacity-60 z-10"></div>
          <Image
            src={image || "/placeholder.svg"}
            alt={title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            priority
          />
        </div>

        {/* Content */}
        <div className="relative z-20 p-5 bg-bright-black border border-bright-yellow/20">
          <div className="text-sm font-medium text-bright-yellow mb-2">{category}</div>
          <h3 className="text-xl font-bold text-bright-white mb-2">{title}</h3>
          <p className="text-bright-white/70 text-sm mb-4 line-clamp-2">{description}</p>
          <div className="flex items-center text-bright-yellow font-medium">
            <span>View Project</span>
            <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        {/* Glow effect */}
        <div
          className="absolute -bottom-2 left-0 right-0 h-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          style={{ backgroundColor: glowColor }}
        ></div>
      </motion.div>
    </Link>
  )
}
