"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Upload, X, ImageIcon, FileText, Video, Check } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"
import { cn } from "@/lib/utils"

interface MediaUploadProps {
  onUpload?: (files: File[]) => void
  maxFiles?: number
  acceptedTypes?: string[]
  maxSizeMB?: number
  className?: string
}

export default function MediaUpload({
  onUpload,
  maxFiles = 5,
  acceptedTypes = ["image/*", "video/*", "application/pdf"],
  maxSizeMB = 10,
  className,
}: MediaUploadProps) {
  const [isDragging, setIsDragging] = useState(false)
  const [files, setFiles] = useState<File[]>([])
  const [previews, setPreviews] = useState<string[]>([])
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState<number[]>([])
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    const droppedFiles = Array.from(e.dataTransfer.files)
    handleFiles(droppedFiles)
  }

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files)
      handleFiles(selectedFiles)
    }
  }

  const handleFiles = (newFiles: File[]) => {
    // Filter files by accepted types
    const filteredFiles = newFiles.filter((file) => {
      const fileType = file.type
      return acceptedTypes.some((type) => {
        if (type.endsWith("/*")) {
          const category = type.split("/")[0]
          return fileType.startsWith(`${category}/`)
        }
        return type === fileType
      })
    })

    // Filter files by size
    const validFiles = filteredFiles.filter((file) => {
      const fileSizeMB = file.size / (1024 * 1024)
      if (fileSizeMB > maxSizeMB) {
        toast({
          title: "File too large",
          description: `${file.name} exceeds the maximum size of ${maxSizeMB}MB.`,
          variant: "destructive",
        })
        return false
      }
      return true
    })

    // Check if adding these files would exceed the max files limit
    if (files.length + validFiles.length > maxFiles) {
      toast({
        title: "Too many files",
        description: `You can only upload a maximum of ${maxFiles} files.`,
        variant: "destructive",
      })
      return
    }

    // Create previews for valid files
    const newPreviews: string[] = []

    validFiles.forEach((file) => {
      if (file.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          if (e.target?.result) {
            newPreviews.push(e.target.result as string)
            if (newPreviews.length === validFiles.length) {
              setPreviews((prev) => [...prev, ...newPreviews])
            }
          }
        }
        reader.readAsDataURL(file)
      } else if (file.type.startsWith("video/")) {
        newPreviews.push("video")
      } else {
        newPreviews.push("file")
      }
    })

    // Update files state
    setFiles((prev) => [...prev, ...validFiles])

    // Initialize upload progress for new files
    setUploadProgress((prev) => [...prev, ...Array(validFiles.length).fill(0)])

    // Call onUpload callback if provided
    if (onUpload && validFiles.length > 0) {
      onUpload(validFiles)
    }

    // Simulate upload progress
    simulateUpload(files.length, validFiles.length)
  }

  const simulateUpload = (startIndex: number, count: number) => {
    if (count === 0) return

    setIsUploading(true)

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        const newProgress = [...prev]
        let allComplete = true

        for (let i = startIndex; i < startIndex + count; i++) {
          if (newProgress[i] < 100) {
            newProgress[i] += 10
            allComplete = false
          }
        }

        if (allComplete) {
          clearInterval(interval)
          setIsUploading(false)

          toast({
            title: "Upload complete",
            description: `Successfully uploaded ${count} file${count > 1 ? "s" : ""}.`,
          })
        }

        return newProgress
      })
    }, 300)
  }

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
    setPreviews((prev) => prev.filter((_, i) => i !== index))
    setUploadProgress((prev) => prev.filter((_, i) => i !== index))
  }

  const getFileIcon = (file: File) => {
    if (file.type.startsWith("image/")) {
      return <ImageIcon className="h-6 w-6" />
    } else if (file.type.startsWith("video/")) {
      return <Video className="h-6 w-6" />
    } else {
      return <FileText className="h-6 w-6" />
    }
  }

  return (
    <div className={cn("space-y-4", className)}>
      <div
        className={cn(
          "border-2 border-dashed rounded-lg p-8 text-center transition-colors",
          isDragging ? "border-bright-yellow bg-bright-yellow/5" : "border-bright-yellow/20",
          "hover:border-bright-yellow/50 hover:bg-bright-yellow/5",
        )}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileInputChange}
          multiple
          accept={acceptedTypes.join(",")}
          className="hidden"
        />

        <div className="flex flex-col items-center justify-center">
          <Upload className={cn("h-10 w-10 mb-2", isDragging ? "text-bright-yellow" : "text-bright-white/50")} />
          <p className="text-bright-white mb-1">
            {isDragging ? "Drop files here" : "Drag and drop files here, or click to select"}
          </p>
          <p className="text-bright-white/50 text-sm">
            Max {maxFiles} files, up to {maxSizeMB}MB each
          </p>
        </div>
      </div>

      {files.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-bright-white">
            Uploaded Files ({files.length}/{maxFiles})
          </h3>

          <AnimatePresence>
            {files.map((file, index) => (
              <motion.div
                key={`${file.name}-${index}`}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -10 }}
                className="flex items-center justify-between p-3 bg-bright-black/30 rounded-md border border-bright-yellow/10"
              >
                <div className="flex items-center">
                  {previews[index] && previews[index] !== "video" && previews[index] !== "file" ? (
                    <div className="h-10 w-10 rounded overflow-hidden mr-3 bg-bright-black/50">
                      <img
                        src={previews[index] || "/placeholder.svg"}
                        alt={file.name}
                        className="h-full w-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="h-10 w-10 rounded overflow-hidden mr-3 bg-bright-black/50 flex items-center justify-center">
                      {getFileIcon(file)}
                    </div>
                  )}

                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-bright-white truncate">{file.name}</p>
                    <p className="text-xs text-bright-white/50">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
                  </div>
                </div>

                <div className="flex items-center">
                  {uploadProgress[index] < 100 ? (
                    <div className="w-16 bg-bright-black/50 rounded-full h-2 mr-3">
                      <div
                        className="bg-bright-yellow h-2 rounded-full"
                        style={{ width: `${uploadProgress[index]}%` }}
                      ></div>
                    </div>
                  ) : (
                    <Check className="h-5 w-5 text-green-500 mr-3" />
                  )}

                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-bright-white/70 hover:text-bright-white"
                    onClick={() => removeFile(index)}
                    disabled={isUploading && uploadProgress[index] < 100}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  )
}
