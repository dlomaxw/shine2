"use client"

import type React from "react"

import { useState } from "react"
import { Bot, Send, X } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

export default function AIChatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState([
    { role: "system", content: "Hello! I'm Bright's AI assistant. How can I help you today?" },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!input.trim()) return

    // Add user message
    const userMessage = { role: "user", content: input }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    // Simulate AI response (this will be replaced with actual AI integration in Phase 4)
    setTimeout(() => {
      let response

      if (input.toLowerCase().includes("property") || input.toLowerCase().includes("real estate")) {
        response = {
          role: "system",
          content:
            "We offer virtual property tours and 3D visualizations for real estate. Would you like to see some examples or schedule a demo?",
        }
      } else if (input.toLowerCase().includes("vr") || input.toLowerCase().includes("virtual reality")) {
        response = {
          role: "system",
          content:
            "Our VR solutions include training simulations, virtual property tours, and immersive entertainment experiences. How can we help with your VR needs?",
        }
      } else if (input.toLowerCase().includes("price") || input.toLowerCase().includes("cost")) {
        response = {
          role: "system",
          content:
            "Our pricing varies based on project requirements. Would you like to speak with a sales representative to get a custom quote?",
        }
      } else {
        response = {
          role: "system",
          content:
            "Thank you for your message. One of our team members will follow up with more information. Can I help you with anything else?",
        }
      }

      setMessages((prev) => [...prev, response])
      setIsTyping(false)
    }, 1500)
  }

  return (
    <>
      {/* Floating chat button */}
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 rounded-full p-4 shadow-lg z-50"
        size="icon"
      >
        <Bot className="h-6 w-6" />
      </Button>

      {/* Chat window */}
      {isOpen && (
        <Card className="fixed bottom-20 right-4 w-80 md:w-96 shadow-xl z-50 border-primary/10">
          <CardHeader className="bg-primary text-primary-foreground py-3 px-4 flex flex-row justify-between items-center">
            <h3 className="font-medium">Bright Assistant</h3>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(false)}
              className="h-8 w-8 text-primary-foreground"
            >
              <X className="h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="p-4 h-80 overflow-y-auto flex flex-col gap-3">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`${
                  message.role === "user" ? "bg-primary/10 ml-auto" : "bg-slate-100"
                } rounded-lg p-3 max-w-[80%]`}
              >
                {message.content}
              </div>
            ))}
            {isTyping && (
              <div className="bg-slate-100 rounded-lg p-3 max-w-[80%] flex gap-1">
                <span className="animate-bounce">.</span>
                <span className="animate-bounce delay-75">.</span>
                <span className="animate-bounce delay-150">.</span>
              </div>
            )}
          </CardContent>
          <CardFooter className="p-3 border-t">
            <form onSubmit={handleSendMessage} className="flex w-full gap-2">
              <Input
                placeholder="Type your message..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" size="icon" disabled={isTyping}>
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardFooter>
        </Card>
      )}
    </>
  )
}
