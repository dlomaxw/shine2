"use client"

import { useEffect, useRef, useState } from "react"
import { cn } from "@/lib/utils"

interface AnimatedTextProps {
  text: string
  className?: string
  once?: boolean
  delay?: number
  speed?: number
  tag?: "h1" | "h2" | "h3" | "h4" | "h5" | "h6" | "p" | "span"
}

export default function AnimatedText({
  text,
  className,
  once = true,
  delay = 0,
  speed = 50,
  tag: Tag = "span",
}: AnimatedTextProps) {
  const [displayedText, setDisplayedText] = useState("")
  const [isAnimating, setIsAnimating] = useState(false)
  const elementRef = useRef<HTMLElement>(null)
  const [isInView, setIsInView] = useState(false)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true)
          if (once) {
            observer.disconnect()
          }
        } else {
          if (!once) {
            setIsInView(false)
          }
        }
      },
      { threshold: 0.1 },
    )

    if (elementRef.current) {
      observer.observe(elementRef.current)
    }

    return () => observer.disconnect()
  }, [once])

  useEffect(() => {
    if (!isInView) {
      if (!once) {
        setDisplayedText("")
      }
      return
    }

    if (displayedText === text) {
      setIsAnimating(false)
      return
    }

    setIsAnimating(true)
    const timeout = setTimeout(() => {
      const nextChar = text.charAt(displayedText.length)
      setDisplayedText((prev) => prev + nextChar)
    }, speed)

    return () => clearTimeout(timeout)
  }, [displayedText, isInView, once, speed, text])

  useEffect(() => {
    if (isInView && delay > 0) {
      const delayTimeout = setTimeout(() => {
        setDisplayedText("")
      }, delay)

      return () => clearTimeout(delayTimeout)
    }
  }, [delay, isInView])

  return (
    <Tag ref={elementRef} className={cn("inline-block", className)}>
      {displayedText}
      {isAnimating && (
        <span className="inline-block w-[0.1em] h-[1.1em] bg-bright-yellow animate-pulse-soft ml-0.5 align-middle" />
      )}
    </Tag>
  )
}
