"use client"

import { useState, useRef, useEffect } from "react"
import { ChevronLeft, ChevronRight, Play, Pause, User } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"

interface Video {
  src: string
  poster?: string
  alt: string
  title?: string
  description?: string
  owner?: string
}

interface EnhancedVideoCarouselProps {
  videos: Video[]
  height?: string
  autoplay?: boolean
  interval?: number
  showControls?: boolean
  showIndicators?: boolean
  overlay?: boolean
  showOwnerCard?: boolean
}

export default function EnhancedVideoCarousel({
  videos,
  height = "h-[60vh]",
  autoplay = true,
  interval = 8000,
  showControls = true,
  showIndicators = true,
  overlay = true,
  showOwnerCard = false,
}: EnhancedVideoCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(autoplay)
  const videoRefs = useRef<(HTMLVideoElement | null)[]>([])
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Initialize video refs array
  useEffect(() => {
    videoRefs.current = videoRefs.current.slice(0, videos.length)
  }, [videos.length])

  // Handle autoplay and video transitions
  useEffect(() => {
    if (isPlaying) {
      // Start the current video
      const currentVideo = videoRefs.current[currentIndex]
      if (currentVideo) {
        currentVideo.play().catch((error) => {
          console.error("Video play failed:", error)
          setIsPlaying(false)
        })
      }

      // Set timeout for next video
      if (autoplay) {
        timeoutRef.current = setTimeout(() => {
          goToNext()
        }, interval)
      }
    } else {
      // Pause the current video
      const currentVideo = videoRefs.current[currentIndex]
      if (currentVideo) {
        currentVideo.pause()
      }

      // Clear any existing timeout
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }

    // Cleanup function
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [currentIndex, isPlaying, autoplay, interval])

  const goToPrevious = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? videos.length - 1 : prevIndex - 1))
  }

  const goToNext = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }
    setCurrentIndex((prevIndex) => (prevIndex === videos.length - 1 ? 0 : prevIndex + 1))
  }

  const goToIndex = (index: number) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current)
    }
    setCurrentIndex(index)
  }

  const togglePlayPause = () => {
    setIsPlaying(!isPlaying)
  }

  return (
    <div className={`relative ${height} w-full overflow-hidden bg-bright-black`}>
      {/* Videos */}
      {videos.map((video, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0"
          }`}
        >
          <video
            ref={(el) => (videoRefs.current[index] = el)}
            src={video.src}
            poster={video.poster}
            className="w-full h-full object-cover"
            muted
            loop
            playsInline
            preload="metadata"
          />

          {/* Overlay */}
          {overlay && (
            <div className="absolute inset-0 bg-gradient-to-t from-bright-black via-transparent to-transparent opacity-70"></div>
          )}

          {/* Video Info */}
          <AnimatePresence>
            {index === currentIndex && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
                className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 z-20"
              >
                <div className="container mx-auto">
                  <div className="max-w-2xl">
                    {video.title && (
                      <h3 className="text-xl sm:text-2xl font-bold text-bright-white mb-2">{video.title}</h3>
                    )}
                    {video.description && (
                      <p className="text-sm sm:text-base text-bright-white/80 mb-4">{video.description}</p>
                    )}

                    {/* Owner Card */}
                    {showOwnerCard && video.owner && (
                      <div className="flex items-center mt-4">
                        <div className="bg-bright-yellow/20 p-2 rounded-full">
                          <User className="h-4 w-4 sm:h-5 sm:w-5 text-bright-yellow" />
                        </div>
                        <div className="ml-3">
                          <p className="text-xs sm:text-sm text-bright-white/60">Created by</p>
                          <p className="text-sm sm:text-base font-medium text-bright-white">{video.owner}</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}

      {/* Controls */}
      {showControls && (
        <div className="absolute bottom-4 right-4 sm:bottom-6 sm:right-6 z-30 flex items-center space-x-2">
          <Button
            size="icon"
            variant="outline"
            className="bg-bright-black/50 border-bright-white/20 text-bright-white hover:bg-bright-black/70 hover:text-bright-yellow"
            onClick={togglePlayPause}
          >
            {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <Button
            size="icon"
            variant="outline"
            className="bg-bright-black/50 border-bright-white/20 text-bright-white hover:bg-bright-black/70 hover:text-bright-yellow"
            onClick={goToPrevious}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="outline"
            className="bg-bright-black/50 border-bright-white/20 text-bright-white hover:bg-bright-black/70 hover:text-bright-yellow"
            onClick={goToNext}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Indicators */}
      {showIndicators && (
        <div className="absolute bottom-4 left-0 right-0 z-30 flex justify-center">
          <div className="flex space-x-2">
            {videos.map((_, index) => (
              <button
                key={index}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentIndex ? "bg-bright-yellow w-4" : "bg-bright-white/50 hover:bg-bright-white/80"
                }`}
                onClick={() => goToIndex(index)}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
