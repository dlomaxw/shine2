"use client"

import { useState } from "react"
import { ThumbsUpIcon as ThumbUp, ThumbsDownIcon as ThumbDown } from "lucide-react"

export default function FeedbackWidget() {
  const [feedback, setFeedback] = useState<boolean | null>(null)

  const handleFeedback = (isPositive: boolean) => {
    setFeedback(isPositive)
    // Simulate sending feedback (replace with actual API call in Phase 2)
    console.log(`Feedback submitted: ${isPositive ? "Positive" : "Negative"}`)
    setTimeout(() => {
      setFeedback(null)
    }, 2000)
  }

  return (
    <div className="fixed bottom-4 left-4 bg-bright-black/50 backdrop-blur-sm p-3 rounded-md shadow-lg z-50">
      <p className="text-sm text-bright-white/70 mb-2">Was this site helpful?</p>
      <div className="flex space-x-2">
        <button
          onClick={() => handleFeedback(true)}
          className={`p-2 rounded-md hover:bg-green-500/20 ${feedback === true ? "bg-green-500/50" : ""}`}
          aria-label="Yes"
          disabled={feedback !== null}
        >
          <ThumbUp className="h-5 w-5 text-bright-white" />
        </button>
        <button
          onClick={() => handleFeedback(false)}
          className={`p-2 rounded-md hover:bg-red-500/20 ${feedback === false ? "bg-red-500/50" : ""}`}
          aria-label="No"
          disabled={feedback !== null}
        >
          <ThumbDown className="h-5 w-5 text-bright-white" />
        </button>
      </div>
    </div>
  )
}
