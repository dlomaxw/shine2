"use client"

import type React from "react"

import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface IndustryCardProps {
  title: string
  description: string
  icon: React.ReactNode
  href: string
  gradient?: string
}

export default function IndustryCard({ title, description, icon, href, gradient }: IndustryCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
      className="group"
    >
      <Link href={href}>
        <Card className="h-full bg-bright-white border-2 border-transparent hover:border-bright-yellow transition-all duration-300 cursor-pointer group-hover:shadow-xl">
          <CardContent className="p-8 h-full flex flex-col">
            <div className="mb-6">
              <div
                className={`w-16 h-16 rounded-full bg-gradient-to-r ${gradient || "from-bright-yellow to-bright-yellow"} flex items-center justify-center mb-4`}
              >
                <div className="text-bright-black">{icon}</div>
              </div>
              <h3 className="text-2xl font-bold text-bright-black mb-3 group-hover:text-bright-yellow transition-colors">
                {title}
              </h3>
              <p className="text-bright-black/70 leading-relaxed flex-grow">{description}</p>
            </div>
            <div className="mt-auto">
              <Button
                variant="ghost"
                className="group/btn text-bright-black hover:text-bright-yellow p-0 h-auto font-semibold"
              >
                Learn More
                <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  )
}
