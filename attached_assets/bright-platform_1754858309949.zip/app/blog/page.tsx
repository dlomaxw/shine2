import Image from "next/image"
import Link from "next/link"
import { ArrowRight, Calendar, User } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

export default function BlogPage() {
  // Sample blog posts data
  const blogPosts = [
    {
      id: 1,
      title: "The Future of Virtual Reality in Real Estate Marketing",
      excerpt:
        "Explore how VR is transforming property marketing and sales, creating immersive experiences for potential buyers.",
      image: "/images/building1.webp",
      category: "Real Estate",
      author: "Sarah Johnson",
      date: "March 15, 2023",
      readTime: "5 min read",
    },
    {
      id: 2,
      title: "How Immersive Training is Revolutionizing Employee Development",
      excerpt:
        "Discover the impact of VR/AR training solutions on employee skill development, safety, and knowledge retention.",
      image: "/images/building2.webp",
      category: "Training",
      author: "Michael Chen",
      date: "April 22, 2023",
      readTime: "7 min read",
    },
    {
      id: 3,
      title: "The Rise of Virtual Production in Film and Media",
      excerpt:
        "Learn how virtual production techniques are changing the landscape of film, television, and advertising.",
      image: "/images/building3.webp",
      category: "Media & Entertainment",
      author: "Priya Patel",
      date: "May 10, 2023",
      readTime: "6 min read",
    },
    {
      id: 4,
      title: "Creating Effective Virtual Collaboration Spaces for Remote Teams",
      excerpt:
        "Tips and best practices for designing virtual environments that enhance remote team collaboration and productivity.",
      image: "/images/building4.webp",
      category: "Corporate",
      author: "David Wilson",
      date: "June 5, 2023",
      readTime: "8 min read",
    },
    {
      id: 5,
      title: "The Psychology of Immersive Experiences: Why VR Works",
      excerpt:
        "Exploring the psychological factors that make virtual reality such a powerful tool for engagement and learning.",
      image: "/images/building5.webp",
      category: "Research",
      author: "Emma Rodriguez",
      date: "July 18, 2023",
      readTime: "10 min read",
    },
    {
      id: 6,
      title: "Augmented Reality in Retail: Enhancing the Shopping Experience",
      excerpt:
        "How retailers are using AR to create interactive shopping experiences and drive sales both online and in-store.",
      image: "/images/building6.webp",
      category: "Digital",
      author: "James Kim",
      date: "August 30, 2023",
      readTime: "6 min read",
    },
  ]

  // Categories for filter
  const categories = ["All", "Real Estate", "Training", "Media & Entertainment", "Corporate", "Digital", "Research"]

  return (
    <main className="flex-1">
      <section className="bg-slate-50 py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Bright Blog</h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                Insights, trends, and thought leadership on immersive technology and its applications.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-1 gap-12 md:grid-cols-4">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <div className="sticky top-24 space-y-8">
                {/* Search */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Search</h3>
                  <div className="flex">
                    <Input placeholder="Search articles..." className="rounded-r-none" />
                    <Button className="rounded-l-none">
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {/* Categories */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Categories</h3>
                  <ul className="space-y-2">
                    {categories.map((category) => (
                      <li key={category}>
                        <Link
                          href={`/blog?category=${category === "All" ? "" : category}`}
                          className="text-muted-foreground hover:text-bright-yellow transition-colors"
                        >
                          {category}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Recent Posts */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Recent Posts</h3>
                  <ul className="space-y-4">
                    {blogPosts.slice(0, 3).map((post) => (
                      <li key={post.id} className="flex gap-3">
                        <div className="relative h-16 w-16 flex-shrink-0 overflow-hidden rounded-md">
                          <Image
                            src={post.image || "/placeholder.svg"}
                            alt={post.title}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <Link
                            href={`/blog/${post.id}`}
                            className="line-clamp-2 font-medium hover:text-bright-yellow transition-colors"
                          >
                            {post.title}
                          </Link>
                          <p className="text-xs text-muted-foreground">{post.date}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Main Content */}
            <div className="md:col-span-3">
              <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
                {blogPosts.map((post) => (
                  <Card key={post.id} className="overflow-hidden border-none shadow-md h-full">
                    <div className="relative h-48 w-full overflow-hidden">
                      <Image
                        src={post.image || "/placeholder.svg"}
                        alt={post.title}
                        fill
                        className="object-cover transition-transform duration-300 hover:scale-105"
                      />
                      <div className="absolute top-4 left-4">
                        <span className="rounded-full bg-bright-yellow px-3 py-1 text-xs font-medium text-bright-black">
                          {post.category}
                        </span>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                        <div className="flex items-center">
                          <Calendar className="mr-1 h-3 w-3" />
                          {post.date}
                        </div>
                        <span>•</span>
                        <div className="flex items-center">
                          <User className="mr-1 h-3 w-3" />
                          {post.author}
                        </div>
                      </div>
                      <Link href={`/blog/${post.id}`}>
                        <h3 className="mb-2 text-xl font-semibold hover:text-bright-yellow transition-colors">
                          {post.title}
                        </h3>
                      </Link>
                      <p className="mb-4 text-muted-foreground line-clamp-3">{post.excerpt}</p>
                      <Link
                        href={`/blog/${post.id}`}
                        className="inline-flex items-center text-bright-yellow hover:underline"
                      >
                        Read More <ArrowRight className="ml-1 h-3 w-3" />
                      </Link>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Pagination */}
              <div className="mt-12 flex justify-center">
                <div className="flex space-x-2">
                  <Button variant="outline" disabled>
                    Previous
                  </Button>
                  <Button variant="outline" className="bg-bright-yellow text-bright-black border-bright-yellow">
                    1
                  </Button>
                  <Button variant="outline">2</Button>
                  <Button variant="outline">3</Button>
                  <Button variant="outline">Next</Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
