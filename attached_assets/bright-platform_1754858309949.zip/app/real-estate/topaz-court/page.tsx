"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Check, MapPin, Home, Play, Building2, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ContactForm from "@/components/contact-form"
import ContactCTA from "@/components/contact-cta"
import VideoPlayer from "@/components/video-player"

export default function TopazCourtPage() {
  const unitTypes = [
    {
      type: "2 Bedroom Apartment",
      bedrooms: 2,
      size: "110 sqm",
      price: "$145,000",
      description: "Elegant 2-bedroom apartment with modern amenities and premium finishes",
      features: [
        "Master bedroom with en-suite",
        "Guest bedroom",
        "Open-plan living",
        "Modern kitchen",
        "Private balcony",
      ],
    },
    {
      type: "3 Bedroom Apartment",
      bedrooms: 3,
      size: "150 sqm",
      price: "$185,000",
      description: "Spacious 3-bedroom apartment with luxury features and stunning views",
      features: [
        "Three bedrooms with built-ins",
        "Two bathrooms",
        "Large living/dining",
        "Premium appliances",
        "Balcony with views",
      ],
    },
  ]

  const amenities = [
    { name: "Rooftop Pool", description: "Infinity pool with city views" },
    { name: "Fitness Center", description: "State-of-the-art gym equipment" },
    { name: "Concierge Service", description: "24/7 professional concierge" },
    { name: "Secure Parking", description: "Underground parking spaces" },
    { name: "Business Center", description: "Professional meeting spaces" },
    { name: "Landscaped Gardens", description: "Beautiful outdoor spaces" },
    { name: "Children's Area", description: "Safe play zone for kids" },
    { name: "Security", description: "24/7 security and surveillance" },
  ]

  return (
    <main className="flex min-h-screen flex-col bg-bright-black text-bright-white">
      {/* Hero Section */}
      <section className="relative min-h-screen bg-bright-black overflow-hidden">
        <div className="absolute inset-0">
          <Image
            src="/images/topaz-court-exterior.png"
            alt="Topaz Court - Luxury Apartments"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-r from-bright-black via-bright-black/80 to-transparent"></div>
        </div>

        <div className="relative z-10 container mx-auto px-4 min-h-screen flex items-center">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <div className="inline-flex items-center px-4 py-2 bg-bright-yellow/10 border border-bright-yellow/20 rounded-full">
                <Building2 className="h-4 w-4 text-bright-yellow mr-2" />
                <span className="text-bright-yellow font-medium">Luxury Living</span>
              </div>

              <div>
                <h1 className="text-4xl md:text-6xl font-bold text-bright-white mb-4">
                  <span className="relative inline-block">
                    <span className="relative z-10">Topaz</span>
                    <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                  </span>
                  <br />
                  <span className="text-bright-yellow">Court</span>
                </h1>
                <h2 className="text-xl md:text-2xl text-bright-yellow/80 font-medium mb-2">Luxury Apartment Complex</h2>
                <p className="text-lg text-bright-white/70 italic">"Modern amenities and elegant design"</p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Home className="h-5 w-5 text-bright-yellow mr-2" />
                    <span className="text-bright-white font-medium">Unit Types</span>
                  </div>
                  <p className="text-bright-white/70">2 & 3 bedroom apartments</p>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <Users className="h-5 w-5 text-bright-yellow mr-2" />
                    <span className="text-bright-white font-medium">Starting Price</span>
                  </div>
                  <p className="text-bright-yellow font-bold text-xl">$145,000</p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 font-medium">
                  Schedule Viewing
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-bright-white text-bright-white hover:bg-bright-white/10"
                >
                  Download Brochure
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20 px-4 md:px-6 lg:px-8 bg-bright-black">
        <div className="container mx-auto">
          <Link href="/real-estate" className="flex items-center text-muted-foreground hover:text-bright-yellow mb-12">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Real Estate Projects
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-12">
              {/* Virtual Tour Section */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Virtual Tour</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="relative h-[400px] md:h-[500px] rounded-lg overflow-hidden mb-6">
                  <VideoPlayer
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/topaz%20court-IarahXii0RQiQnxicNfBPprqR1bM6w.webm"
                    title="Topaz Court Virtual Tour"
                    className="h-full"
                    poster="/images/topaz-court-exterior.png"
                  />
                </div>

                <div className="bg-bright-black/50 border border-bright-yellow/20 rounded-lg p-6">
                  <div className="flex items-center mb-3">
                    <Play className="h-5 w-5 text-bright-yellow mr-2" />
                    <h3 className="text-bright-white font-bold">Explore Topaz Court</h3>
                  </div>
                  <p className="text-bright-white/70">
                    Take an immersive virtual tour of Topaz Court and discover the luxury apartments, modern amenities,
                    and elegant design that define this exceptional development.
                  </p>
                </div>
              </div>

              {/* Overview */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Project Overview</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="prose prose-lg prose-invert max-w-none">
                  <p>
                    Topaz Court represents a new standard in luxury apartment living, featuring modern amenities and
                    elegant design throughout. This exceptional development offers sophisticated 2 and 3 bedroom
                    apartments designed for discerning residents who appreciate quality and style.
                  </p>
                  <p>
                    Each apartment at Topaz Court is meticulously crafted with premium finishes, contemporary fixtures,
                    and thoughtful layouts that maximize both comfort and functionality. The development features
                    world-class amenities including a rooftop pool, fitness center, and 24/7 concierge service.
                  </p>
                </div>
              </div>

              {/* Unit Types */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Unit Types & Pricing</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {unitTypes.map((unit, index) => (
                    <Card key={index} className="bg-bright-black/50 border-bright-yellow/20 overflow-hidden">
                      <CardContent className="p-6">
                        <h3 className="text-xl font-bold mb-2 text-bright-white">{unit.type}</h3>
                        <div className="flex items-center space-x-4 mb-3">
                          <div className="flex items-center">
                            <Home className="h-4 w-4 text-bright-yellow mr-1" />
                            <span className="text-bright-white/70">{unit.bedrooms} BR</span>
                          </div>
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 text-bright-yellow mr-1" />
                            <span className="text-bright-white/70">{unit.size}</span>
                          </div>
                        </div>
                        <p className="text-bright-yellow font-bold text-lg mb-3">{unit.price}</p>
                        <p className="text-bright-white/70 mb-4 text-sm">{unit.description}</p>
                        <div className="space-y-2">
                          {unit.features.map((feature, idx) => (
                            <div key={idx} className="flex items-center">
                              <Check className="h-3 w-3 text-bright-yellow mr-2 flex-shrink-0" />
                              <span className="text-bright-white/80 text-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Amenities */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Luxury Amenities</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {amenities.map((amenity, index) => (
                    <div key={index} className="flex items-start p-4 border border-bright-yellow/20 rounded-lg">
                      <Check className="h-5 w-5 text-bright-yellow mr-3 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-bright-white">{amenity.name}</h4>
                        <p className="text-bright-white/70 text-sm">{amenity.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-8">
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Pricing Information</h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-bright-white/70 text-sm">Starting Price</p>
                      <p className="text-bright-yellow text-2xl font-bold">$145,000</p>
                    </div>
                    <div>
                      <p className="text-bright-white/70 text-sm">Unit Types</p>
                      <p className="text-bright-white font-medium">2 & 3 Bedroom Apartments</p>
                    </div>
                    <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                      Schedule Viewing
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Interested in Topaz Court?</h3>
                  <ContactForm propertyId="topaz-court" propertyTitle="Topaz Court" simplified />
                </CardContent>
              </Card>

              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Virtual Experience</h3>
                  <div className="relative h-48 rounded-lg overflow-hidden mb-4">
                    <VideoPlayer
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/topaz%20court-IarahXii0RQiQnxicNfBPprqR1bM6w.webm"
                      title="Virtual Tour"
                      className="h-full"
                      poster="/images/topaz-court-exterior.png"
                    />
                  </div>
                  <p className="text-bright-white/70 text-sm">
                    Experience Topaz Court through our immersive virtual tour showcasing the luxury amenities and
                    elegant design.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
