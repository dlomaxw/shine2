"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, MapPin, DollarSign, Home, Calendar, Share2, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import VideoPlayer from "@/components/video-player"
import ContactCTA from "@/components/contact-cta"

export default function GatesSpringPage() {
  const propertyImages = ["/images/building3.webp", "/images/building1.webp", "/images/building2.webp"]

  const propertyFeatures = [
    "Family-oriented community",
    "Landscaped environments",
    "Children's play areas",
    "Community center",
    "24/7 security",
    "Parking facilities",
    "Green spaces",
    "Modern amenities",
  ]

  const unitTypes = [
    {
      type: "2 Bedroom",
      area: "1,100 sqft",
      price: "$95,000",
      features: ["2 bedrooms", "2 bathrooms", "Living room", "Kitchen", "Balcony"],
    },
    {
      type: "3 Bedroom",
      area: "1,400 sqft",
      price: "$125,000",
      features: ["3 bedrooms", "2 bathrooms", "Living room", "Kitchen", "Balcony", "Study room"],
    },
  ]

  return (
    <main className="min-h-screen bg-bright-black text-bright-white">
      {/* Navigation */}
      <div className="container mx-auto px-4 py-6">
        <Link href="/real-estate" className="flex items-center text-bright-white/70 hover:text-bright-yellow">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Properties
        </Link>
      </div>

      {/* Hero Section */}
      <section className="relative h-[70vh] overflow-hidden">
        <VideoPlayer
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/gates%20spring%201-6QMh83Ksu3HDdVNpJaIp7banpIRJ6u.webm"
          className="h-full"
          poster="/images/building3.webp"
          autoplay={true}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bright-black via-bright-black/50 to-transparent" />

        <div className="absolute bottom-8 left-8 right-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-2xl"
          >
            <Badge className="bg-green-500 text-white mb-4">Available</Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-4">Gates Spring</h1>
            <p className="text-xl text-bright-white/90 mb-6">
              Family-oriented residential community with landscaped environments
            </p>
            <div className="flex items-center gap-6 text-bright-white/80">
              <div className="flex items-center">
                <MapPin className="h-5 w-5 mr-2 text-bright-yellow" />
                <span>Spring Valley</span>
              </div>
              <div className="flex items-center">
                <DollarSign className="h-5 w-5 mr-2 text-bright-yellow" />
                <span>Starting from $95,000</span>
              </div>
              <div className="flex items-center">
                <Home className="h-5 w-5 mr-2 text-bright-yellow" />
                <span>2, 3 BR</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Property Details */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="grid w-full grid-cols-4 bg-bright-black/50 border border-bright-yellow/20">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="units">Unit Types</TabsTrigger>
                  <TabsTrigger value="amenities">Amenities</TabsTrigger>
                  <TabsTrigger value="gallery">Gallery</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="mt-8">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-2xl font-bold mb-4 text-bright-yellow">About Gates Spring</h3>
                      <p className="text-bright-white/80 leading-relaxed">
                        Gates Spring is designed with families in mind, offering a safe and nurturing environment for
                        children to grow and families to thrive. The community features beautifully landscaped
                        environments with plenty of green spaces and recreational facilities.
                      </p>
                    </div>

                    <div>
                      <h4 className="text-xl font-semibold mb-3 text-bright-yellow">Key Features</h4>
                      <div className="grid grid-cols-2 gap-3">
                        {propertyFeatures.map((feature, index) => (
                          <div key={index} className="flex items-center">
                            <div className="w-2 h-2 bg-bright-yellow rounded-full mr-3" />
                            <span className="text-bright-white/80">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="units" className="mt-8">
                  <div className="space-y-6">
                    <h3 className="text-2xl font-bold mb-6 text-bright-yellow">Available Unit Types</h3>
                    <div className="grid gap-6">
                      {unitTypes.map((unit, index) => (
                        <Card key={index} className="bg-bright-black/50 border-bright-yellow/20">
                          <CardContent className="p-6">
                            <div className="flex justify-between items-start mb-4">
                              <div>
                                <h4 className="text-xl font-bold text-bright-white">{unit.type}</h4>
                                <p className="text-bright-white/70">{unit.area}</p>
                              </div>
                              <div className="text-right">
                                <p className="text-2xl font-bold text-bright-yellow">{unit.price}</p>
                              </div>
                            </div>
                            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                              {unit.features.map((feature, idx) => (
                                <span key={idx} className="text-sm text-bright-white/70">
                                  • {feature}
                                </span>
                              ))}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="amenities" className="mt-8">
                  <div className="space-y-6">
                    <h3 className="text-2xl font-bold mb-6 text-bright-yellow">Community Amenities</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Card className="bg-bright-black/50 border-bright-yellow/20">
                        <CardContent className="p-6">
                          <h4 className="text-lg font-semibold mb-4 text-bright-yellow">Family Features</h4>
                          <ul className="space-y-2 text-bright-white/80">
                            <li>• Children's playground</li>
                            <li>• Community center</li>
                            <li>• Green spaces</li>
                            <li>• Walking paths</li>
                          </ul>
                        </CardContent>
                      </Card>
                      <Card className="bg-bright-black/50 border-bright-yellow/20">
                        <CardContent className="p-6">
                          <h4 className="text-lg font-semibold mb-4 text-bright-yellow">Security & Services</h4>
                          <ul className="space-y-2 text-bright-white/80">
                            <li>• 24/7 security</li>
                            <li>• Gated community</li>
                            <li>• Parking facilities</li>
                            <li>• Maintenance services</li>
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="gallery" className="mt-8">
                  <div className="space-y-6">
                    <h3 className="text-2xl font-bold mb-6 text-bright-yellow">Property Gallery</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {propertyImages.map((image, index) => (
                        <div key={index} className="relative h-64 rounded-lg overflow-hidden">
                          <Image
                            src={image || "/placeholder.svg"}
                            alt={`Gates Spring view ${index + 1}`}
                            fill
                            className="object-cover hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-yellow">Quick Actions</h3>
                  <div className="space-y-3">
                    <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                      <Calendar className="mr-2 h-4 w-4" />
                      Schedule Viewing
                    </Button>
                    <Button variant="outline" className="w-full border-bright-yellow text-bright-yellow">
                      <Heart className="mr-2 h-4 w-4" />
                      Save Property
                    </Button>
                    <Button variant="outline" className="w-full border-bright-yellow text-bright-yellow">
                      <Share2 className="mr-2 h-4 w-4" />
                      Share Property
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-yellow">Property Details</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between">
                      <span className="text-bright-white/70">Status:</span>
                      <span className="text-bright-white">Available</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-bright-white/70">Property Type:</span>
                      <span className="text-bright-white">Residential</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-bright-white/70">Total Units:</span>
                      <span className="text-bright-white">36 Units</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-bright-white/70">Completion:</span>
                      <span className="text-bright-white">Ready</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
