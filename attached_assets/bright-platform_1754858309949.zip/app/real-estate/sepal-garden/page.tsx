"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion } from "framer-motion"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Check, ChevronRight, Home, Info, MapPin, Phone, Share2, Star, Users } from "lucide-react"
import ContactCTA from "@/components/contact-cta"

export default function SepalGardenPage() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <main className="bg-bright-black text-bright-white">
      {/* Hero Section */}
      <section className="relative h-[70vh]">
        <div className="absolute inset-0">
          <Image
            src="/images/building2.webp"
            alt="Sepal Garden Residential Complex"
            fill
            className="object-cover"
            priority
            sizes="100vw"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-bright-black via-bright-black/50 to-transparent"></div>
        </div>

        <div className="absolute inset-0 flex items-end">
          <div className="container mx-auto px-4 pb-12">
            <div className="max-w-4xl">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="flex items-center mb-4"
              >
                <Badge className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 mr-2">Featured</Badge>
                <div className="text-sm text-bright-white/80">Residential Development</div>
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-4xl md:text-6xl font-bold mb-4"
              >
                Sepal Garden
              </motion.h1>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="flex items-center mb-6"
              >
                <MapPin className="h-5 w-5 text-bright-yellow mr-2" />
                <span className="text-bright-white/90">Bugolobi, Kampala, Uganda</span>
              </motion.div>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="text-lg text-bright-white/80 mb-8 max-w-2xl"
              >
                Beautiful garden-themed residential development with lush landscaping, premium amenities, and modern
                living spaces designed for comfort and luxury.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="flex flex-wrap gap-4"
              >
                <Button className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">Book a Viewing</Button>
                <Button variant="outline" className="border-bright-white/20 text-bright-white">
                  <Phone className="mr-2 h-4 w-4" /> Contact Agent
                </Button>
                <Button variant="ghost" className="text-bright-white hover:bg-bright-white/10">
                  <Share2 className="mr-2 h-4 w-4" /> Share
                </Button>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Property Details Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-4 mb-8">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="units">Unit Types</TabsTrigger>
                  <TabsTrigger value="amenities">Amenities</TabsTrigger>
                  <TabsTrigger value="gallery">Gallery</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-8">
                  <div>
                    <h2 className="text-2xl font-bold mb-4 text-bright-yellow">About Sepal Garden</h2>
                    <p className="text-bright-white/80 mb-4">
                      Sepal Garden is a premium residential development that combines modern architecture with lush
                      green spaces. Located in the heart of Bugolobi, this development offers a serene living
                      environment with easy access to urban amenities.
                    </p>
                    <p className="text-bright-white/80 mb-4">
                      The development features spacious apartments with high-quality finishes, large windows for natural
                      light, and private balconies overlooking beautifully landscaped gardens. The property is designed
                      to provide residents with a perfect balance of comfort, luxury, and connection to nature.
                    </p>
                    <p className="text-bright-white/80">
                      With 24/7 security, dedicated parking, and a range of recreational facilities, Sepal Garden offers
                      a comprehensive living experience for families and professionals alike.
                    </p>
                  </div>

                  <div>
                    <h2 className="text-2xl font-bold mb-4 text-bright-yellow">Property Features</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-start">
                        <Check className="h-5 w-5 text-bright-yellow mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-medium">Modern Architecture</h3>
                          <p className="text-sm text-bright-white/70">
                            Contemporary design with clean lines and elegant finishes
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Check className="h-5 w-5 text-bright-yellow mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-medium">Landscaped Gardens</h3>
                          <p className="text-sm text-bright-white/70">
                            Extensive green spaces with walking paths and seating areas
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Check className="h-5 w-5 text-bright-yellow mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-medium">Secure Environment</h3>
                          <p className="text-sm text-bright-white/70">
                            24/7 security with CCTV surveillance and controlled access
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Check className="h-5 w-5 text-bright-yellow mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-medium">Ample Parking</h3>
                          <p className="text-sm text-bright-white/70">
                            Dedicated parking spaces for residents and visitors
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Check className="h-5 w-5 text-bright-yellow mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-medium">Quality Finishes</h3>
                          <p className="text-sm text-bright-white/70">Premium materials and craftsmanship throughout</p>
                        </div>
                      </div>
                      <div className="flex items-start">
                        <Check className="h-5 w-5 text-bright-yellow mr-2 mt-0.5" />
                        <div>
                          <h3 className="font-medium">Prime Location</h3>
                          <p className="text-sm text-bright-white/70">
                            Close to schools, shopping centers, and healthcare facilities
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h2 className="text-2xl font-bold mb-4 text-bright-yellow">Location Advantages</h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Card className="bg-bright-black border-bright-yellow/20">
                        <CardContent className="p-4">
                          <h3 className="font-medium mb-2">Transportation</h3>
                          <p className="text-sm text-bright-white/70">
                            10 minutes to city center
                            <br />
                            15 minutes to business district
                            <br />
                            30 minutes to airport
                          </p>
                        </CardContent>
                      </Card>
                      <Card className="bg-bright-black border-bright-yellow/20">
                        <CardContent className="p-4">
                          <h3 className="font-medium mb-2">Education</h3>
                          <p className="text-sm text-bright-white/70">
                            5 minutes to international schools
                            <br />8 minutes to university
                            <br />3 minutes to library
                          </p>
                        </CardContent>
                      </Card>
                      <Card className="bg-bright-black border-bright-yellow/20">
                        <CardContent className="p-4">
                          <h3 className="font-medium mb-2">Lifestyle</h3>
                          <p className="text-sm text-bright-white/70">
                            5 minutes to shopping mall
                            <br />7 minutes to restaurants
                            <br />
                            10 minutes to parks
                          </p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="units" className="space-y-8">
                  <div>
                    <h2 className="text-2xl font-bold mb-6 text-bright-yellow">Available Unit Types</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <Card className="bg-bright-black border-bright-yellow/20 overflow-hidden">
                        <div className="relative h-48">
                          <Image
                            src="/images/building2.webp"
                            alt="One Bedroom Apartment"
                            fill
                            className="object-cover"
                            sizes="(max-width: 768px) 100vw, 50vw"
                          />
                        </div>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-center mb-2">
                            <h3 className="font-bold text-lg">One Bedroom</h3>
                            <Badge className="bg-bright-yellow text-bright-black">From $65,000</Badge>
                          </div>
                          <div className="flex items-center text-bright-white/70 text-sm mb-3">
                            <Home className="h-4 w-4 mr-1" />
                            <span>650 sq ft</span>
                          </div>
                          <p className="text-bright-white/80 text-sm mb-4">
                            Compact yet spacious one-bedroom apartments with modern finishes, perfect for singles or
                            couples.
                          </p>
                          <div className="flex justify-between">
                            <Button variant="outline" size="sm" className="border-bright-yellow/40 text-bright-yellow">
                              View Details
                            </Button>
                            <Button size="sm" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                              Inquire Now
                            </Button>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-bright-black border-bright-yellow/20 overflow-hidden">
                        <div className="relative h-48">
                          <Image
                            src="/images/building3.webp"
                            alt="Two Bedroom Apartment"
                            fill
                            className="object-cover"
                            sizes="(max-width: 768px) 100vw, 50vw"
                          />
                        </div>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-center mb-2">
                            <h3 className="font-bold text-lg">Two Bedroom</h3>
                            <Badge className="bg-bright-yellow text-bright-black">From $95,000</Badge>
                          </div>
                          <div className="flex items-center text-bright-white/70 text-sm mb-3">
                            <Home className="h-4 w-4 mr-1" />
                            <span>950 sq ft</span>
                          </div>
                          <p className="text-bright-white/80 text-sm mb-4">
                            Spacious two-bedroom apartments with separate living areas, ideal for small families.
                          </p>
                          <div className="flex justify-between">
                            <Button variant="outline" size="sm" className="border-bright-yellow/40 text-bright-yellow">
                              View Details
                            </Button>
                            <Button size="sm" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                              Inquire Now
                            </Button>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-bright-black border-bright-yellow/20 overflow-hidden">
                        <div className="relative h-48">
                          <Image
                            src="/images/modern-house-1.jpeg"
                            alt="Three Bedroom Apartment"
                            fill
                            className="object-cover"
                            sizes="(max-width: 768px) 100vw, 50vw"
                          />
                        </div>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-center mb-2">
                            <h3 className="font-bold text-lg">Three Bedroom</h3>
                            <Badge className="bg-bright-yellow text-bright-black">From $135,000</Badge>
                          </div>
                          <div className="flex items-center text-bright-white/70 text-sm mb-3">
                            <Home className="h-4 w-4 mr-1" />
                            <span>1,250 sq ft</span>
                          </div>
                          <p className="text-bright-white/80 text-sm mb-4">
                            Luxurious three-bedroom apartments with premium finishes and garden views.
                          </p>
                          <div className="flex justify-between">
                            <Button variant="outline" size="sm" className="border-bright-yellow/40 text-bright-yellow">
                              View Details
                            </Button>
                            <Button size="sm" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                              Inquire Now
                            </Button>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="bg-bright-black border-bright-yellow/20 overflow-hidden">
                        <div className="relative h-48">
                          <Image
                            src="/images/night-building.jpeg"
                            alt="Penthouse"
                            fill
                            className="object-cover"
                            sizes="(max-width: 768px) 100vw, 50vw"
                          />
                        </div>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-center mb-2">
                            <h3 className="font-bold text-lg">Penthouse</h3>
                            <Badge className="bg-bright-yellow text-bright-black">From $250,000</Badge>
                          </div>
                          <div className="flex items-center text-bright-white/70 text-sm mb-3">
                            <Home className="h-4 w-4 mr-1" />
                            <span>2,100 sq ft</span>
                          </div>
                          <p className="text-bright-white/80 text-sm mb-4">
                            Exclusive penthouse units with private terraces and panoramic city views.
                          </p>
                          <div className="flex justify-between">
                            <Button variant="outline" size="sm" className="border-bright-yellow/40 text-bright-yellow">
                              View Details
                            </Button>
                            <Button size="sm" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                              Inquire Now
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="amenities" className="space-y-8">
                  <div>
                    <h2 className="text-2xl font-bold mb-6 text-bright-yellow">World-Class Amenities</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      <Card className="bg-bright-black border-bright-yellow/20">
                        <CardContent className="p-4">
                          <div className="flex items-center mb-3">
                            <div className="bg-bright-yellow/20 p-2 rounded-lg mr-3">
                              <Users className="h-5 w-5 text-bright-yellow" />
                            </div>
                            <h3 className="font-medium">Community Center</h3>
                          </div>
                          <p className="text-sm text-bright-white/70">
                            Spacious community hall for events and gatherings
                          </p>
                        </CardContent>
                      </Card>

                      <Card className="bg-bright-black border-bright-yellow/20">
                        <CardContent className="p-4">
                          <div className="flex items-center mb-3">
                            <div className="bg-bright-yellow/20 p-2 rounded-lg mr-3">
                              <Star className="h-5 w-5 text-bright-yellow" />
                            </div>
                            <h3 className="font-medium">Fitness Center</h3>
                          </div>
                          <p className="text-sm text-bright-white/70">Modern gym with state-of-the-art equipment</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-bright-black border-bright-yellow/20">
                        <CardContent className="p-4">
                          <div className="flex items-center mb-3">
                            <div className="bg-bright-yellow/20 p-2 rounded-lg mr-3">
                              <Home className="h-5 w-5 text-bright-yellow" />
                            </div>
                            <h3 className="font-medium">Children's Playground</h3>
                          </div>
                          <p className="text-sm text-bright-white/70">Safe and fun play area for children</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-bright-black border-bright-yellow/20">
                        <CardContent className="p-4">
                          <div className="flex items-center mb-3">
                            <div className="bg-bright-yellow/20 p-2 rounded-lg mr-3">
                              <Info className="h-5 w-5 text-bright-yellow" />
                            </div>
                            <h3 className="font-medium">Swimming Pool</h3>
                          </div>
                          <p className="text-sm text-bright-white/70">Resort-style pool with lounging area</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-bright-black border-bright-yellow/20">
                        <CardContent className="p-4">
                          <div className="flex items-center mb-3">
                            <div className="bg-bright-yellow/20 p-2 rounded-lg mr-3">
                              <MapPin className="h-5 w-5 text-bright-yellow" />
                            </div>
                            <h3 className="font-medium">Landscaped Gardens</h3>
                          </div>
                          <p className="text-sm text-bright-white/70">Beautiful gardens with walking paths</p>
                        </CardContent>
                      </Card>

                      <Card className="bg-bright-black border-bright-yellow/20">
                        <CardContent className="p-4">
                          <div className="flex items-center mb-3">
                            <div className="bg-bright-yellow/20 p-2 rounded-lg mr-3">
                              <Calendar className="h-5 w-5 text-bright-yellow" />
                            </div>
                            <h3 className="font-medium">24/7 Security</h3>
                          </div>
                          <p className="text-sm text-bright-white/70">Round-the-clock security and surveillance</p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="gallery" className="space-y-8">
                  <div>
                    <h2 className="text-2xl font-bold mb-6 text-bright-yellow">Property Gallery</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {[
                        "/images/building2.webp",
                        "/images/building3.webp",
                        "/images/modern-house-1.jpeg",
                        "/images/night-building.jpeg",
                        "/images/waterfront-complex.jpeg",
                        "/images/lakeside-building.jpeg",
                      ].map((image, index) => (
                        <div key={index} className="relative h-64 rounded-lg overflow-hidden">
                          <Image
                            src={image || "/placeholder.svg"}
                            alt={`Sepal Garden Gallery Image ${index + 1}`}
                            fill
                            className="object-cover hover:scale-105 transition-transform duration-300"
                            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-8 space-y-6">
                <Card className="bg-bright-black border-bright-yellow/20">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-4 text-bright-yellow">Quick Info</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-bright-white/70">Starting Price</span>
                        <span className="font-medium">$65,000</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-bright-white/70">Property Type</span>
                        <span className="font-medium">Residential</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-bright-white/70">Units Available</span>
                        <span className="font-medium">48</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-bright-white/70">Completion</span>
                        <span className="font-medium">Q4 2024</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-bright-white/70">Payment Plan</span>
                        <span className="font-medium">Available</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-bright-black border-bright-yellow/20">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-4 text-bright-yellow">Contact Agent</h3>
                    <div className="space-y-4">
                      <div>
                        <p className="font-medium">Sarah Nakamya</p>
                        <p className="text-sm text-bright-white/70">Senior Property Consultant</p>
                      </div>
                      <div className="space-y-2">
                        <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                          <Phone className="mr-2 h-4 w-4" />
                          Call Now
                        </Button>
                        <Button variant="outline" className="w-full border-bright-yellow/40 text-bright-yellow">
                          <Calendar className="mr-2 h-4 w-4" />
                          Schedule Visit
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-bright-black border-bright-yellow/20">
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-4 text-bright-yellow">Similar Properties</h3>
                    <div className="space-y-4">
                      <Link href="/real-estate/horizon-residency" className="block">
                        <div className="flex items-center space-x-3 p-2 rounded-lg hover:bg-bright-white/5 transition-colors">
                          <div className="relative w-16 h-16 rounded-lg overflow-hidden">
                            <Image
                              src="/images/horizon-residency-front.jpeg"
                              alt="Horizon Residency"
                              fill
                              className="object-cover"
                              sizes="64px"
                            />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium text-sm">Horizon Residency</p>
                            <p className="text-xs text-bright-white/70">From $78,000</p>
                          </div>
                          <ChevronRight className="h-4 w-4 text-bright-white/50" />
                        </div>
                      </Link>

                      <Link href="/real-estate/topaz-court" className="block">
                        <div className="flex items-center space-x-3 p-2 rounded-lg hover:bg-bright-white/5 transition-colors">
                          <div className="relative w-16 h-16 rounded-lg overflow-hidden">
                            <Image
                              src="/images/building1.webp"
                              alt="Topaz Court"
                              fill
                              className="object-cover"
                              sizes="64px"
                            />
                          </div>
                          <div className="flex-1">
                            <p className="font-medium text-sm">Topaz Court</p>
                            <p className="text-xs text-bright-white/70">From $85,000</p>
                          </div>
                          <ChevronRight className="h-4 w-4 text-bright-white/50" />
                        </div>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
