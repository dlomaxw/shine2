"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Check, MapPin, Home, Waves, Building2, Bath } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ContactForm from "@/components/contact-form"
import Icon180Hero from "@/components/icon-180-hero"
import ContactCTA from "@/components/contact-cta"

export default function Icon180Page() {
  // Unit types data
  const unitTypes = [
    {
      type: "4-Bedroom Duplex",
      bedrooms: 4,
      bathrooms: 4,
      size: "280 sqm",
      description: "Spacious two-level duplex with panoramic lakeview and premium finishes",
      features: [
        "Two-level living with private staircase",
        "Master suite with lake-facing balcony",
        "Open-plan kitchen and dining",
        "Private rooftop terrace",
        "Walk-in closets in all bedrooms",
        "Premium appliances and fixtures",
      ],
    },
    {
      type: "3-Bedroom Apartment",
      bedrooms: 3,
      bathrooms: 3,
      size: "180 sqm",
      description: "Modern apartment with floor-to-ceiling windows and stunning lake panoramas",
      features: [
        "Floor-to-ceiling windows",
        "Open-concept living and dining",
        "Modern kitchen with island",
        "Master bedroom with en-suite",
        "Private balcony with lake views",
        "Built-in storage solutions",
      ],
    },
  ]

  // Amenities data
  const amenities = [
    { name: "Lakefront Promenade", description: "Private walkway along the lake with seating areas" },
    { name: "Infinity Pool", description: "Rooftop infinity pool overlooking the lake" },
    { name: "Fitness Center", description: "State-of-the-art gym with lake views" },
    { name: "Residents' Lounge", description: "Elegant social space with panoramic views" },
    { name: "Concierge Service", description: "24/7 personalized assistance for residents" },
    { name: "Secure Parking", description: "Underground parking with electric vehicle charging" },
    { name: "Sky Garden", description: "Rooftop garden with outdoor dining areas" },
    { name: "Business Center", description: "Professional workspace with meeting rooms" },
  ]

  return (
    <main className="flex min-h-screen flex-col bg-bright-black text-bright-white">
      {/* Hero Section */}
      <Icon180Hero />

      {/* Main Content */}
      <section className="py-20 px-4 md:px-6 lg:px-8 bg-bright-black">
        <div className="container mx-auto">
          <Link href="/real-estate" className="flex items-center text-muted-foreground hover:text-bright-yellow mb-12">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Real Estate Projects
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left Column - Main Content */}
            <div className="lg:col-span-2 space-y-12">
              {/* Overview Section */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Your Home in the Skyline</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="prose prose-lg prose-invert max-w-none">
                  <p>
                    Icon 180 represents the pinnacle of modern lakefront living, where contemporary architecture meets
                    the serene beauty of breathtaking lake views. This exclusive development offers a unique opportunity
                    to own your home in the skyline, with unparalleled vistas and sophisticated design.
                  </p>
                  <p>
                    Choose from spacious 4-bedroom duplexes that span two levels of luxury, or elegant 3-bedroom
                    apartments with floor-to-ceiling windows that frame the stunning lake panoramas. Each residence is
                    meticulously designed to maximize natural light and showcase the breathtaking views that make Icon
                    180 truly exceptional.
                  </p>

                  <div className="bg-bright-yellow/10 border border-bright-yellow/20 rounded-lg p-6 my-8">
                    <h3 className="text-bright-yellow font-bold text-xl mb-3">Ready to live in the lap of luxury?</h3>
                    <p className="text-bright-white/80 mb-0">
                      Experience the perfect blend of modern sophistication and natural beauty at Icon 180, where every
                      day begins with stunning lake views and ends with the comfort of luxury living.
                    </p>
                  </div>
                </div>

                {/* Quick Facts */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <div className="flex items-center mb-2">
                        <Waves className="h-4 w-4 text-bright-yellow mr-2" />
                        <p className="text-bright-white/70 text-sm">Views</p>
                      </div>
                      <p className="text-bright-white font-medium">Breathtaking Lakeview</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <div className="flex items-center mb-2">
                        <Home className="h-4 w-4 text-bright-yellow mr-2" />
                        <p className="text-bright-white/70 text-sm">Unit Types</p>
                      </div>
                      <p className="text-bright-white font-medium">Duplexes & Apartments</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <div className="flex items-center mb-2">
                        <Building2 className="h-4 w-4 text-bright-yellow mr-2" />
                        <p className="text-bright-white/70 text-sm">Architecture</p>
                      </div>
                      <p className="text-bright-white font-medium">Modern Skyline</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <div className="flex items-center mb-2">
                        <MapPin className="h-4 w-4 text-bright-yellow mr-2" />
                        <p className="text-bright-white/70 text-sm">Location</p>
                      </div>
                      <p className="text-bright-white font-medium">Lakefront Premium</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Gallery Section */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Gallery</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Icon 180 - Exterior View"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Icon 180 - Lake View from Balcony"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Icon 180 - Duplex Interior"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/placeholder.svg?height=400&width=600"
                      alt="Icon 180 - Rooftop Pool"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </div>

              {/* Unit Types */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Unit Types</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="space-y-8">
                  {unitTypes.map((unit, index) => (
                    <Card key={index} className="bg-bright-black/50 border-bright-yellow/20 overflow-hidden">
                      <CardContent className="p-8">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div>
                            <h3 className="text-2xl font-bold mb-4 text-bright-white">{unit.type}</h3>
                            <div className="flex items-center space-x-6 mb-4">
                              <div className="flex items-center">
                                <Home className="h-5 w-5 text-bright-yellow mr-2" />
                                <span className="text-bright-white/70">{unit.bedrooms} Bedrooms</span>
                              </div>
                              <div className="flex items-center">
                                <Bath className="h-5 w-5 text-bright-yellow mr-2" />
                                <span className="text-bright-white/70">{unit.bathrooms} Bathrooms</span>
                              </div>
                              <div className="flex items-center">
                                <MapPin className="h-5 w-5 text-bright-yellow mr-2" />
                                <span className="text-bright-white/70">{unit.size}</span>
                              </div>
                            </div>
                            <p className="text-bright-white/70 mb-6">{unit.description}</p>
                            <div className="space-y-3">
                              {unit.features.map((feature, idx) => (
                                <div key={idx} className="flex items-center">
                                  <Check className="h-4 w-4 text-bright-yellow mr-3 flex-shrink-0" />
                                  <span className="text-bright-white/80">{feature}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                          <div className="relative h-64 md:h-full rounded-lg overflow-hidden">
                            <Image
                              src={`/placeholder.svg?height=400&width=600&query=${unit.type.toLowerCase()} interior with lake view and modern design`}
                              alt={`${unit.type} Interior`}
                              fill
                              className="object-cover"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Amenities */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Luxury Amenities</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {amenities.map((amenity, index) => (
                    <div key={index} className="flex items-start p-4 border border-bright-yellow/20 rounded-lg">
                      <Check className="h-5 w-5 text-bright-yellow mr-3 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-bright-white">{amenity.name}</h4>
                        <p className="text-bright-white/70 text-sm">{amenity.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column - Sidebar */}
            <div className="space-y-8">
              {/* Luxury Living Card */}
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Luxury Lakefront Living</h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-bright-white/70 text-sm">Experience</p>
                      <p className="text-bright-yellow font-medium">Modern Living with Breathtaking Lakeview</p>
                    </div>
                    <div>
                      <p className="text-bright-white/70 text-sm">Available Units</p>
                      <p className="text-bright-white font-medium">4BR Duplexes & 3BR Apartments</p>
                    </div>
                    <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                      Schedule Private Tour
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Contact Form */}
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Interested in Icon 180?</h3>
                  <ContactForm propertyId="icon-180" propertyTitle="Icon 180" simplified />
                </CardContent>
              </Card>

              {/* Virtual Tour Card */}
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Virtual Experience</h3>
                  <div className="relative h-48 rounded-lg overflow-hidden mb-4">
                    <Image
                      src="/placeholder.svg?height=300&width=400"
                      alt="Icon 180 Virtual Tour"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 bg-bright-black/40 flex items-center justify-center">
                      <Button
                        variant="outline"
                        className="border-bright-white text-bright-white hover:bg-bright-white/10"
                      >
                        Launch Virtual Tour
                      </Button>
                    </div>
                  </div>
                  <p className="text-bright-white/70 text-sm">
                    Experience Icon 180's breathtaking lakeviews and luxury interiors through our immersive virtual
                    tour.
                  </p>
                </CardContent>
              </Card>

              {/* Lifestyle Card */}
              <Card className="bg-bright-yellow/10 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-yellow">Ready to live in the lap of luxury?</h3>
                  <p className="text-bright-white/80 mb-4">
                    Discover your perfect home where modern sophistication meets natural beauty at Icon 180.
                  </p>
                  <Button
                    variant="outline"
                    className="w-full border-bright-yellow text-bright-yellow hover:bg-bright-yellow/10"
                  >
                    Learn More
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
