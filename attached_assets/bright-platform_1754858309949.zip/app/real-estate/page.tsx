"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowRight, MapPin, DollarSign, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import FuturisticCard from "@/components/futuristic-card"
import ContactCTA from "@/components/contact-cta"
import VideoPlayer from "@/components/video-player"
import PropertySearchHero from "@/components/property-search-hero"

export default function RealEstatePage() {
  const featuredProperties = [
    {
      id: "horizon-residency",
      title: "The Horizon Residency",
      description: "Luxury Living in the Heart of Bugolobi - Premium 1, 2, and 3 bedroom apartments",
      location: "Luthuli Avenue, Bugolobi",
      startingPrice: "$78,000",
      image: "/images/horizon-residency-front.jpeg",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/horizon%20residencyV1-pX4FFwA4bPYXhHK937BJ1oajcitg5A.webm",
      status: "Available",
      unitTypes: "1, 2, 3 BR",
    },
    {
      id: "skyrise-apartments",
      title: "Skyrise Apartments",
      description: "Luxury Living in Prestigious Kololo with breathtaking golf course views",
      location: "Kololo, Kampala",
      startingPrice: "$135,000",
      image: "/images/skyrise-aerial-view.jpeg",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/skyriseinsta-ou61xLfPnC9SGnbyqMj0Y5H0vakI8b.webm",
      status: "In Progress",
      unitTypes: "2, 3 BR",
    },
    {
      id: "topaz-court",
      title: "Topaz Court",
      description: "Luxury apartment complex featuring modern amenities and elegant design",
      location: "Premium Location",
      startingPrice: "$145,000",
      image: "/images/topaz-court-exterior.png",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/topaz%20court-IarahXii0RQiQnxicNfBPprqR1bM6w.webm",
      status: "Available",
      unitTypes: "2, 3 BR",
    },
    {
      id: "sepal-garden",
      title: "Sepal Garden",
      description: "Beautiful garden-themed residential development with lush landscaping",
      location: "Garden District",
      startingPrice: "$120,000",
      image: "/images/sepal-garden-exterior.png",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/SEPAL%20GARDEN-Jv919x59xk5JOoiioE6rACqtfDf0Mi.webm",
      status: "Pre-Launch",
      unitTypes: "2, 3, 4 BR",
    },
    {
      id: "gates-spring",
      title: "Gates Spring",
      description: "Family-oriented residential community with landscaped environments",
      location: "Spring Valley",
      startingPrice: "$95,000",
      image: "/images/gates-spring-exterior.png",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/gates%20spring%201-6QMh83Ksu3HDdVNpJaIp7banpIRJ6u.webm",
      status: "Available",
      unitTypes: "2, 3 BR",
    },
    {
      id: "sky-resident",
      title: "Sky Resident",
      description: "Pre-launch architectural visualization for luxury residential development",
      location: "City Center",
      startingPrice: "$160,000",
      image: "/images/sky-resident-exterior.png",
      video: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/sky%20resident%20pre-glYYw1X6QY4LTVLPzsYjEIsVJR4UvI.webm",
      status: "Pre-Launch",
      unitTypes: "1, 2, 3 BR",
    },
  ]

  return (
    <main className="flex min-h-screen flex-col bg-bright-black text-bright-white">
      {/* Hero Section */}
      <PropertySearchHero />

      {/* Featured Properties */}
      <section className="py-20 px-4 md:px-6 lg:px-8 bg-bright-black">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-5xl font-bold mb-4 text-bright-yellow relative inline-block"
            >
              <span className="relative z-10">Featured Properties</span>
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-bright-white/70 max-w-3xl mx-auto"
            >
              Explore our portfolio of luxury properties with immersive virtual tours and detailed property information.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProperties.map((property, index) => (
              <motion.div
                key={property.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="bg-bright-black/50 border-bright-yellow/20 overflow-hidden group hover:border-bright-yellow/40 transition-all duration-300">
                  <div className="relative h-64">
                    <VideoPlayer
                      src={property.video}
                      title={property.title}
                      className="h-full"
                      poster={property.image}
                    />
                    <div className="absolute top-4 right-4">
                      <span
                        className={`px-2 py-1 text-xs font-medium rounded-full ${
                          property.status === "Available"
                            ? "bg-green-500/20 text-green-400"
                            : property.status === "In Progress"
                              ? "bg-yellow-500/20 text-yellow-400"
                              : "bg-blue-500/20 text-blue-400"
                        }`}
                      >
                        {property.status}
                      </span>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-2 text-bright-white group-hover:text-bright-yellow transition-colors">
                      {property.title}
                    </h3>
                    <p className="text-bright-white/70 mb-4 text-sm">{property.description}</p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-sm">
                        <MapPin className="h-4 w-4 text-bright-yellow mr-2" />
                        <span className="text-bright-white/70">{property.location}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <DollarSign className="h-4 w-4 text-bright-yellow mr-2" />
                        <span className="text-bright-white/70">Starting from </span>
                        <span className="text-bright-yellow font-bold ml-1">{property.startingPrice}</span>
                      </div>
                      <div className="flex items-center text-sm">
                        <Home className="h-4 w-4 text-bright-yellow mr-2" />
                        <span className="text-bright-white/70">{property.unitTypes} Apartments</span>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Link href={`/real-estate/${property.id}`} className="flex-1">
                        <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                          View Details
                        </Button>
                      </Link>
                      <Button
                        variant="outline"
                        size="icon"
                        className="border-bright-yellow text-bright-yellow hover:bg-bright-yellow/10"
                      >
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4 md:px-6 lg:px-8 bg-bright-black/50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-5xl font-bold mb-4 text-bright-yellow relative inline-block"
            >
              <span className="relative z-10">Our Real Estate Services</span>
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </motion.h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FuturisticCard
              title="Virtual Property Tours"
              description="Immersive 3D virtual tours that allow potential buyers to explore properties remotely"
              category="Virtual Reality"
              image="/placeholder.svg?height=300&width=400"
              href="/services/virtual-tours"
              glowColor="rgba(255, 225, 0, 0.3)"
            />
            <FuturisticCard
              title="Architectural Visualization"
              description="Photorealistic renderings and animations of properties before construction"
              category="3D Rendering"
              image="/placeholder.svg?height=300&width=400"
              href="/services/visualization"
              glowColor="rgba(255, 225, 0, 0.3)"
            />
            <FuturisticCard
              title="Interactive Floor Plans"
              description="Dynamic floor plans with interactive elements and virtual staging"
              category="Interactive Design"
              image="/placeholder.svg?height=300&width=400"
              href="/services/floor-plans"
              glowColor="rgba(255, 225, 0, 0.3)"
            />
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 px-4 md:px-6 lg:px-8 bg-white">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                We make it easy for <span className="text-bright-yellow">tenants and landlords</span>
              </h2>
              <p className="text-gray-600 mb-8">
                Whether it's selling your current home, getting financing, or buying a new home, we make it easy and
                efficient. The best part? You'll save a bunch of money and time with our services.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="text-center p-6 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-bright-yellow mb-2">For tenants</div>
                  <p className="text-sm text-gray-600">Find your perfect home with virtual tours</p>
                </div>
                <div className="text-center p-6 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-bright-yellow mb-2">For landlords</div>
                  <p className="text-sm text-gray-600">List and showcase your properties effectively</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <img
                src="/placeholder.svg?height=400&width=500"
                alt="Happy family in their new home"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
