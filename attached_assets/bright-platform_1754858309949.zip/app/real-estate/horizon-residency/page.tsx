"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Check, MapPin, Home, Play } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ContactForm from "@/components/contact-form"
import HorizonResidencyHero from "@/components/horizon-residency-hero"
import ContactCTA from "@/components/contact-cta"
import VideoPlayer from "@/components/video-player"

export default function HorizonResidencyPage() {
  // Unit types data
  const unitTypes = [
    {
      type: "1 Bedroom Apartment",
      bedrooms: 1,
      size: "65 sqm",
      price: "$78,000",
      description: "Compact luxury living with modern amenities and efficient space utilization",
      features: ["Open-plan living", "Modern kitchen", "Private balcony", "Built-in storage"],
    },
    {
      type: "2 Bedroom Apartment",
      bedrooms: 2,
      size: "95 sqm",
      price: "$98,000",
      description: "Spacious family apartment with premium finishes and panoramic views",
      features: ["Master bedroom with en-suite", "Guest bedroom", "Spacious living area", "Modern appliances"],
    },
    {
      type: "3 Bedroom Apartment",
      bedrooms: 3,
      size: "125 sqm",
      price: "$128,000",
      description: "Luxury family residence with expansive layouts and premium amenities",
      features: ["Three bedrooms with built-ins", "Two bathrooms", "Large living/dining", "Premium finishes"],
    },
  ]

  // Amenities data
  const amenities = [
    { name: "Swimming Pool", description: "Resort-style pool with sun deck" },
    { name: "Fitness Center", description: "Fully equipped modern gym" },
    { name: "Children's Playground", description: "Safe play area for kids" },
    { name: "24/7 Security", description: "Round-the-clock security service" },
    { name: "Parking", description: "Secure covered parking spaces" },
    { name: "Landscaped Gardens", description: "Beautiful communal garden areas" },
    { name: "Community Hall", description: "Multi-purpose event space" },
    { name: "Backup Generator", description: "Uninterrupted power supply" },
  ]

  return (
    <main className="flex min-h-screen flex-col bg-bright-black text-bright-white">
      {/* Hero Section */}
      <HorizonResidencyHero />

      {/* Main Content */}
      <section className="py-20 px-4 md:px-6 lg:px-8 bg-bright-black">
        <div className="container mx-auto">
          <Link href="/real-estate" className="flex items-center text-muted-foreground hover:text-bright-yellow mb-12">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Real Estate Projects
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left Column - Main Content */}
            <div className="lg:col-span-2 space-y-12">
              {/* Virtual Tour Section */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Virtual Tour</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="relative h-[400px] md:h-[500px] rounded-lg overflow-hidden mb-6">
                  <VideoPlayer
                    src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/horizon%20residencyV1-pX4FFwA4bPYXhHK937BJ1oajcitg5A.webm"
                    title="Horizon Residency Virtual Tour"
                    className="h-full"
                    poster="/images/horizon-residency-front.jpeg"
                  />
                </div>

                <div className="bg-bright-black/50 border border-bright-yellow/20 rounded-lg p-6">
                  <div className="flex items-center mb-3">
                    <Play className="h-5 w-5 text-bright-yellow mr-2" />
                    <h3 className="text-bright-white font-bold">Immersive Property Experience</h3>
                  </div>
                  <p className="text-bright-white/70">
                    Take a comprehensive virtual tour of The Horizon Residency. Explore the luxurious interiors, premium
                    amenities, and stunning views that make this development exceptional.
                  </p>
                </div>
              </div>

              {/* Overview Section */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Project Overview</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="prose prose-lg prose-invert max-w-none">
                  <p>
                    The Horizon Residency represents the pinnacle of luxury living in the heart of Bugolobi, situated on
                    the prestigious Luthuli Avenue. This exceptional development offers a perfect blend of modern
                    sophistication and comfortable living, designed for discerning residents who appreciate quality and
                    elegance.
                  </p>
                  <p>
                    Developed by Bright Thought Services, The Horizon Residency features premium 1, 2, and 3 bedroom
                    apartments starting at an attractive $78,000. Each residence is meticulously crafted with high-end
                    finishes, modern amenities, and thoughtful design elements that maximize both space and natural
                    light.
                  </p>
                </div>

                {/* Quick Facts */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <p className="text-bright-white/70 text-sm">Location</p>
                      <p className="text-bright-white font-medium">Luthuli Avenue, Bugolobi</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <p className="text-bright-white/70 text-sm">Developer</p>
                      <p className="text-bright-white font-medium">Bright Thought Services</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <p className="text-bright-white/70 text-sm">Starting Price</p>
                      <p className="text-bright-white font-medium">$78,000</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <p className="text-bright-white/70 text-sm">Unit Types</p>
                      <p className="text-bright-white font-medium">1, 2, 3 Bedroom</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Gallery Section */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Gallery</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/images/horizon-residency-front.jpeg"
                      alt="Horizon Residency - Front View"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/images/horizon-residency-entrance.jpeg"
                      alt="Horizon Residency - Entrance"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/images/horizon-residency-night.jpeg"
                      alt="Horizon Residency - Night View"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/images/horizon-residency-aerial.jpeg"
                      alt="Horizon Residency - Aerial View"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </div>

              {/* Unit Types */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Unit Types & Pricing</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {unitTypes.map((unit, index) => (
                    <Card key={index} className="bg-bright-black/50 border-bright-yellow/20 overflow-hidden">
                      <CardContent className="p-6">
                        <h3 className="text-xl font-bold mb-2 text-bright-white">{unit.type}</h3>
                        <div className="flex items-center space-x-4 mb-3">
                          <div className="flex items-center">
                            <Home className="h-4 w-4 text-bright-yellow mr-1" />
                            <span className="text-bright-white/70">{unit.bedrooms} BR</span>
                          </div>
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 text-bright-yellow mr-1" />
                            <span className="text-bright-white/70">{unit.size}</span>
                          </div>
                        </div>
                        <p className="text-bright-yellow font-bold text-lg mb-3">{unit.price}</p>
                        <p className="text-bright-white/70 mb-4 text-sm">{unit.description}</p>
                        <div className="space-y-2">
                          {unit.features.map((feature, idx) => (
                            <div key={idx} className="flex items-center">
                              <Check className="h-3 w-3 text-bright-yellow mr-2 flex-shrink-0" />
                              <span className="text-bright-white/80 text-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Amenities */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Amenities</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {amenities.map((amenity, index) => (
                    <div key={index} className="flex items-start p-4 border border-bright-yellow/20 rounded-lg">
                      <Check className="h-5 w-5 text-bright-yellow mr-3 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-bright-white">{amenity.name}</h4>
                        <p className="text-bright-white/70 text-sm">{amenity.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Location */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Location</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="rounded-lg overflow-hidden h-[400px] relative">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.7568587419567!2d32.58956857587536!3d0.3306999640132064!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x177dbb8080541c6d%3A0x9634932a8e1dde03!2sBugolobi%2C%20Kampala%2C%20Uganda!5e0!3m2!1sen!2sus!4v1654789542123!5m2!1sen!2sus"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    title="Horizon Residency Location"
                  />
                </div>
              </div>
            </div>

            {/* Right Column - Sidebar */}
            <div className="space-y-8">
              {/* Price Card */}
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Pricing Information</h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-bright-white/70 text-sm">Starting Price</p>
                      <p className="text-bright-yellow text-2xl font-bold">$78,000</p>
                    </div>
                    <div>
                      <p className="text-bright-white/70 text-sm">Developer</p>
                      <p className="text-bright-white font-medium">Bright Thought Services</p>
                    </div>
                    <div>
                      <p className="text-bright-white/70 text-sm">Location</p>
                      <p className="text-bright-white font-medium">Luthuli Avenue, Bugolobi</p>
                    </div>
                    <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                      Schedule Viewing
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Contact Form */}
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Interested in Horizon Residency?</h3>
                  <ContactForm propertyId="horizon-residency" propertyTitle="The Horizon Residency" simplified />
                </CardContent>
              </Card>

              {/* Virtual Tour Card */}
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Virtual Experience</h3>
                  <div className="relative h-48 rounded-lg overflow-hidden mb-4">
                    <VideoPlayer
                      src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/horizon%20residencyV1-pX4FFwA4bPYXhHK937BJ1oajcitg5A.webm"
                      title="Virtual Tour"
                      className="h-full"
                      poster="/images/horizon-residency-front.jpeg"
                    />
                  </div>
                  <p className="text-bright-white/70 text-sm">
                    Experience The Horizon Residency through our immersive virtual tour showcasing the luxury apartments
                    and premium amenities.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
