"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Calendar, Check, MapPin, Share2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { type Property, getProperties } from "@/lib/api-client"
import VRTourViewer from "@/components/vr-tour-viewer"
import ContactForm from "@/components/contact-form"

export default function PropertyDetailPage({ params }: { params: { id: string } }) {
  const [property, setProperty] = useState<Property | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadProperty() {
      try {
        // In Phase 2, this will be replaced with a direct API call to get a single property
        const properties = await getProperties()
        const foundProperty = properties.find((p) => p.id === params.id)
        setProperty(foundProperty || null)
      } catch (error) {
        console.error("Error loading property:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadProperty()
  }, [params.id])

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
          <div className="h-96 bg-gray-200 rounded mb-8"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <div className="h-6 bg-gray-200 rounded w-1/2 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
            </div>
            <div>
              <div className="h-64 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!property) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold mb-4">Property Not Found</h1>
        <p className="mb-6">The property you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link href="/real-estate">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Properties
          </Link>
        </Button>
      </div>
    )
  }

  return (
    <main className="container mx-auto px-4 py-12">
      <Link href="/real-estate" className="flex items-center text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" /> Back to Properties
      </Link>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <h1 className="text-3xl font-bold mb-2">{property.title}</h1>

          <div className="flex items-center text-muted-foreground mb-6">
            <MapPin className="h-4 w-4 mr-1" />
            <span>{property.location}</span>
          </div>

          <div className="relative rounded-lg overflow-hidden mb-8">
            <Image
              src={property.imageUrls[0] || "/placeholder.svg?height=600&width=800"}
              alt={property.title}
              width={800}
              height={500}
              className="w-full object-cover"
            />
            <div className="absolute top-4 right-4">
              <Button size="sm" variant="secondary">
                <Share2 className="h-4 w-4 mr-2" /> Share
              </Button>
            </div>
          </div>

          <Tabs defaultValue="details">
            <TabsList className="mb-6">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="vr-tour">VR Tour</TabsTrigger>
              <TabsTrigger value="location">Location</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-6">
              <div>
                <h2 className="text-xl font-semibold mb-4">Property Details</h2>
                <p className="text-muted-foreground">{property.description}</p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="bg-slate-50 p-4 rounded-lg">
                  <p className="text-sm text-muted-foreground">Price</p>
                  <p className="font-semibold">${property.price.toLocaleString()}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-lg">
                  <p className="text-sm text-muted-foreground">Status</p>
                  <p className="font-semibold capitalize">{property.status}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-lg">
                  <p className="text-sm text-muted-foreground">Type</p>
                  <p className="font-semibold">{property.type}</p>
                </div>
              </div>

              <div>
                <h2 className="text-xl font-semibold mb-4">Features</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {[
                    "Spacious layout",
                    "Modern finishes",
                    "Energy efficient",
                    "Smart home features",
                    "Private garden",
                    "Parking space",
                  ].map((feature, index) => (
                    <div key={index} className="flex items-center">
                      <Check className="h-4 w-4 text-primary mr-2" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="vr-tour">
              {property.vrTourUrl ? (
                <VRTourViewer tourUrl={property.vrTourUrl} title={`VR Tour of ${property.title}`} />
              ) : (
                <div className="text-center py-12 bg-slate-50 rounded-lg">
                  <p className="text-muted-foreground">VR tour not available for this property.</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="location">
              <div className="rounded-lg overflow-hidden h-[400px] relative">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.30596552044!2d-74.25986548248684!3d40.69714941932609!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sca!4v1619120581244!5m2!1sen!2sca"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  title="Property Location"
                />
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <Card>
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold mb-4">Interested in this property?</h2>
              <div className="space-y-4 mb-6">
                <Button className="w-full">Schedule Viewing</Button>
                <Button variant="outline" className="w-full">
                  <Calendar className="h-4 w-4 mr-2" /> Book a Video Call
                </Button>
              </div>

              <div className="border-t pt-6">
                <h3 className="font-medium mb-4">Contact Agent</h3>
                <ContactForm propertyId={property.id} propertyTitle={property.title} simplified />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  )
}
