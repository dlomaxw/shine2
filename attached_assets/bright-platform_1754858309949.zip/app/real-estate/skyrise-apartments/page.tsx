"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, Check, MapPin, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ContactForm from "@/components/contact-form"
import SkyriseApartmentsHero from "@/components/skyrise-apartments-hero"
import ContactCTA from "@/components/contact-cta"

export default function SkyriseApartmentsPage() {
  // Unit types data
  const unitTypes = [
    {
      type: "Apartment A",
      bedrooms: 3,
      size: "200 sqm",
      description: "Spacious 3BHK with premium finishes and golf course views",
      features: ["Master bedroom with en-suite", "Walk-in closet", "Private balcony", "Open-plan kitchen"],
    },
    {
      type: "Apartment B",
      bedrooms: 3,
      size: "241 sqm",
      description: "Deluxe 3BHK with expanded living areas and panoramic views",
      features: ["Dual aspect windows", "Home office space", "Designer kitchen", "Luxury fixtures"],
    },
    {
      type: "Apartment C",
      bedrooms: 2,
      size: "125 sqm",
      description: "Elegant 2BHK with efficient layout and modern amenities",
      features: ["Contemporary design", "Built-in storage", "Balcony access", "High ceilings"],
    },
    {
      type: "Apartment D",
      bedrooms: 2,
      size: "125 sqm",
      description: "Stylish 2BHK with alternative layout options and quality finishes",
      features: ["Flexible living space", "Ambient lighting", "Premium appliances", "City views"],
    },
  ]

  // Amenities data
  const amenities = [
    { name: "Rooftop Swimming Pool", description: "Infinity-edge pool with panoramic views" },
    { name: "Children's Play Area", description: "Safe and engaging playground for families" },
    { name: "Rooftop Garden", description: "Lush green spaces for relaxation" },
    { name: "Private Cabanas", description: "Exclusive seating areas for residents" },
    { name: "24/7 Security", description: "Round-the-clock surveillance and security personnel" },
    { name: "Fitness Center", description: "State-of-the-art gym equipment" },
    { name: "Residents' Lounge", description: "Elegant space for socializing and events" },
    { name: "Concierge Service", description: "Personalized assistance for residents" },
  ]

  return (
    <main className="flex min-h-screen flex-col bg-bright-black text-bright-white">
      {/* Hero Section */}
      <SkyriseApartmentsHero />

      {/* Main Content */}
      <section className="py-20 px-4 md:px-6 lg:px-8 bg-bright-black">
        <div className="container mx-auto">
          <Link href="/real-estate" className="flex items-center text-muted-foreground hover:text-bright-yellow mb-12">
            <ArrowLeft className="mr-2 h-4 w-4" /> Back to Real Estate Projects
          </Link>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Left Column - Main Content */}
            <div className="lg:col-span-2 space-y-12">
              {/* Overview Section */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Project Overview</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="prose prose-lg prose-invert max-w-none">
                  <p>
                    Skyrise Apartments presents an exclusive collection of meticulously designed luxury residences in
                    the prestigious neighborhood of Kololo, Kampala. Crafted with premium materials and sophisticated
                    modern finishes, each apartment embodies the highest standards of quality, comfort, and elegance.
                  </p>
                  <p>
                    Enjoy breathtaking golf course views, expansive layouts, and thoughtfully designed interiors that
                    maximize space and functionality. Our world-class amenities ensure unparalleled convenience and an
                    elevated lifestyle, all within a secure and private environment.
                  </p>
                  <p>
                    With flexible payment plans and exclusive offers, owning your dream home has never been more
                    attainable. Experience refined urban living at Skyrise Apartments—where luxury meets convenience in
                    the heart of Kampala.
                  </p>
                </div>

                {/* Quick Facts */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <p className="text-bright-white/70 text-sm">Location</p>
                      <p className="text-bright-white font-medium">Kololo, Kampala</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <p className="text-bright-white/70 text-sm">Status</p>
                      <p className="text-bright-white font-medium">In Progress</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <p className="text-bright-white/70 text-sm">Payment Plan</p>
                      <p className="text-bright-white font-medium">40 Months</p>
                    </CardContent>
                  </Card>
                  <Card className="bg-bright-black/50 border-bright-yellow/20">
                    <CardContent className="p-4">
                      <p className="text-bright-white/70 text-sm">Total Units</p>
                      <p className="text-bright-white font-medium">72 Apartments</p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Gallery Section */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Gallery</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/images/skyrise-aerial-view.jpeg"
                      alt="Skyrise Apartments - Aerial View"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/images/skyrise-rooftop-view.jpeg"
                      alt="Skyrise Apartments - Rooftop Amenities"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/images/skyrise-pool.jpeg"
                      alt="Skyrise Apartments - Swimming Pool"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="relative h-64 rounded-lg overflow-hidden">
                    <Image
                      src="/images/skyrise-interior.png"
                      alt="Skyrise Apartments - Interior"
                      fill
                      className="object-cover"
                    />
                  </div>
                </div>
              </div>

              {/* Unit Types */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Unit Types</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {unitTypes.map((unit, index) => (
                    <Card key={index} className="bg-bright-black/50 border-bright-yellow/20 overflow-hidden">
                      <CardContent className="p-6">
                        <h3 className="text-xl font-bold mb-2 text-bright-white">{unit.type}</h3>
                        <div className="flex items-center space-x-4 mb-3">
                          <div className="flex items-center">
                            <Home className="h-4 w-4 text-bright-yellow mr-1" />
                            <span className="text-bright-white/70">{unit.bedrooms} BHK</span>
                          </div>
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 text-bright-yellow mr-1" />
                            <span className="text-bright-white/70">{unit.size}</span>
                          </div>
                        </div>
                        <p className="text-bright-white/70 mb-4">{unit.description}</p>
                        <div className="space-y-2">
                          {unit.features.map((feature, idx) => (
                            <div key={idx} className="flex items-center">
                              <Check className="h-4 w-4 text-bright-yellow mr-2 flex-shrink-0" />
                              <span className="text-bright-white/80 text-sm">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Amenities */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Amenities</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {amenities.map((amenity, index) => (
                    <div key={index} className="flex items-start p-4 border border-bright-yellow/20 rounded-lg">
                      <Check className="h-5 w-5 text-bright-yellow mr-3 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-bright-white">{amenity.name}</h4>
                        <p className="text-bright-white/70 text-sm">{amenity.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Location */}
              <div>
                <motion.h2
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="text-3xl font-bold mb-6 text-bright-yellow relative inline-block"
                >
                  <span className="relative z-10">Location</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </motion.h2>

                <div className="rounded-lg overflow-hidden h-[400px] relative">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.7568587419567!2d32.58956857587536!3d0.3306999640132064!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x177dbb8080541c6d%3A0x9634932a8e1dde03!2sKololo%2C%20Kampala%2C%20Uganda!5e0!3m2!1sen!2sus!4v1654789542123!5m2!1sen!2sus"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    title="Skyrise Apartments Location"
                  />
                </div>
              </div>
            </div>

            {/* Right Column - Sidebar */}
            <div className="space-y-8">
              {/* Price Card */}
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Pricing Information</h3>
                  <div className="space-y-4">
                    <div>
                      <p className="text-bright-white/70 text-sm">Starting Price</p>
                      <p className="text-bright-yellow text-2xl font-bold">$135,000</p>
                    </div>
                    <div>
                      <p className="text-bright-white/70 text-sm">Reservation Fee</p>
                      <p className="text-bright-white font-medium">$5,000</p>
                    </div>
                    <div>
                      <p className="text-bright-white/70 text-sm">Payment Plan</p>
                      <p className="text-bright-white font-medium">40 Month Flexible Plan</p>
                    </div>
                    <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                      Reserve Now
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Contact Form */}
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Interested in Skyrise?</h3>
                  <ContactForm propertyId="skyrise" propertyTitle="Skyrise Apartments" simplified />
                </CardContent>
              </Card>

              {/* Virtual Tour Card */}
              <Card className="bg-bright-black/50 border-bright-yellow/20">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 text-bright-white">Experience Skyrise</h3>
                  <div className="relative h-48 rounded-lg overflow-hidden mb-4">
                    <Image
                      src="/images/skyrise-vr-tour.png"
                      alt="Skyrise Apartments Virtual Tour"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 bg-bright-black/40 flex items-center justify-center">
                      <Button
                        variant="outline"
                        className="border-bright-white text-bright-white hover:bg-bright-white/10"
                      >
                        Launch Virtual Tour
                      </Button>
                    </div>
                  </div>
                  <p className="text-bright-white/70 text-sm">
                    Experience Skyrise Apartments in immersive virtual reality. Explore the units, amenities, and
                    breathtaking views.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
