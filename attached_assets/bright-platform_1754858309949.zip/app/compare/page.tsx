"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useComparison } from "@/contexts/comparison-context"
import PropertyComparisonModal from "@/components/property-comparison-modal"

export default function ComparePage() {
  const { comparedProperties } = useComparison()
  const [showComparison, setShowComparison] = useState(true)
  const router = useRouter()

  useEffect(() => {
    if (comparedProperties.length < 2) {
      router.push("/real-estate")
    }
  }, [comparedProperties.length, router])

  const handleClose = () => {
    setShowComparison(false)
    router.push("/real-estate")
  }

  if (comparedProperties.length < 2) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">No Properties to Compare</h1>
          <p className="text-gray-600 mb-6">Please select at least 2 properties to compare.</p>
          <Button onClick={() => router.push("/real-estate")} className="bg-bright-yellow text-bright-black">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Properties
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <PropertyComparisonModal isOpen={showComparison} onClose={handleClose} properties={comparedProperties} />
    </div>
  )
}
