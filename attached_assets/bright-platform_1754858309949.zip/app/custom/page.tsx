import Image from "next/image"
import Link from "next/link"
import { ArrowRight, CheckCircle, Lightbulb, Settings, Sparkles, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ContactCTA from "@/components/contact-cta"

export default function CustomSolutionsPage() {
  return (
    <main className="flex-1">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-slate-900 to-slate-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Custom Solutions Background"
            fill
            className="object-cover"
          />
        </div>
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Custom Immersive Solutions
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Bespoke immersive technology solutions tailored to your unique business challenges and opportunities.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-bright-yellow to-bright-yellow-dark hover:from-bright-yellow-dark hover:to-bright-yellow text-bright-black"
              >
                <Link href="/contact" className="flex items-center">
                  Discuss Your Project <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white/20 hover:bg-white/10">
                <Link href="/portfolio?category=custom">View Custom Projects</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Approach Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Custom Approach</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We work closely with you to understand your unique challenges and develop tailored immersive solutions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Lightbulb className="h-10 w-10" />,
                title: "Discovery",
                description:
                  "We start by deeply understanding your business, challenges, and goals to identify the right immersive solution.",
              },
              {
                icon: <Settings className="h-10 w-10" />,
                title: "Design",
                description:
                  "Our team designs a custom solution that addresses your specific needs and integrates with your existing systems.",
              },
              {
                icon: <Sparkles className="h-10 w-10" />,
                title: "Development",
                description:
                  "We build your custom solution using the most appropriate immersive technologies and platforms.",
              },
              {
                icon: <Users className="h-10 w-10" />,
                title: "Deployment & Support",
                description:
                  "We ensure smooth implementation and provide ongoing support and enhancements as your needs evolve.",
              },
            ].map((step, index) => (
              <Card key={index} className="border-none shadow-lg">
                <CardContent className="p-6">
                  <div className="mb-4 p-2 rounded-lg bg-bright-yellow/10 w-fit text-bright-yellow">{step.icon}</div>
                  <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-slate-50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Custom Solution Use Cases</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Our custom immersive solutions can address a wide range of business challenges across industries.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Interactive Product Configurators",
                description: "Allow customers to customize and visualize products in real-time before purchase.",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Virtual Facility Tours",
                description: "Showcase manufacturing plants, warehouses, or campuses to stakeholders remotely.",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Specialized Training Simulations",
                description: "Train employees on complex procedures or equipment in a safe, virtual environment.",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Interactive Data Visualization",
                description:
                  "Transform complex data into intuitive, interactive 3D visualizations for better insights.",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Virtual Prototyping",
                description: "Test and iterate on product designs in VR before physical production.",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Immersive Customer Experiences",
                description: "Create memorable brand experiences that engage customers in new ways.",
                image: "/placeholder.svg?height=400&width=600",
              },
            ].map((useCase, index) => (
              <div key={index} className="overflow-hidden rounded-lg bg-white shadow-md h-full">
                <div className="relative h-48 w-full overflow-hidden">
                  <Image src={useCase.image || "/placeholder.svg"} alt={useCase.title} fill className="object-cover" />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{useCase.title}</h3>
                  <p className="text-muted-foreground">{useCase.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Why Choose Custom Solutions?</h2>
              <p className="text-lg text-muted-foreground mb-8">
                Custom immersive solutions provide unique advantages that off-the-shelf products simply can't match.
              </p>

              <div className="space-y-4">
                {[
                  "Tailored precisely to your specific business challenges and goals",
                  "Seamless integration with your existing systems and workflows",
                  "Proprietary solutions that provide competitive advantage",
                  "Scalable architecture that grows with your business",
                  "Ongoing support and enhancements from a dedicated team",
                  "Full ownership of the intellectual property",
                ].map((benefit, index) => (
                  <div key={index} className="flex items-start">
                    <div className="mr-3 mt-1 bg-bright-yellow/10 rounded-full p-1">
                      <CheckCircle className="h-4 w-4 text-bright-yellow" />
                    </div>
                    <p>{benefit}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="relative rounded-xl overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Custom VR Solution"
                  width={800}
                  height={600}
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 w-48 h-48 rounded-lg overflow-hidden shadow-lg hidden md:block">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="AR Application"
                  width={200}
                  height={200}
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Case Study Preview */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-slate-50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Success Stories</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              See how our custom solutions have helped businesses overcome unique challenges.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Manufacturing Visualization",
                description: "Custom VR solution reduced production planning time by 40%",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Healthcare Training",
                description: "Specialized medical simulation improved procedure success rates by 35%",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Retail Experience",
                description: "Interactive product configurator increased conversion rates by 28%",
                image: "/placeholder.svg?height=400&width=600",
              },
            ].map((caseStudy, index) => (
              <Link href={`/portfolio/case-study-${index + 1}`} key={index} className="group">
                <div className="overflow-hidden rounded-lg bg-white shadow-md transition-all duration-300 hover:shadow-xl">
                  <div className="relative h-64 w-full overflow-hidden">
                    <Image
                      src={caseStudy.image || "/placeholder.svg"}
                      alt={caseStudy.title}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{caseStudy.title}</h3>
                    <p className="text-muted-foreground mb-4">{caseStudy.description}</p>
                    <span className="text-sm font-medium text-bright-yellow flex items-center">
                      Read Case Study <ArrowRight className="ml-1 h-3 w-3" />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
