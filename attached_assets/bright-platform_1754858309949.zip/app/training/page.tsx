import Image from "next/image"
import Link from "next/link"
import { ArrowRight, BookOpen, CheckCircle, Headset, Users, Zap } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ContactCTA from "@/components/contact-cta"

export default function TrainingPage() {
  return (
    <main className="flex-1">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-slate-900 to-slate-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Training Background"
            fill
            className="object-cover"
          />
        </div>
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Immersive Training Solutions
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Enhance learning outcomes and skills development with VR/AR training experiences that improve retention
              and engagement.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-bright-yellow to-bright-yellow-dark hover:from-bright-yellow-dark hover:to-bright-yellow text-bright-black"
              >
                <Link href="/contact" className="flex items-center">
                  Book a Demo <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white/20 hover:bg-white/10">
                <Link href="/portfolio?category=training">View Training Projects</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Training Solutions</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Comprehensive immersive training solutions designed for various industries and learning objectives.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Headset className="h-10 w-10" />,
                title: "VR Training Simulations",
                description:
                  "Immersive virtual reality training environments that simulate real-world scenarios for hands-on practice without real-world risks.",
              },
              {
                icon: <Users className="h-10 w-10" />,
                title: "Soft Skills Development",
                description:
                  "Interactive scenarios for practicing communication, leadership, conflict resolution, and other interpersonal skills.",
              },
              {
                icon: <Zap className="h-10 w-10" />,
                title: "Technical Skills Training",
                description:
                  "Detailed simulations for machinery operation, maintenance procedures, and technical processes.",
              },
              {
                icon: <CheckCircle className="h-10 w-10" />,
                title: "Safety & Compliance",
                description:
                  "Immersive training for safety protocols, emergency procedures, and regulatory compliance requirements.",
              },
              {
                icon: <BookOpen className="h-10 w-10" />,
                title: "Educational Experiences",
                description:
                  "Interactive learning environments for educational institutions that make complex concepts tangible and engaging.",
              },
              {
                icon: <Users className="h-10 w-10" />,
                title: "Onboarding & Orientation",
                description:
                  "Virtual tours and interactive experiences to familiarize new employees with facilities, processes, and company culture.",
              },
            ].map((service, index) => (
              <Card key={index} className="border-none shadow-lg">
                <CardContent className="p-6">
                  <div className="mb-4 p-2 rounded-lg bg-bright-yellow/10 w-fit text-bright-yellow">{service.icon}</div>
                  <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-muted-foreground">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-slate-50">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Benefits of Immersive Training</h2>
              <p className="text-lg text-muted-foreground mb-8">
                Our VR/AR training solutions deliver measurable improvements in learning outcomes and operational
                efficiency.
              </p>

              <div className="space-y-4">
                {[
                  "Increase knowledge retention by up to 75% compared to traditional training",
                  "Reduce training time by 40% while improving competency",
                  "Practice high-risk scenarios in a safe, controlled environment",
                  "Cut training costs by eliminating travel and physical equipment needs",
                  "Provide consistent training experiences across all locations",
                  "Track detailed analytics on trainee performance and progress",
                ].map((benefit, index) => (
                  <div key={index} className="flex items-start">
                    <div className="mr-3 mt-1 bg-bright-yellow/10 rounded-full p-1">
                      <CheckCircle className="h-4 w-4 text-bright-yellow" />
                    </div>
                    <p>{benefit}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="relative rounded-xl overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="VR Training Experience"
                  width={800}
                  height={600}
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 w-48 h-48 rounded-lg overflow-hidden shadow-lg hidden md:block">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="AR Training App"
                  width={200}
                  height={200}
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Case Study Preview */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Success Stories</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              See how our clients have transformed their training programs with immersive technology.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Industrial Safety",
                description: "70% reduction in workplace incidents after implementing VR safety training",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Medical Training",
                description: "Surgical residents improved procedure times by 45% with VR practice",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Customer Service",
                description: "Call center satisfaction scores increased by 28% after soft skills VR training",
                image: "/placeholder.svg?height=400&width=600",
              },
            ].map((caseStudy, index) => (
              <Link href={`/portfolio/case-study-${index + 1}`} key={index} className="group">
                <div className="overflow-hidden rounded-lg bg-white shadow-md transition-all duration-300 hover:shadow-xl">
                  <div className="relative h-64 w-full overflow-hidden">
                    <Image
                      src={caseStudy.image || "/placeholder.svg"}
                      alt={caseStudy.title}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{caseStudy.title}</h3>
                    <p className="text-muted-foreground mb-4">{caseStudy.description}</p>
                    <span className="text-sm font-medium text-bright-yellow flex items-center">
                      Read Case Study <ArrowRight className="ml-1 h-3 w-3" />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
