"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { ArrowLeft, ArrowRight, Calendar, Clock, Users, MessageSquare, CheckCircle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { toast } from "@/components/ui/use-toast"

export default function BookDemoPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    // Step 1: Personal Information
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    jobTitle: "",

    // Step 2: Demo Preferences
    industry: "",
    teamSize: "",
    interests: [] as string[],
    requirements: "",

    // Step 3: Scheduling
    preferredDate: "",
    preferredTime: "",
    timezone: "UTC",
    demoType: "virtual",
    additionalNotes: "",
  })

  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleInputChange = (field: string, value: string | string[]) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))

    // Clear error for this field if it exists
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[field]
        return newErrors
      })
    }
  }

  const handleCheckboxChange = (value: string, checked: boolean) => {
    setFormData((prev) => {
      const interests = [...prev.interests]

      if (checked) {
        interests.push(value)
      } else {
        const index = interests.indexOf(value)
        if (index !== -1) {
          interests.splice(index, 1)
        }
      }

      return {
        ...prev,
        interests,
      }
    })

    // Clear error for interests if it exists
    if (errors.interests) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors.interests
        return newErrors
      })
    }
  }

  const validateStep = (stepNumber: number) => {
    const newErrors: Record<string, string> = {}

    if (stepNumber === 1) {
      if (!formData.firstName) newErrors.firstName = "First name is required"
      if (!formData.lastName) newErrors.lastName = "Last name is required"
      if (!formData.email) {
        newErrors.email = "Email is required"
      } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
        newErrors.email = "Please enter a valid email address"
      }
      if (!formData.company) newErrors.company = "Company name is required"
    } else if (stepNumber === 2) {
      if (!formData.industry) newErrors.industry = "Please select an industry"
      if (!formData.teamSize) newErrors.teamSize = "Please select your team size"
      if (formData.interests.length === 0) newErrors.interests = "Please select at least one area of interest"
    } else if (stepNumber === 3) {
      if (!formData.preferredDate) newErrors.preferredDate = "Please select a preferred date"
      if (!formData.preferredTime) newErrors.preferredTime = "Please select a preferred time"
      if (!formData.timezone) newErrors.timezone = "Please select your timezone"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const nextStep = () => {
    if (validateStep(step)) {
      setStep(step + 1)
      window.scrollTo(0, 0)
    }
  }

  const prevStep = () => {
    setStep(step - 1)
    window.scrollTo(0, 0)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateStep(step)) return

    setIsSubmitting(true)

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Demo request submitted",
        description: "We'll be in touch shortly to confirm your demo.",
      })

      // Redirect to thank you page
      router.push("/book-demo/thank-you")
    } catch (error) {
      toast({
        title: "Error submitting form",
        description: "There was a problem submitting your request. Please try again.",
        variant: "destructive",
      })
      setIsSubmitting(false)
    }
  }

  return (
    <main className="flex-1 bg-gradient-to-b from-bright-black to-bright-black-light py-16 px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-8">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-bright-white mb-4">Book a Demo</h1>
          <p className="text-bright-white/70 text-lg max-w-2xl mx-auto">
            Experience the power of Bright's immersive technology solutions with a personalized demonstration.
          </p>
        </div>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex justify-between items-center">
            {[1, 2, 3].map((stepNumber) => (
              <div key={stepNumber} className="flex-1 relative">
                <div className="flex flex-col items-center">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      step >= stepNumber
                        ? "bg-bright-yellow text-bright-black"
                        : "bg-bright-black/50 text-bright-white/50 border border-bright-yellow/20"
                    }`}
                  >
                    {step > stepNumber ? <CheckCircle className="h-5 w-5" /> : stepNumber}
                  </div>
                  <span className={`mt-2 text-sm ${step >= stepNumber ? "text-bright-white" : "text-bright-white/50"}`}>
                    {stepNumber === 1 ? "Your Information" : stepNumber === 2 ? "Demo Preferences" : "Schedule"}
                  </span>
                </div>

                {/* Connector line */}
                {stepNumber < 3 && (
                  <div className="absolute top-5 left-1/2 w-full h-0.5 bg-bright-black/50">
                    <div
                      className="h-full bg-bright-yellow transition-all duration-300"
                      style={{ width: step > stepNumber ? "100%" : "0%" }}
                    ></div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-bright-white">
              {step === 1 ? "Your Information" : step === 2 ? "Demo Preferences" : "Schedule Your Demo"}
            </CardTitle>
            <CardDescription>
              {step === 1
                ? "Tell us about yourself and your company"
                : step === 2
                  ? "Help us understand your needs and interests"
                  : "Choose a convenient time for your demo"}
            </CardDescription>
          </CardHeader>

          <CardContent>
            <form onSubmit={handleSubmit}>
              {/* Step 1: Personal Information */}
              {step === 1 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName" className="text-bright-white">
                        First Name <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange("firstName", e.target.value)}
                        className={`bg-bright-black/30 border-bright-yellow/20 text-bright-white ${
                          errors.firstName ? "border-red-500" : ""
                        }`}
                      />
                      {errors.firstName && <p className="text-red-500 text-xs mt-1">{errors.firstName}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="lastName" className="text-bright-white">
                        Last Name <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange("lastName", e.target.value)}
                        className={`bg-bright-black/30 border-bright-yellow/20 text-bright-white ${
                          errors.lastName ? "border-red-500" : ""
                        }`}
                      />
                      {errors.lastName && <p className="text-red-500 text-xs mt-1">{errors.lastName}</p>}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-bright-white">
                      Email Address <span className="text-red-500">*</span>
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className={`bg-bright-black/30 border-bright-yellow/20 text-bright-white ${
                        errors.email ? "border-red-500" : ""
                      }`}
                    />
                    {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-bright-white">
                      Phone Number
                    </Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="company" className="text-bright-white">
                        Company <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="company"
                        value={formData.company}
                        onChange={(e) => handleInputChange("company", e.target.value)}
                        className={`bg-bright-black/30 border-bright-yellow/20 text-bright-white ${
                          errors.company ? "border-red-500" : ""
                        }`}
                      />
                      {errors.company && <p className="text-red-500 text-xs mt-1">{errors.company}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="jobTitle" className="text-bright-white">
                        Job Title
                      </Label>
                      <Input
                        id="jobTitle"
                        value={formData.jobTitle}
                        onChange={(e) => handleInputChange("jobTitle", e.target.value)}
                        className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                      />
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 2: Demo Preferences */}
              {step === 2 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <Label htmlFor="industry" className="text-bright-white">
                      Industry <span className="text-red-500">*</span>
                    </Label>
                    <Select value={formData.industry} onValueChange={(value) => handleInputChange("industry", value)}>
                      <SelectTrigger
                        id="industry"
                        className={`bg-bright-black/30 border-bright-yellow/20 text-bright-white ${
                          errors.industry ? "border-red-500" : ""
                        }`}
                      >
                        <SelectValue placeholder="Select your industry" />
                      </SelectTrigger>
                      <SelectContent className="bg-bright-black border-bright-yellow/20">
                        <SelectItem value="real-estate" className="text-bright-white">
                          Real Estate
                        </SelectItem>
                        <SelectItem value="architecture" className="text-bright-white">
                          Architecture
                        </SelectItem>
                        <SelectItem value="interior-design" className="text-bright-white">
                          Interior Design
                        </SelectItem>
                        <SelectItem value="media" className="text-bright-white">
                          Media & Entertainment
                        </SelectItem>
                        <SelectItem value="education" className="text-bright-white">
                          Education & Training
                        </SelectItem>
                        <SelectItem value="corporate" className="text-bright-white">
                          Corporate
                        </SelectItem>
                        <SelectItem value="retail" className="text-bright-white">
                          Retail
                        </SelectItem>
                        <SelectItem value="healthcare" className="text-bright-white">
                          Healthcare
                        </SelectItem>
                        <SelectItem value="other" className="text-bright-white">
                          Other
                        </SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.industry && <p className="text-red-500 text-xs mt-1">{errors.industry}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="teamSize" className="text-bright-white">
                      Team Size <span className="text-red-500">*</span>
                    </Label>
                    <Select value={formData.teamSize} onValueChange={(value) => handleInputChange("teamSize", value)}>
                      <SelectTrigger
                        id="teamSize"
                        className={`bg-bright-black/30 border-bright-yellow/20 text-bright-white ${
                          errors.teamSize ? "border-red-500" : ""
                        }`}
                      >
                        <SelectValue placeholder="Select your team size" />
                      </SelectTrigger>
                      <SelectContent className="bg-bright-black border-bright-yellow/20">
                        <SelectItem value="1-10" className="text-bright-white">
                          1-10 employees
                        </SelectItem>
                        <SelectItem value="11-50" className="text-bright-white">
                          11-50 employees
                        </SelectItem>
                        <SelectItem value="51-200" className="text-bright-white">
                          51-200 employees
                        </SelectItem>
                        <SelectItem value="201-500" className="text-bright-white">
                          201-500 employees
                        </SelectItem>
                        <SelectItem value="501+" className="text-bright-white">
                          501+ employees
                        </SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.teamSize && <p className="text-red-500 text-xs mt-1">{errors.teamSize}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label className="text-bright-white">
                      Areas of Interest <span className="text-red-500">*</span>
                    </Label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      {[
                        { id: "vr-tours", label: "VR Tours" },
                        { id: "3d-visualization", label: "3D Visualization" },
                        { id: "training", label: "Training Solutions" },
                        { id: "media-production", label: "Media Production" },
                        { id: "virtual-events", label: "Virtual Events" },
                        { id: "custom-development", label: "Custom Development" },
                      ].map((interest) => (
                        <div key={interest.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={interest.id}
                            checked={formData.interests.includes(interest.id)}
                            onCheckedChange={(checked) => handleCheckboxChange(interest.id, checked as boolean)}
                            className="border-bright-yellow/50 data-[state=checked]:bg-bright-yellow data-[state=checked]:text-bright-black"
                          />
                          <Label htmlFor={interest.id} className="text-bright-white cursor-pointer">
                            {interest.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                    {errors.interests && <p className="text-red-500 text-xs mt-1">{errors.interests}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="requirements" className="text-bright-white">
                      Specific Requirements or Questions
                    </Label>
                    <Textarea
                      id="requirements"
                      value={formData.requirements}
                      onChange={(e) => handleInputChange("requirements", e.target.value)}
                      placeholder="Tell us about your specific needs or questions..."
                      className="bg-bright-black/30 border-bright-yellow/20 text-bright-white min-h-[100px]"
                    />
                  </div>
                </motion.div>
              )}

              {/* Step 3: Scheduling */}
              {step === 3 && (
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <Label htmlFor="demoType" className="text-bright-white">
                      Demo Type
                    </Label>
                    <RadioGroup
                      value={formData.demoType}
                      onValueChange={(value) => handleInputChange("demoType", value)}
                      className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2"
                    >
                      <div className="flex items-center space-x-2 border border-bright-yellow/20 rounded-md p-4 cursor-pointer hover:bg-bright-black/30">
                        <RadioGroupItem
                          value="virtual"
                          id="virtual"
                          className="border-bright-yellow/50 text-bright-yellow"
                        />
                        <Label htmlFor="virtual" className="flex items-center cursor-pointer">
                          <div className="bg-bright-yellow/10 p-2 rounded-full mr-2">
                            <MessageSquare className="h-4 w-4 text-bright-yellow" />
                          </div>
                          <div>
                            <div className="font-medium text-bright-white">Virtual Demo</div>
                            <div className="text-xs text-bright-white/70">Online presentation via video call</div>
                          </div>
                        </Label>
                      </div>

                      <div className="flex items-center space-x-2 border border-bright-yellow/20 rounded-md p-4 cursor-pointer hover:bg-bright-black/30">
                        <RadioGroupItem
                          value="in-person"
                          id="in-person"
                          className="border-bright-yellow/50 text-bright-yellow"
                        />
                        <Label htmlFor="in-person" className="flex items-center cursor-pointer">
                          <div className="bg-bright-yellow/10 p-2 rounded-full mr-2">
                            <Users className="h-4 w-4 text-bright-yellow" />
                          </div>
                          <div>
                            <div className="font-medium text-bright-white">In-Person Demo</div>
                            <div className="text-xs text-bright-white/70">Face-to-face at your location</div>
                          </div>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="preferredDate" className="text-bright-white">
                        Preferred Date <span className="text-red-500">*</span>
                      </Label>
                      <div className="relative">
                        <Input
                          id="preferredDate"
                          type="date"
                          value={formData.preferredDate}
                          onChange={(e) => handleInputChange("preferredDate", e.target.value)}
                          className={`bg-bright-black/30 border-bright-yellow/20 text-bright-white ${
                            errors.preferredDate ? "border-red-500" : ""
                          }`}
                          min={new Date().toISOString().split("T")[0]}
                        />
                        <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-bright-white/50 pointer-events-none" />
                      </div>
                      {errors.preferredDate && <p className="text-red-500 text-xs mt-1">{errors.preferredDate}</p>}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="preferredTime" className="text-bright-white">
                        Preferred Time <span className="text-red-500">*</span>
                      </Label>
                      <Select
                        value={formData.preferredTime}
                        onValueChange={(value) => handleInputChange("preferredTime", value)}
                      >
                        <SelectTrigger
                          id="preferredTime"
                          className={`bg-bright-black/30 border-bright-yellow/20 text-bright-white ${
                            errors.preferredTime ? "border-red-500" : ""
                          }`}
                        >
                          <SelectValue placeholder="Select a time" />
                        </SelectTrigger>
                        <SelectContent className="bg-bright-black border-bright-yellow/20">
                          <SelectItem value="morning" className="text-bright-white">
                            Morning (9AM - 12PM)
                          </SelectItem>
                          <SelectItem value="afternoon" className="text-bright-white">
                            Afternoon (12PM - 4PM)
                          </SelectItem>
                          <SelectItem value="evening" className="text-bright-white">
                            Evening (4PM - 6PM)
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      {errors.preferredTime && <p className="text-red-500 text-xs mt-1">{errors.preferredTime}</p>}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="timezone" className="text-bright-white">
                      Timezone <span className="text-red-500">*</span>
                    </Label>
                    <Select value={formData.timezone} onValueChange={(value) => handleInputChange("timezone", value)}>
                      <SelectTrigger
                        id="timezone"
                        className={`bg-bright-black/30 border-bright-yellow/20 text-bright-white ${
                          errors.timezone ? "border-red-500" : ""
                        }`}
                      >
                        <SelectValue placeholder="Select your timezone" />
                      </SelectTrigger>
                      <SelectContent className="bg-bright-black border-bright-yellow/20">
                        <SelectItem value="UTC" className="text-bright-white">
                          UTC (Coordinated Universal Time)
                        </SelectItem>
                        <SelectItem value="EST" className="text-bright-white">
                          EST (Eastern Standard Time)
                        </SelectItem>
                        <SelectItem value="CST" className="text-bright-white">
                          CST (Central Standard Time)
                        </SelectItem>
                        <SelectItem value="MST" className="text-bright-white">
                          MST (Mountain Standard Time)
                        </SelectItem>
                        <SelectItem value="PST" className="text-bright-white">
                          PST (Pacific Standard Time)
                        </SelectItem>
                        <SelectItem value="EAT" className="text-bright-white">
                          EAT (East Africa Time)
                        </SelectItem>
                        <SelectItem value="CET" className="text-bright-white">
                          CET (Central European Time)
                        </SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.timezone && <p className="text-red-500 text-xs mt-1">{errors.timezone}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="additionalNotes" className="text-bright-white">
                      Additional Notes
                    </Label>
                    <Textarea
                      id="additionalNotes"
                      value={formData.additionalNotes}
                      onChange={(e) => handleInputChange("additionalNotes", e.target.value)}
                      placeholder="Any additional information that might help us prepare for your demo..."
                      className="bg-bright-black/30 border-bright-yellow/20 text-bright-white min-h-[100px]"
                    />
                  </div>

                  <div className="flex items-start space-x-2 pt-4">
                    <Checkbox
                      id="consent"
                      className="border-bright-yellow/50 data-[state=checked]:bg-bright-yellow data-[state=checked]:text-bright-black mt-1"
                      defaultChecked
                    />
                    <Label htmlFor="consent" className="text-bright-white/70 text-sm">
                      By submitting this form, I agree to Bright's privacy policy and consent to being contacted
                      regarding my demo request.
                    </Label>
                  </div>
                </motion.div>
              )}

              <div className="flex justify-between mt-8">
                {step > 1 && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={prevStep}
                    className="border-bright-yellow/20 text-bright-yellow hover:bg-bright-yellow/10"
                  >
                    <ArrowLeft className="h-4 w-4 mr-2" /> Back
                  </Button>
                )}

                {step < 3 ? (
                  <Button
                    type="button"
                    onClick={nextStep}
                    className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 ml-auto"
                  >
                    Next <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                ) : (
                  <Button
                    type="submit"
                    className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 ml-auto"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Submitting..." : "Book Your Demo"}
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Benefits Section */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="border-bright-yellow/10 bg-bright-black/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-bright-white">Why Book a Demo?</CardTitle>
              <CardDescription>Experience firsthand how our solutions can transform your business</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                {
                  title: "Personalized Experience",
                  description: "See solutions specific to your industry and business challenges.",
                },
                {
                  title: "Expert Guidance",
                  description: "Get insights from our specialists on implementation and best practices.",
                },
                {
                  title: "Interactive Showcase",
                  description: "Try our immersive technologies and experience their impact firsthand.",
                },
                {
                  title: "ROI Discussion",
                  description: "Understand the potential return on investment for your specific use case.",
                },
              ].map((item, index) => (
                <div key={index} className="flex">
                  <div className="mr-4 bg-bright-yellow/10 p-2 rounded-full h-fit">
                    <CheckCircle className="h-5 w-5 text-bright-yellow" />
                  </div>
                  <div>
                    <h3 className="font-medium text-bright-white">{item.title}</h3>
                    <p className="text-bright-white/70 text-sm">{item.description}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-bright-yellow/10 bg-bright-yellow/5 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-bright-white">What to Expect</CardTitle>
              <CardDescription>Our demo process is designed to be informative and valuable</CardDescription>
            </CardHeader>
            <CardContent>
              <ol className="space-y-3 ml-6 list-decimal text-bright-white/80">
                <li>Brief introduction to Bright and our approach</li>
                <li>Interactive demonstration of relevant solutions</li>
                <li>Discussion of your specific needs and challenges</li>
                <li>Q&A session with our specialists</li>
                <li>Next steps and implementation options</li>
              </ol>

              <div className="mt-6 pt-6 border-t border-bright-yellow/10">
                <div className="flex items-center">
                  <div className="bg-bright-yellow/10 p-2 rounded-full mr-3">
                    <Clock className="h-5 w-5 text-bright-yellow" />
                  </div>
                  <div>
                    <h3 className="font-medium text-bright-white">Demo Duration</h3>
                    <p className="text-bright-white/70 text-sm">
                      Our standard demos typically last 30-45 minutes, with additional time for questions and
                      discussion.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  )
}
