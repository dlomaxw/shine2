import Link from "next/link"
import { CheckCircle, Calendar, ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function ThankYouPage() {
  return (
    <main className="flex-1">
      <section className="py-12 md:py-24 bg-gradient-to-r from-bright-black to-bright-black-light">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="bg-bright-yellow/20 p-4 rounded-full mb-4">
              <CheckCircle className="h-12 w-12 text-bright-yellow" />
            </div>
            <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl text-bright-white">
              Thank You for Booking a Demo!
            </h1>
            <p className="mx-auto max-w-[700px] text-bright-white/70 md:text-xl">
              We've received your request and our team will contact you shortly to confirm your demo.
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="max-w-3xl mx-auto">
            <Card className="border-bright-yellow/10">
              <CardContent className="p-6 md:p-8">
                <div className="flex items-center mb-6">
                  <div className="bg-bright-yellow/10 p-2 rounded-full mr-4">
                    <Calendar className="h-6 w-6 text-bright-yellow" />
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold">What Happens Next?</h2>
                    <p className="text-muted-foreground">Here's what you can expect</p>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="flex">
                    <div className="mr-4 shrink-0 w-8 h-8 rounded-full bg-bright-yellow/10 flex items-center justify-center text-bright-yellow font-medium">
                      1
                    </div>
                    <div>
                      <h3 className="font-medium">Confirmation Email</h3>
                      <p className="text-muted-foreground">
                        You'll receive a confirmation email with a summary of your demo request.
                      </p>
                    </div>
                  </div>

                  <div className="flex">
                    <div className="mr-4 shrink-0 w-8 h-8 rounded-full bg-bright-yellow/10 flex items-center justify-center text-bright-yellow font-medium">
                      2
                    </div>
                    <div>
                      <h3 className="font-medium">Scheduling Call</h3>
                      <p className="text-muted-foreground">
                        A member of our team will contact you within 24 hours to confirm the date and time for your
                        demo.
                      </p>
                    </div>
                  </div>

                  <div className="flex">
                    <div className="mr-4 shrink-0 w-8 h-8 rounded-full bg-bright-yellow/10 flex items-center justify-center text-bright-yellow font-medium">
                      3
                    </div>
                    <div>
                      <h3 className="font-medium">Calendar Invitation</h3>
                      <p className="text-muted-foreground">
                        Once confirmed, you'll receive a calendar invitation with all the details and joining
                        instructions.
                      </p>
                    </div>
                  </div>

                  <div className="flex">
                    <div className="mr-4 shrink-0 w-8 h-8 rounded-full bg-bright-yellow/10 flex items-center justify-center text-bright-yellow font-medium">
                      4
                    </div>
                    <div>
                      <h3 className="font-medium">Demo Session</h3>
                      <p className="text-muted-foreground">
                        Enjoy your personalized demo session with our specialists.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-6 border-t border-gray-200">
                  <h3 className="font-medium mb-2">Have questions before your demo?</h3>
                  <p className="text-muted-foreground mb-4">
                    Feel free to reach out to our team at{" "}
                    <a href="mailto:brightthoughtsservices@gmail.com" className="text-bright-yellow hover:underline">
                      brightthoughtsservices@gmail.com
                    </a>{" "}
                    or call us at{" "}
                    <a href="tel:+256750421224" className="text-bright-yellow hover:underline">
                      +256 750 421 224
                    </a>
                    .
                  </p>
                </div>
              </CardContent>
            </Card>

            <div className="mt-8 text-center">
              <p className="text-muted-foreground mb-4">
                While you wait for your demo, explore more about our solutions
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Button variant="outline" className="border-bright-yellow/20">
                  <Link href="/portfolio" className="flex items-center">
                    View Our Portfolio <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button variant="outline" className="border-bright-yellow/20">
                  <Link href="/blog" className="flex items-center">
                    Read Our Blog <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                  <Link href="/" className="flex items-center">
                    Back to Home
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
