"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowRight, Lightbulb, Cog, Users, Zap } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ContactCTA from "@/components/contact-cta"

export default function CustomSolutionsPage() {
  const customSolutions = [
    {
      title: "AI-Powered Analytics",
      description: "Custom machine learning solutions for business intelligence and predictive analytics",
      icon: <Lightbulb className="h-8 w-8" />,
    },
    {
      title: "IoT Integration",
      description: "Smart building solutions with IoT sensors and automated systems",
      icon: <Cog className="h-8 w-8" />,
    },
    {
      title: "Custom VR Experiences",
      description: "Bespoke virtual reality applications tailored to your specific industry needs",
      icon: <Zap className="h-8 w-8" />,
    },
    {
      title: "Enterprise Solutions",
      description: "Large-scale digital transformation projects for enterprise clients",
      icon: <Users className="h-8 w-8" />,
    },
  ]

  const processSteps = [
    {
      step: "01",
      title: "Discovery & Analysis",
      description: "We analyze your business challenges and identify opportunities for innovation",
    },
    {
      step: "02",
      title: "Solution Design",
      description: "Our team designs a custom solution tailored to your specific requirements",
    },
    {
      step: "03",
      title: "Development & Testing",
      description: "We build and rigorously test your solution to ensure optimal performance",
    },
    {
      step: "04",
      title: "Deployment & Support",
      description: "We deploy your solution and provide ongoing support and maintenance",
    },
  ]

  return (
    <main className="flex min-h-screen flex-col bg-bright-black text-bright-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-bright-black to-bright-black-light text-white overflow-hidden py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight relative inline-block"
            >
              <span className="relative z-10">Custom Solutions</span>
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-gray-300 mb-8"
            >
              Bespoke immersive technology solutions tailored to your specific business challenges and requirements.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-bright-yellow to-bright-yellow-dark hover:from-bright-yellow-dark hover:to-bright-yellow text-bright-black"
              >
                <Link href="/contact" className="flex items-center">
                  Start Your Project <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white/20 hover:bg-white/10">
                <Link href="/portfolio">View Our Work</Link>
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Custom Solutions Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold mb-4 relative inline-block"
            >
              <span className="relative z-10">Our Custom Solutions</span>
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-bright-white/70 max-w-3xl mx-auto"
            >
              We create innovative solutions that address your unique business challenges.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {customSolutions.map((solution, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="border-none shadow-lg h-full bg-bright-black/50 border-bright-yellow/20">
                  <CardContent className="p-6">
                    <div className="mb-4 p-2 rounded-lg bg-bright-yellow/10 w-fit text-bright-yellow">
                      {solution.icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-2 text-bright-white">{solution.title}</h3>
                    <p className="text-bright-white/70">{solution.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-bright-black/50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold mb-4 relative inline-block"
            >
              <span className="relative z-10">Our Process</span>
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </motion.h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="mb-4">
                  <span className="text-4xl font-bold text-bright-yellow">{step.step}</span>
                </div>
                <h3 className="text-xl font-semibold mb-2 text-bright-white">{step.title}</h3>
                <p className="text-bright-white/70">{step.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
