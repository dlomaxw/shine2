"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowRight, Eye, Home, Building, Camera } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ContactCTA from "@/components/contact-cta"

export default function VirtualToursPage() {
  return (
    <main className="flex min-h-screen flex-col bg-bright-black text-bright-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-bright-black to-bright-black-light text-white overflow-hidden py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight relative inline-block"
            >
              <span className="relative z-10">Virtual Property Tours</span>
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-gray-300 mb-8"
            >
              Immersive 3D virtual tours that allow potential buyers to explore properties remotely with stunning detail
              and interactivity.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-bright-yellow to-bright-yellow-dark hover:from-bright-yellow-dark hover:to-bright-yellow text-bright-black"
              >
                <Link href="/contact" className="flex items-center">
                  Get Started <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white/20 hover:bg-white/10">
                <Link href="/real-estate">View Examples</Link>
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Eye className="h-10 w-10" />,
                title: "360° Virtual Tours",
                description:
                  "Complete 360-degree immersive experiences that let viewers explore every corner of your property.",
              },
              {
                icon: <Home className="h-10 w-10" />,
                title: "Interactive Floor Plans",
                description: "Dynamic floor plans with clickable hotspots and detailed room information.",
              },
              {
                icon: <Building className="h-10 w-10" />,
                title: "Virtual Staging",
                description: "Digitally furnish empty spaces to help buyers visualize the property's potential.",
              },
              {
                icon: <Camera className="h-10 w-10" />,
                title: "High-Quality Imagery",
                description: "Professional photography and rendering for stunning visual presentation.",
              },
            ].map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="border-none shadow-lg h-full bg-bright-black/50 border-bright-yellow/20">
                  <CardContent className="p-6">
                    <div className="mb-4 p-2 rounded-lg bg-bright-yellow/10 w-fit text-bright-yellow">
                      {feature.icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-2 text-bright-white">{feature.title}</h3>
                    <p className="text-bright-white/70">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
