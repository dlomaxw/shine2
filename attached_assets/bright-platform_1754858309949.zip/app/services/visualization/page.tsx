"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowRight, Layers, Palette, Ruler, Lightbulb } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ContactCTA from "@/components/contact-cta"

export default function VisualizationPage() {
  return (
    <main className="flex min-h-screen flex-col bg-bright-black text-bright-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-bright-black to-bright-black-light text-white overflow-hidden py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight relative inline-block"
            >
              <span className="relative z-10">Architectural Visualization</span>
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-gray-300 mb-8"
            >
              Photorealistic renderings and animations of properties before construction, helping you visualize and
              market your projects effectively.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-bright-yellow to-bright-yellow-dark hover:from-bright-yellow-dark hover:to-bright-yellow text-bright-black"
              >
                <Link href="/contact" className="flex items-center">
                  Start Your Project <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white/20 hover:bg-white/10">
                <Link href="/architecture">View Portfolio</Link>
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: <Layers className="h-10 w-10" />,
                title: "3D Rendering",
                description: "Photorealistic 3D renderings that bring your architectural designs to life.",
              },
              {
                icon: <Palette className="h-10 w-10" />,
                title: "Material Visualization",
                description: "Accurate representation of materials, textures, and finishes.",
              },
              {
                icon: <Ruler className="h-10 w-10" />,
                title: "Technical Drawings",
                description: "Detailed technical illustrations and construction documentation.",
              },
              {
                icon: <Lightbulb className="h-10 w-10" />,
                title: "Lighting Studies",
                description: "Natural and artificial lighting analysis and visualization.",
              },
            ].map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="border-none shadow-lg h-full bg-bright-black/50 border-bright-yellow/20">
                  <CardContent className="p-6">
                    <div className="mb-4 p-2 rounded-lg bg-bright-yellow/10 w-fit text-bright-yellow">
                      {service.icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-2 text-bright-white">{service.title}</h3>
                    <p className="text-bright-white/70">{service.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
