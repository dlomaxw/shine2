"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowRight, Film, ImageIcon, Play, Headset } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { type MediaItem, getMediaItems } from "@/lib/api-client"
import ContactCTA from "@/components/contact-cta"

export default function MediaPage() {
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("all")

  useEffect(() => {
    async function loadMedia() {
      try {
        const items = await getMediaItems()
        setMediaItems(items)
      } catch (error) {
        console.error("Error loading media:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadMedia()
  }, [])

  const filteredItems = activeTab === "all" ? mediaItems : mediaItems.filter((item) => item.type === activeTab)

  const getMediaIcon = (type: string) => {
    switch (type) {
      case "video":
        return <Film className="h-10 w-10" />
      case "image":
        return <ImageIcon className="h-10 w-10" />
      case "vr":
        return <Headset className="h-10 w-10" />
      default:
        return <Film className="h-10 w-10" />
    }
  }

  return (
    <main className="flex-1">
      <section className="relative bg-gradient-to-r from-slate-900 to-slate-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Media Production Background"
            fill
            className="object-cover"
          />
        </div>
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Immersive Media & Entertainment
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              From traditional video production to cutting-edge VR experiences, we create engaging content that
              captivates audiences.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
              >
                <Link href="/contact" className="flex items-center">
                  Book a Consultation <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white/20 hover:bg-white/10">
                <Link href="/portfolio?category=media">View Media Projects</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Media Gallery</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Explore our diverse portfolio of media productions and immersive experiences.
            </p>
          </div>

          <Tabs defaultValue="all" onValueChange={setActiveTab}>
            <div className="flex justify-center mb-8">
              <TabsList>
                <TabsTrigger value="all">All Media</TabsTrigger>
                <TabsTrigger value="video">Videos</TabsTrigger>
                <TabsTrigger value="vr">VR Experiences</TabsTrigger>
                <TabsTrigger value="image">Images</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value={activeTab}>
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[1, 2, 3, 4, 5, 6].map((item) => (
                    <Card key={item} className="overflow-hidden">
                      <div className="animate-pulse">
                        <div className="h-48 bg-slate-200"></div>
                        <CardContent className="p-6">
                          <div className="h-4 bg-slate-200 rounded w-3/4 mb-4"></div>
                          <div className="h-3 bg-slate-200 rounded w-full mb-2"></div>
                          <div className="h-3 bg-slate-200 rounded w-2/3"></div>
                        </CardContent>
                      </div>
                    </Card>
                  ))}
                </div>
              ) : filteredItems.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredItems.map((item) => (
                    <Link href={`/media/${item.id}`} key={item.id} className="group">
                      <Card className="overflow-hidden h-full transition-all duration-300 hover:shadow-lg">
                        <div className="relative h-48 w-full overflow-hidden">
                          <Image
                            src={item.thumbnailUrl || "/placeholder.svg"}
                            alt={item.title}
                            fill
                            className="object-cover transition-transform duration-300 group-hover:scale-105"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                          <div className="absolute bottom-4 left-4 flex items-center">
                            <div className="bg-primary/90 rounded-full p-2 mr-2">
                              {item.type === "video" ? (
                                <Play className="h-4 w-4 text-white" />
                              ) : item.type === "vr" ? (
                                <Headset className="h-4 w-4 text-white" />
                              ) : (
                                <ImageIcon className="h-4 w-4 text-white" />
                              )}
                            </div>
                            <span className="text-white text-sm font-medium">
                              {item.type === "video" ? "Video" : item.type === "vr" ? "VR Experience" : "Image"}
                            </span>
                          </div>
                        </div>
                        <CardContent className="p-6">
                          <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                          <p className="text-muted-foreground mb-4 line-clamp-2">{item.description}</p>
                          <div className="flex flex-wrap gap-2">
                            {item.tags.map((tag, index) => (
                              <span key={index} className="text-xs bg-slate-100 px-2 py-1 rounded-full">
                                {tag}
                              </span>
                            ))}
                          </div>
                        </CardContent>
                      </Card>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">No media items found for this category.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </section>

      <section className="py-16 px-4 md:px-6 lg:px-8 bg-slate-50">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Media Production Services</h2>
              <p className="text-lg text-muted-foreground mb-8">
                From concept to delivery, we provide end-to-end media production services tailored to your needs.
              </p>

              <div className="space-y-6">
                {[
                  {
                    icon: <Film className="h-10 w-10 text-primary" />,
                    title: "Video Production",
                    description:
                      "Professional video production for commercials, corporate videos, music videos, and more.",
                  },
                  {
                    icon: <Headset className="h-10 w-10 text-primary" />,
                    title: "VR Experiences",
                    description: "Immersive virtual reality experiences for entertainment, education, and marketing.",
                  },
                  {
                    icon: <ImageIcon className="h-10 w-10 text-primary" />,
                    title: "360° Photography",
                    description: "High-quality 360° photography for virtual tours, real estate, and events.",
                  },
                ].map((service, index) => (
                  <div key={index} className="flex gap-4">
                    <div className="mt-1">{service.icon}</div>
                    <div>
                      <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                      <p className="text-muted-foreground">{service.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="relative rounded-xl overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Media Production"
                  width={800}
                  height={600}
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 w-48 h-48 rounded-lg overflow-hidden shadow-lg hidden md:block">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="VR Production"
                  width={200}
                  height={200}
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
