"use client"

import Image from "next/image"
import Link from "next/link"
import { ArrowRight, Building, Check, Compass, Home, Ruler } from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ContactCTA from "@/components/contact-cta"
import ProjectGallery from "@/components/project-gallery"

export default function ArchitecturePage() {
  return (
    <main className="flex-1">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-slate-900 to-slate-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a0b636bae87bcc2975fca450f582d3fc_high-TlUhD7qnAPEvvgWaJMUdjAsLVapZRn.webp"
            alt="Innovative Architecture"
            fill
            className="object-cover"
          />
        </div>
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-3xl">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight relative inline-block"
            >
              <span className="relative z-10">Architectural Visualization Excellence</span>
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-gray-300 mb-8"
            >
              Bringing architectural designs to life with immersive 3D visualization and interactive experiences.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-bright-yellow to-bright-yellow-dark hover:from-bright-yellow-dark hover:to-bright-yellow text-bright-black relative overflow-hidden group"
              >
                <Link href="/contact" className="flex items-center">
                  <span className="relative z-10">
                    Start Your Project{" "}
                    <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                  </span>
                  <span className="absolute inset-0 bg-white/20 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></span>
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white/20 hover:bg-white/10">
                <Link href="/portfolio?category=architecture">View Architecture Projects</Link>
              </Button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold mb-4 relative inline-block"
            >
              <span className="relative z-10">Our Architectural Services</span>
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-muted-foreground max-w-3xl mx-auto"
            >
              Comprehensive visualization solutions for architects, developers, and design professionals.
            </motion.p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Building className="h-10 w-10" />,
                title: "Exterior Visualization",
                description:
                  "Photorealistic renderings of building exteriors, showcasing materials, lighting, and contextual surroundings.",
              },
              {
                icon: <Home className="h-10 w-10" />,
                title: "Interior Visualization",
                description:
                  "Detailed interior renderings that bring spaces to life with accurate lighting, materials, and furnishings.",
              },
              {
                icon: <Compass className="h-10 w-10" />,
                title: "Site Planning",
                description:
                  "Comprehensive site visualizations showing landscaping, access points, and relationship to surroundings.",
              },
              {
                icon: <Ruler className="h-10 w-10" />,
                title: "3D Architectural Modeling",
                description: "Detailed 3D models for design development, presentation, and construction documentation.",
              },
              {
                icon: <Building className="h-10 w-10" />,
                title: "Animation & Walkthroughs",
                description:
                  "Dynamic animations and virtual walkthroughs that showcase architectural spaces in motion.",
              },
              {
                icon: <Compass className="h-10 w-10" />,
                title: "VR/AR Experiences",
                description: "Immersive virtual and augmented reality experiences for interactive design exploration.",
              },
            ].map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="border-none shadow-lg h-full hover:shadow-xl transition-shadow duration-300">
                  <CardContent className="p-6">
                    <div className="mb-4 p-2 rounded-lg bg-bright-yellow/10 w-fit text-bright-yellow">
                      {service.icon}
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                    <p className="text-muted-foreground">{service.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Showcase */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-slate-50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-3xl md:text-4xl font-bold mb-4 relative inline-block"
            >
              <span className="relative z-10">Architectural Portfolio</span>
              <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-muted-foreground max-w-3xl mx-auto"
            >
              Explore our architectural visualization projects across different styles and building types.
            </motion.p>
          </div>

          <Tabs defaultValue="residential" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList>
                <TabsTrigger value="residential">Residential</TabsTrigger>
                <TabsTrigger value="commercial">Commercial</TabsTrigger>
                <TabsTrigger value="institutional">Institutional</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="residential">
              <ProjectGallery
                images={[
                  {
                    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a0b636bae87bcc2975fca450f582d3fc_high-TlUhD7qnAPEvvgWaJMUdjAsLVapZRn.webp",
                    alt: "Contemporary Curved Edge House",
                    description: "Modern residential design with smooth curved edges and glass facade",
                    category: "Residential",
                  },
                  {
                    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a1823870bc6ac6aa38e4f0dbb81d9939_high-x1dgCbfVnigzQF0W7PqZ5LAy0W4wq2.webp",
                    alt: "Circular Window Residence",
                    description: "Innovative brick construction with circular window openings and open concept living",
                    category: "Residential",
                  },
                  {
                    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/aa67ef8cee448ed470f7311e5773ad0d_high-rDL21lQPU8UM6iuDU7DctpIMCQ7ssa.webp",
                    alt: "Compact Modern House",
                    description: "Space-efficient design with wood accents and contemporary aesthetic",
                    category: "Residential",
                  },
                  {
                    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a73eace8e0fe3bc6126cae4885913eb1_high-yX8gv14HkIpCDE3sNs7iwpcU7UMjuz.webp",
                    alt: "Orange Curved Residence",
                    description: "Distinctive orange facade with rounded corners and modern design elements",
                    category: "Residential",
                  },
                  {
                    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a57f83d6751c0593f6cb6dfc08b3f36e_high-xJa6fMMLfwpgS79VYkoe5k3hW0PYAi.webp",
                    alt: "Perforated Facade House",
                    description: "Modern white house with decorative perforated facade elements",
                    category: "Residential",
                  },
                ]}
                className="mb-8 rounded-xl overflow-hidden shadow-xl"
              />
            </TabsContent>

            <TabsContent value="commercial">
              <ProjectGallery
                images={[
                  {
                    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/b1bc8af70abb972d2dc86ce553c0f630_high-mKKCHBT8xcXlYlGv1UwfNVGZaf4iMK.webp",
                    alt: "Waterfront High-Rise",
                    description: "Luxury apartment tower with curved balconies and panoramic ocean views",
                    category: "Commercial",
                  },
                  {
                    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a445adaf066b475c362fb2b508e2f3c6_high-uTeM1aV8RHxnjqPit6zCkeKmx8FWP5.webp",
                    alt: "Modern Apartment Tower",
                    description: "Contemporary high-rise with staggered balconies and distinctive architectural style",
                    category: "Commercial",
                  },
                  {
                    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/A%20smooth%20gradient%20transition%20with%20bright%20lens%20flare%20renders%20a%20modern%20retirement%20building%20complex%20by%20a%20lake...and%20hospital%20components.%20%20Printed%20facades%2C%20large%20windows%2C%20decorative%20railings%2C%20balconies%2C%20green%20landscaping%2C%20palm%20trees%2C%20a.jpg-9ED00I4BQuFgCUuN2t5tFEk6XRbk25.jpeg",
                    alt: "Waterfront Resort Complex",
                    description: "Luxury hotel with extensive landscaping and waterfront access",
                    category: "Commercial",
                  },
                  {
                    src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/An%20overhead%20bird%E2%80%99s%20eye%20view%20of%20a%20layered%20papier-ma%CC%82che%CC%81%20style%203D%20render%20depicting%20a%20modern%20retirement%20buil...h%20commercial%20and%20hospital%20sections.%20%20Printed%20facades%2C%20large%20windows%2C%20balconies%2C%20green%20landscaping%2C%20palm%20trees%20and%20pathwa.jpg-PJLIrtQVaZWTUOMfTXIqb5WEL29LKH.jpeg",
                    alt: "Island Resort Development",
                    description: "Beachfront hotel complex with tropical landscaping and water access",
                    category: "Commercial",
                  },
                ]}
                className="mb-8 rounded-xl overflow-hidden shadow-xl"
              />
            </TabsContent>

            <TabsContent value="institutional">
              <ProjectGallery
                images={[
                  {
                    src: "/images/brick-arches.webp",
                    alt: "Contemporary Community Center",
                    description: "Modern interpretation of traditional brick architecture with dramatic arches",
                    category: "Institutional",
                  },
                  {
                    src: "/images/building3.webp",
                    alt: "University Building",
                    description: "Educational facility designed for collaborative learning",
                    category: "Institutional",
                  },
                  {
                    src: "/images/building7.webp",
                    alt: "Cultural Center",
                    description: "Public space celebrating local heritage through innovative design",
                    category: "Institutional",
                  },
                ]}
                className="mb-8 rounded-xl overflow-hidden shadow-xl"
              />
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="order-2 lg:order-1"
            >
              <div className="relative rounded-xl overflow-hidden shadow-xl">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a857e0f798a1373e05fde2481ecd6718_high-gcskXyL6UqIaTrKLUlIBaiOPAmxOwm.webp"
                  alt="Architectural Visualization"
                  width={800}
                  height={600}
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 w-48 h-48 rounded-lg overflow-hidden shadow-lg hidden md:block">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a0b636bae87bcc2975fca450f582d3fc_high-TlUhD7qnAPEvvgWaJMUdjAsLVapZRn.webp"
                  alt="Architectural Detail"
                  width={200}
                  height={200}
                  className="object-cover"
                />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="order-1 lg:order-2"
            >
              <h2 className="text-3xl md:text-4xl font-bold mb-6 relative inline-block">
                <span className="relative z-10">Benefits of Architectural Visualization</span>
                <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Our immersive visualization solutions deliver measurable advantages for architectural projects.
              </p>

              <div className="space-y-4">
                {[
                  "Communicate design intent clearly to clients and stakeholders",
                  "Identify design issues early in the process, saving time and costs",
                  "Secure project approvals and funding with compelling visuals",
                  "Market properties before construction begins",
                  "Explore design alternatives quickly and efficiently",
                  "Enhance collaboration between architects, engineers, and clients",
                ].map((benefit, index) => (
                  <motion.div
                    key={index}
                    className="flex items-start"
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <div className="mr-3 mt-1 bg-bright-yellow/10 rounded-full p-1">
                      <Check className="h-4 w-4 text-bright-yellow" />
                    </div>
                    <p>{benefit}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
