import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function PortfolioPage() {
  const categories = [
    { id: "all", label: "All Projects" },
    { id: "real-estate", label: "Real Estate" },
    { id: "media", label: "Media & Entertainment" },
    { id: "training", label: "Training" },
    { id: "corporate", label: "Corporate" },
    { id: "digital", label: "Digital" },
  ]

  const projects = [
    {
      id: 1,
      title: "Luxury Property VR Tours",
      category: "real-estate",
      description: "Immersive virtual tours for high-end residential properties.",
      image: "/placeholder.svg?height=600&width=800",
    },
    {
      id: 2,
      title: "Corporate Training Simulator",
      category: "training",
      description: "VR-based safety training for industrial environments.",
      image: "/placeholder.svg?height=600&width=800",
    },
    {
      id: 3,
      title: "Interactive Music Video",
      category: "media",
      description: "360° interactive music video experience for a leading artist.",
      image: "/placeholder.svg?height=600&width=800",
    },
    {
      id: 4,
      title: "Virtual Office Environment",
      category: "corporate",
      description: "Collaborative virtual workspace for remote teams.",
      image: "/placeholder.svg?height=600&width=800",
    },
    {
      id: 5,
      title: "Real Estate Development Visualization",
      category: "real-estate",
      description: "3D visualization of upcoming residential development.",
      image: "/placeholder.svg?height=600&width=800",
    },
    {
      id: 6,
      title: "E-commerce AR Application",
      category: "digital",
      description: "AR app allowing customers to visualize products in their space.",
      image: "/placeholder.svg?height=600&width=800",
    },
    {
      id: 7,
      title: "Medical Training Simulation",
      category: "training",
      description: "VR simulation for medical professionals practicing procedures.",
      image: "/placeholder.svg?height=600&width=800",
    },
    {
      id: 8,
      title: "Interactive Documentary",
      category: "media",
      description: "Award-winning interactive documentary with VR elements.",
      image: "/placeholder.svg?height=600&width=800",
    },
    {
      id: 9,
      title: "Corporate Event Platform",
      category: "corporate",
      description: "Virtual event platform for large-scale corporate gatherings.",
      image: "/placeholder.svg?height=600&width=800",
    },
  ]

  return (
    <main className="flex-1">
      <section className="bg-slate-50 py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Our Portfolio</h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                Explore our diverse range of immersive technology projects across various industries.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <Tabs defaultValue="all" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList className="grid grid-cols-2 md:grid-cols-6">
                {categories.map((category) => (
                  <TabsTrigger key={category.id} value={category.id}>
                    {category.label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            {categories.map((category) => (
              <TabsContent key={category.id} value={category.id} className="mt-0">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {projects
                    .filter((project) => category.id === "all" || project.category === category.id)
                    .map((project) => (
                      <Link href={`/portfolio/${project.id}`} key={project.id} className="group">
                        <div className="overflow-hidden rounded-lg bg-white shadow-md transition-all duration-300 hover:shadow-xl">
                          <div className="relative h-64 w-full overflow-hidden">
                            <Image
                              src={project.image || "/placeholder.svg"}
                              alt={project.title}
                              fill
                              className="object-cover transition-transform duration-300 group-hover:scale-105"
                            />
                          </div>
                          <div className="p-6">
                            <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                            <p className="text-muted-foreground mb-4">{project.description}</p>
                            <span className="text-sm font-medium text-primary flex items-center">
                              View Project <ArrowRight className="ml-1 h-3 w-3" />
                            </span>
                          </div>
                        </div>
                      </Link>
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      <section className="py-12 md:py-24 bg-slate-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter">Ready to Create Your Own Success Story?</h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                Let's discuss how Bright's immersive technology solutions can transform your business.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg">
                <Link href="/contact">Contact Us</Link>
              </Button>
              <Button size="lg" variant="outline">
                <Link href="/about">Learn About Our Process</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
