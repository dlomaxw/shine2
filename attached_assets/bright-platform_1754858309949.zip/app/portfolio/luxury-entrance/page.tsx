"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, MapPin, Building2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import ContactCTA from "@/components/contact-cta"

export default function LuxuryEntrancePage() {
  return (
    <main className="flex min-h-screen flex-col bg-bright-black text-bright-white">
      {/* Hero Section */}
      <section className="relative h-[70vh] lg:h-[80vh]">
        <div className="absolute inset-0">
          <Image
            src="/images/modern-entrance-gate.jpeg"
            alt="Luxury Entrance Design - Contemporary Gate and Landscaping"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-r from-bright-black via-bright-black/80 to-transparent"></div>
        </div>

        <div className="relative z-10 container mx-auto px-4 h-full flex items-center">
          <div className="max-w-3xl">
            <Link href="/" className="inline-flex items-center text-bright-yellow hover:text-bright-yellow/80 mb-6">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Link>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
              <div className="inline-flex items-center px-4 py-2 bg-bright-yellow/10 border border-bright-yellow/20 rounded-full mb-6">
                <Building2 className="h-4 w-4 text-bright-yellow mr-2" />
                <span className="text-bright-yellow font-medium">Premium Architecture</span>
              </div>

              <h1 className="text-4xl md:text-6xl font-bold mb-4">
                <span className="relative inline-block">
                  <span className="relative z-10">Luxury Entrance</span>
                  <span className="absolute -bottom-2 left-0 w-full h-1 bg-bright-yellow"></span>
                </span>
                <br />
                <span className="text-bright-yellow">Design</span>
              </h1>

              <h2 className="text-xl md:text-2xl text-bright-yellow/80 font-medium mb-4">
                Contemporary Gate and Premium Landscaping
              </h2>

              <div className="flex items-center space-x-2 mb-6">
                <MapPin className="h-5 w-5 text-bright-yellow" />
                <span className="text-bright-white font-medium">Exclusive Residential Community</span>
              </div>

              <p className="text-lg text-bright-white/80 mb-8 max-w-2xl">
                A stunning example of contemporary entrance design that sets the tone for luxury living. This elegant
                gateway features premium materials, sophisticated landscaping, and architectural elements that create an
                impressive first impression.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                  View Design Portfolio
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-bright-white text-bright-white hover:bg-bright-white/10"
                >
                  Contact Designer
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Project Details */}
      <section className="py-20 px-4 md:px-6 lg:px-8 bg-bright-black">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-3xl font-bold mb-6 text-bright-yellow">Design Overview</h3>
              <p className="text-bright-white/80 mb-6 leading-relaxed">
                This luxury entrance design exemplifies contemporary architectural excellence. The sophisticated gate
                structure, combined with meticulously planned landscaping, creates a grand entrance that reflects the
                premium nature of the residential community beyond.
              </p>

              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="bg-bright-yellow/10 border border-bright-yellow/20 rounded-lg p-4">
                  <h4 className="font-semibold text-bright-white mb-2">Design Style</h4>
                  <p className="text-bright-yellow font-bold text-xl">Contemporary</p>
                </div>
                <div className="bg-bright-yellow/10 border border-bright-yellow/20 rounded-lg p-4">
                  <h4 className="font-semibold text-bright-white mb-2">Materials</h4>
                  <p className="text-bright-yellow font-bold text-xl">Premium</p>
                </div>
                <div className="bg-bright-yellow/10 border border-bright-yellow/20 rounded-lg p-4">
                  <h4 className="font-semibold text-bright-white mb-2">Landscaping</h4>
                  <p className="text-bright-yellow font-bold text-xl">Elegant</p>
                </div>
                <div className="bg-bright-yellow/10 border border-bright-yellow/20 rounded-lg p-4">
                  <h4 className="font-semibold text-bright-white mb-2">Security</h4>
                  <p className="text-bright-yellow font-bold text-xl">Advanced</p>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-xl font-semibold text-bright-white">Design Features</h4>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <div className="h-2 w-2 bg-bright-yellow rounded-full mr-3"></div>
                    <span className="text-bright-white/80">Automated gate system</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-2 w-2 bg-bright-yellow rounded-full mr-3"></div>
                    <span className="text-bright-white/80">Premium stone and metal finishes</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-2 w-2 bg-bright-yellow rounded-full mr-3"></div>
                    <span className="text-bright-white/80">Integrated lighting design</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-2 w-2 bg-bright-yellow rounded-full mr-3"></div>
                    <span className="text-bright-white/80">Manicured landscape elements</span>
                  </li>
                  <li className="flex items-center">
                    <div className="h-2 w-2 bg-bright-yellow rounded-full mr-3"></div>
                    <span className="text-bright-white/80">Security camera integration</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="space-y-6">
              <div className="relative h-80 rounded-lg overflow-hidden">
                <Image
                  src="/images/modern-entrance-gate.jpeg"
                  alt="Luxury Entrance Gate Design"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="relative h-40 rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=300&width=400&text=Landscape+Details"
                    alt="Landscape Details"
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="relative h-40 rounded-lg overflow-hidden">
                  <Image
                    src="/placeholder.svg?height=300&width=400&text=Night+Lighting"
                    alt="Night Lighting"
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
