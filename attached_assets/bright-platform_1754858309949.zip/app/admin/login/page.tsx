"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Eye, EyeOff, Loader2, LogIn } from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { toast } from "@/components/ui/use-toast"
import { useAdmin } from "@/contexts/admin-context"

export default function AdminLoginPage() {
  const router = useRouter()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const { login } = useAdmin()

  useEffect(() => {
    console.log("AdminLoginPage component mounted")
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const success = await login(email, password)
      if (success) {
        toast({
          title: "Login successful",
          description: "Welcome to the Bright admin dashboard.",
        })

        // Redirect to dashboard
        router.push("/admin/dashboard")
      } else {
        toast({
          title: "Login failed",
          description: "Invalid email or password. Try admin@bright.com / password",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Login error",
        description: "An unexpected error occurred. Please try again later.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-bright-black via-bright-black-light to-bright-black">
      {/* Background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-bright-yellow/10 via-transparent to-transparent"></div>
        <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-bright-yellow/5 via-transparent to-transparent"></div>

        {/* Grid lines */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,225,0,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,225,0,0.05)_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
      </div>

      <div
        className="container relative z-10 mx-auto px-4 py-16 flex-1 flex items-center justify-center"
        style={{ border: "1px solid red" }}
      >
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <Link href="/" className="inline-block">
              <div className="flex items-center justify-center">
                <div className="relative h-12 w-12 mr-2">
                  <Image src="/images/logo.png" alt="Bright Logo" fill className="object-contain" />
                </div>
                <span className="text-3xl font-bold text-bright-yellow">BRIGHT</span>
              </div>
            </Link>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-bright-black/40 backdrop-blur-md rounded-xl border border-bright-yellow/20 shadow-xl overflow-hidden"
          >
            <div className="p-6 sm:p-8">
              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-bright-white">Admin Login</h1>
                <p className="text-bright-white/70 mt-1">Access your admin dashboard</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-bright-white">
                    Email
                  </Label>
                  <div className="relative">
                    <Input
                      id="email"
                      type="email"
                      placeholder="admin@example.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="bg-bright-black/50 border-bright-yellow/20 text-bright-white placeholder:text-bright-white/50 focus-visible:ring-bright-yellow/50"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <Label htmlFor="password" className="text-bright-white">
                      Password
                    </Label>
                    <Link href="/admin/forgot-password" className="text-xs text-bright-yellow hover:underline">
                      Forgot password?
                    </Link>
                  </div>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      className="bg-bright-black/50 border-bright-yellow/20 text-bright-white placeholder:text-bright-white/50 focus-visible:ring-bright-yellow/50"
                    />
                    <button
                      type="button"
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-bright-white/70 hover:text-bright-white"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="remember"
                    checked={rememberMe}
                    onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                    className="border-bright-yellow/50 data-[state=checked]:bg-bright-yellow data-[state=checked]:text-bright-black"
                  />
                  <Label htmlFor="remember" className="text-sm text-bright-white/70">
                    Remember me
                  </Label>
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 relative overflow-hidden group"
                >
                  {isLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <span className="relative z-10 flex items-center">
                        <LogIn className="mr-2 h-4 w-4" /> Sign In
                      </span>
                      <span className="absolute inset-0 bg-white/20 transform -translate-x-full group-hover:translate-x-0 transition-transform duration-300"></span>
                    </>
                  )}
                </Button>
              </form>

              <div className="mt-6 text-center">
                <p className="text-bright-white/70 text-sm">
                  Don't have admin access?{" "}
                  <Link href="/contact" className="text-bright-yellow hover:underline">
                    Contact us
                  </Link>{" "}
                  to request access.
                </p>
              </div>
            </div>
          </motion.div>

          <div className="mt-8 text-center">
            <Link href="/" className="text-bright-white/70 hover:text-bright-white text-sm">
              &larr; Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
