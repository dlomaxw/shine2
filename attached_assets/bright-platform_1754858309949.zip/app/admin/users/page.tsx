"use client"

import { useState } from "react"
import { Search, Filter, MoreHorizontal, Edit, Trash2, UserPlus, Shield, Mail } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"

// Sample users data
const users = [
  {
    id: 1,
    name: "Admin User",
    email: "admin@bright.com",
    role: "admin",
    status: "active",
    lastLogin: "2023-10-05 14:32:45",
    avatar: "/images/logo.png",
  },
  {
    id: 2,
    name: "John Editor",
    email: "john@bright.com",
    role: "editor",
    status: "active",
    lastLogin: "2023-10-03 09:15:22",
    avatar: null,
  },
  {
    id: 3,
    name: "Sarah Viewer",
    email: "sarah@bright.com",
    role: "viewer",
    status: "active",
    lastLogin: "2023-09-28 16:45:12",
    avatar: null,
  },
  {
    id: 4,
    name: "Michael Smith",
    email: "michael@bright.com",
    role: "editor",
    status: "inactive",
    lastLogin: "2023-09-15 11:30:45",
    avatar: null,
  },
  {
    id: 5,
    name: "Emily Johnson",
    email: "emily@bright.com",
    role: "viewer",
    status: "pending",
    lastLogin: null,
    avatar: null,
  },
]

export default function UsersPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isAddUserOpen, setIsAddUserOpen] = useState(false)
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    role: "viewer",
  })

  // Filter users based on search query
  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.role.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleAddUser = () => {
    // Validate form
    if (!newUser.name || !newUser.email) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    // Simulate adding a user
    toast({
      title: "User added",
      description: `${newUser.name} has been added as a ${newUser.role}.`,
    })

    // Reset form and close dialog
    setNewUser({
      name: "",
      email: "",
      role: "viewer",
    })
    setIsAddUserOpen(false)
  }

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "admin":
        return "bg-red-500/20 text-red-500 hover:bg-red-500/30"
      case "editor":
        return "bg-blue-500/20 text-blue-500 hover:bg-blue-500/30"
      case "viewer":
        return "bg-green-500/20 text-green-500 hover:bg-green-500/30"
      default:
        return "bg-gray-500/20 text-gray-500 hover:bg-gray-500/30"
    }
  }

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500/20 text-green-500 hover:bg-green-500/30"
      case "inactive":
        return "bg-gray-500/20 text-gray-500 hover:bg-gray-500/30"
      case "pending":
        return "bg-yellow-500/20 text-yellow-500 hover:bg-yellow-500/30"
      default:
        return "bg-gray-500/20 text-gray-500 hover:bg-gray-500/30"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">Users</h1>
          <p className="text-bright-white/70">Manage user accounts and permissions</p>
        </div>

        <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
          <DialogTrigger asChild>
            <Button className="mt-4 sm:mt-0 bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
              <UserPlus className="h-4 w-4 mr-2" /> Add New User
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-bright-black border-bright-yellow/20">
            <DialogHeader>
              <DialogTitle className="text-bright-white">Add New User</DialogTitle>
              <DialogDescription>Create a new user account and set their permissions.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-bright-white">
                  Full Name
                </Label>
                <Input
                  id="name"
                  value={newUser.name}
                  onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                  className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email" className="text-bright-white">
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                  className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="role" className="text-bright-white">
                  Role
                </Label>
                <Select value={newUser.role} onValueChange={(value) => setNewUser({ ...newUser, role: value })}>
                  <SelectTrigger id="role" className="bg-bright-black/30 border-bright-yellow/20 text-bright-white">
                    <SelectValue placeholder="Select a role" />
                  </SelectTrigger>
                  <SelectContent className="bg-bright-black border-bright-yellow/20">
                    <SelectItem value="admin" className="text-bright-white">
                      Admin
                    </SelectItem>
                    <SelectItem value="editor" className="text-bright-white">
                      Editor
                    </SelectItem>
                    <SelectItem value="viewer" className="text-bright-white">
                      Viewer
                    </SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-bright-white/50 mt-1">
                  {newUser.role === "admin"
                    ? "Full access to all features and settings."
                    : newUser.role === "editor"
                      ? "Can edit content but cannot manage users or settings."
                      : "View-only access to content."}
                </p>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsAddUserOpen(false)}
                className="border-bright-yellow/20 text-bright-white"
              >
                Cancel
              </Button>
              <Button className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90" onClick={handleAddUser}>
                Add User
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-bright-white/50" />
          <Input
            placeholder="Search users..."
            className="pl-9 bg-bright-black/30 border-bright-yellow/10 text-bright-white"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="border-bright-yellow/20 text-bright-white">
              <Filter className="h-4 w-4 mr-2" /> Filter
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-bright-black border-bright-yellow/20">
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              All Users
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Admins
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Editors
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Viewers
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-bright-yellow/10" />
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Active
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Inactive
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Users Table */}
      <div className="border border-bright-yellow/10 rounded-md overflow-hidden">
        <Table>
          <TableHeader className="bg-bright-black/50">
            <TableRow className="hover:bg-bright-black/30 border-bright-yellow/10">
              <TableHead className="text-bright-white/70">User</TableHead>
              <TableHead className="text-bright-white/70">Role</TableHead>
              <TableHead className="text-bright-white/70">Status</TableHead>
              <TableHead className="text-bright-white/70">Last Login</TableHead>
              <TableHead className="text-right text-bright-white/70">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsers.length > 0 ? (
              filteredUsers.map((user) => (
                <TableRow key={user.id} className="hover:bg-bright-black/30 border-bright-yellow/10">
                  <TableCell className="font-medium text-bright-white">
                    <div className="flex items-center">
                      <Avatar className="h-8 w-8 mr-3">
                        <AvatarImage src={user.avatar || undefined} alt={user.name} />
                        <AvatarFallback className="bg-bright-yellow/20 text-bright-yellow">
                          {user.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p>{user.name}</p>
                        <p className="text-xs text-bright-white/50">{user.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getRoleBadgeColor(user.role)}>{user.role}</Badge>
                  </TableCell>
                  <TableCell>
                    <Badge className={getStatusBadgeColor(user.status)}>{user.status}</Badge>
                  </TableCell>
                  <TableCell className="text-bright-white/70">
                    {user.lastLogin || <span className="text-bright-white/30">Never</span>}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-bright-white/70 hover:text-bright-white">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-bright-black border-bright-yellow/20">
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Edit className="h-4 w-4 mr-2" /> Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Mail className="h-4 w-4 mr-2" /> Send Email
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Shield className="h-4 w-4 mr-2" /> Change Role
                        </DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-bright-yellow/10" />
                        <DropdownMenuItem className="text-red-500 hover:text-red-600 hover:bg-red-500/10">
                          <Trash2 className="h-4 w-4 mr-2" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-8 text-bright-white/50">
                  No users found matching your search.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
