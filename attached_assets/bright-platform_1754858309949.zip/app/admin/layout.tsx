"use client"

import { DropdownMenuLabel } from "@/components/ui/dropdown-menu"

import type React from "react"
import { Suspense } from "react"
import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname, useRouter } from "next/navigation"
import {
  LayoutDashboard,
  Images,
  FileText,
  Palette,
  CuboidIcon as Cube,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronRight,
  Users,
  MessageSquare,
  Home,
  Bell,
  Search,
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { AdminProvider, useAdmin } from "@/contexts/admin-context"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface SidebarItemProps {
  icon: React.ReactNode
  label: string
  href: string
  isActive: boolean
  isCollapsed: boolean
  subItems?: { label: string; href: string }[]
}

function SidebarItem({ icon, label, href, isActive, isCollapsed, subItems }: SidebarItemProps) {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()

  // If this item has subitems and is active, open the dropdown by default
  const hasActiveSubItem = subItems?.some((item) => pathname === item.href)

  useEffect(() => {
    if (hasActiveSubItem) {
      setIsOpen(true)
    }
  }, [hasActiveSubItem])

  return (
    <div>
      <Link
        href={subItems ? "#" : href}
        onClick={(e) => {
          if (subItems) {
            e.preventDefault()
            setIsOpen(!isOpen)
          }
        }}
        className={cn(
          "flex items-center py-2 px-3 rounded-md transition-colors relative group",
          isActive || hasActiveSubItem
            ? "bg-bright-yellow/20 text-bright-yellow"
            : "text-bright-white/70 hover:text-bright-white hover:bg-bright-yellow/10",
        )}
      >
        <span className="mr-3">{icon}</span>
        {!isCollapsed && (
          <>
            <span className="flex-1">{label}</span>
            {subItems && <ChevronRight className={cn("h-4 w-4 transition-transform", isOpen ? "rotate-90" : "")} />}
          </>
        )}

        {/* Tooltip for collapsed state */}
        {isCollapsed && (
          <div className="absolute left-full ml-2 px-2 py-1 bg-bright-black text-bright-white text-xs rounded opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-opacity z-50">
            {label}
          </div>
        )}
      </Link>

      {/* Dropdown for subitems */}
      {subItems && !isCollapsed && (
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="pl-10 pr-3 py-1 space-y-1">
                {subItems.map((item, index) => {
                  const isSubItemActive = pathname === item.href

                  return (
                    <Link
                      key={index}
                      href={item.href}
                      className={cn(
                        "block py-1.5 px-2 rounded-md text-sm transition-colors",
                        isSubItemActive
                          ? "bg-bright-yellow/10 text-bright-yellow"
                          : "text-bright-white/70 hover:text-bright-white hover:bg-bright-yellow/5",
                      )}
                    >
                      {item.label}
                    </Link>
                  )
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      )}
    </div>
  )
}

function AdminLayoutContent({ children }: { children: React.ReactNode }) {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false)
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false)
  const [isSearchOpen, setIsSearchOpen] = useState(false)
  const pathname = usePathname()
  const { user, isAuthenticated, isLoading, logout, notifications } = useAdmin()
  const router = useRouter()

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated && pathname !== "/admin/login") {
      router.push("/admin/login")
    }
  }, [isLoading, isAuthenticated, pathname, router])

  // Allow access to /admin/login without authentication
  if (pathname === "/admin/login") {
    return (
      <div className="min-h-screen bg-bright-black-light flex flex-col">
        <main className="flex-1">{children}</main>
      </div>
    )
  }

  const unreadNotifications = notifications.filter((n) => !n.read).length

  const sidebarItems = [
    {
      icon: <LayoutDashboard className="h-5 w-5" />,
      label: "Dashboard",
      href: "/admin/dashboard",
    },
    {
      icon: <FileText className="h-5 w-5" />,
      label: "Content",
      href: "#",
      subItems: [
        { label: "Pages", href: "/admin/content/pages" },
        { label: "Blog Posts", href: "/admin/content/blog" },
        { label: "Services", href: "/admin/content/services" },
        { label: "Editor", href: "/admin/content/editor" },
      ],
    },
    {
      icon: <Images className="h-5 w-5" />,
      label: "Media",
      href: "/admin/media",
    },
    {
      icon: <Cube className="h-5 w-5" />,
      label: "3D Models",
      href: "/admin/models",
    },
    {
      icon: <Palette className="h-5 w-5" />,
      label: "Appearance",
      href: "#",
      subItems: [
        { label: "Colors", href: "/admin/appearance/colors" },
        { label: "Typography", href: "/admin/appearance/typography" },
        { label: "Components", href: "/admin/appearance/components" },
      ],
    },
    {
      icon: <Users className="h-5 w-5" />,
      label: "Users",
      href: "/admin/users",
    },
    {
      icon: <MessageSquare className="h-5 w-5" />,
      label: "Inquiries",
      href: "/admin/inquiries",
    },
    {
      icon: <Settings className="h-5 w-5" />,
      label: "Settings",
      href: "/admin/settings",
    },
  ]

  if (isLoading) {
    return (
      <div className="min-h-screen bg-bright-black-light flex items-center justify-center">
        <div className="space-y-4 text-center">
          <div className="relative h-16 w-16 mx-auto">
            <Image src="/images/logo.png" alt="Bright Logo" fill className="object-contain animate-pulse" />
          </div>
          <p className="text-bright-white">Loading admin dashboard...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return null // or a redirect component
  }

  return (
    <div className="min-h-screen bg-bright-black-light flex flex-col">
      {/* Top Navigation */}
      <header className="bg-bright-black border-b border-bright-yellow/10 h-16 flex items-center px-4 sticky top-0 z-30">
        <div className="flex items-center justify-between w-full">
          <div className="flex items-center">
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-bright-white mr-2"
              onClick={() => setIsMobileSidebarOpen(!isMobileSidebarOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>

            <Link href="/admin/dashboard" className="flex items-center">
              <div className="relative h-8 w-8 mr-2">
                <Image src="/images/logo.png" alt="Bright Logo" fill className="object-contain" />
              </div>
              <span className="font-bold text-xl text-bright-yellow hidden sm:inline">BRIGHT</span>
              <span className="text-bright-white/50 text-sm ml-2 hidden lg:inline">Admin Dashboard</span>
            </Link>
          </div>

          <div className="flex items-center space-x-2">
            {/* Search */}
            <div className="relative hidden md:block">
              {isSearchOpen ? (
                <div className="absolute right-0 w-64 animate-in fade-in slide-in-from-top-2 duration-300">
                  <Input
                    placeholder="Search..."
                    className="bg-bright-black/30 border-bright-yellow/20 text-bright-white pr-8"
                    autoFocus
                    onBlur={() => setIsSearchOpen(false)}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full text-bright-white/70"
                    onClick={() => setIsSearchOpen(false)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-bright-white/70 hover:text-bright-white"
                  onClick={() => setIsSearchOpen(true)}
                >
                  <Search className="h-5 w-5" />
                </Button>
              )}
            </div>

            {/* Notifications */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative text-bright-white/70 hover:text-bright-white">
                  <Bell className="h-5 w-5" />
                  {unreadNotifications > 0 && (
                    <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80 bg-bright-black border-bright-yellow/20">
                <DropdownMenuLabel className="flex items-center justify-between">
                  <span>Notifications</span>
                  {notifications.length > 0 && (
                    <Button variant="ghost" size="sm" className="h-8 text-xs">
                      Mark all as read
                    </Button>
                  )}
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-bright-yellow/10" />
                {notifications.length > 0 ? (
                  <>
                    {notifications.map((notification) => (
                      <DropdownMenuItem
                        key={notification.id}
                        className="flex flex-col items-start p-3 focus:bg-bright-yellow/5"
                      >
                        <div className="flex items-center w-full">
                          <div className="flex-1">
                            <p className="text-sm font-medium text-bright-white flex items-center">
                              {notification.title}
                              {!notification.read && (
                                <span className="ml-2 w-2 h-2 bg-bright-yellow rounded-full"></span>
                              )}
                            </p>
                            <p className="text-xs text-bright-white/70 mt-1">{notification.message}</p>
                          </div>
                          <span className="text-xs text-bright-white/50">
                            {new Date(notification.date).toLocaleDateString()}
                          </span>
                        </div>
                      </DropdownMenuItem>
                    ))}
                    <DropdownMenuSeparator className="bg-bright-yellow/10" />
                    <DropdownMenuItem className="text-center text-bright-yellow hover:text-bright-yellow hover:bg-bright-yellow/5">
                      View all notifications
                    </DropdownMenuItem>
                  </>
                ) : (
                  <div className="py-4 text-center text-bright-white/50">
                    <p>No notifications</p>
                  </div>
                )}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={user?.avatar || "/placeholder.svg"} alt={user?.name || "User"} />
                    <AvatarFallback className="bg-bright-yellow/20 text-bright-yellow text-2xl">
                      {user?.name?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-bright-black border-bright-yellow/20">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium text-bright-white">{user?.name}</p>
                    <p className="text-xs text-bright-white/70">{user?.email}</p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-bright-yellow/10" />
                <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/5">
                  <Link href="/admin/profile" className="w-full">
                    Profile
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/5">
                  <Link href="/admin/settings" className="w-full">
                    Settings
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-bright-yellow/10" />
                <DropdownMenuItem
                  className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/5"
                  onClick={logout}
                >
                  <LogOut className="mr-2 h-4 w-4" /> Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="ghost" size="sm" className="text-bright-white/70 hover:text-bright-white">
              <Link href="/" className="flex items-center">
                <Home className="h-4 w-4 mr-1" /> View Site
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar for desktop */}
        <aside
          className={cn(
            "bg-bright-black border-r border-bright-yellow/10 h-[calc(100vh-4rem)] sticky top-16 hidden md:block transition-all duration-300",
            isSidebarCollapsed ? "w-16" : "w-64",
          )}
        >
          <div className="p-4 h-full flex flex-col">
            <div className="flex-1 space-y-1">
              {sidebarItems.map((item, index) => (
                <SidebarItem
                  key={index}
                  icon={item.icon}
                  label={item.label}
                  href={item.href}
                  isActive={pathname === item.href}
                  isCollapsed={isSidebarCollapsed}
                  subItems={item.subItems}
                />
              ))}
            </div>

            <Button
              variant="ghost"
              size="icon"
              className="self-end text-bright-white/70 hover:text-bright-white"
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
            >
              {isSidebarCollapsed ? (
                <ChevronRight className="h-5 w-5" />
              ) : (
                <ChevronRight className="h-5 w-5 rotate-180" />
              )}
            </Button>
          </div>
        </aside>

        {/* Mobile sidebar */}
        <AnimatePresence>
          {isMobileSidebarOpen && (
            <>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.5 }}
                exit={{ opacity: 0 }}
                className="fixed inset-0 bg-black z-40 md:hidden"
                onClick={() => setIsMobileSidebarOpen(false)}
              />

              <motion.aside
                initial={{ x: "-100%" }}
                animate={{ x: 0 }}
                exit={{ x: "-100%" }}
                transition={{ type: "tween", duration: 0.3 }}
                className="fixed left-0 top-0 h-full w-64 bg-bright-black border-r border-bright-yellow/10 z-50 md:hidden"
              >
                <div className="p-4 h-full flex flex-col">
                  <div className="flex items-center justify-between mb-6">
                    <Link href="/admin/dashboard" className="flex items-center">
                      <div className="relative h-8 w-8 mr-2">
                        <Image src="/images/logo.png" alt="Bright Logo" fill className="object-contain" />
                      </div>
                      <span className="font-bold text-xl text-bright-yellow">BRIGHT</span>
                    </Link>

                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-bright-white/70 hover:text-bright-white"
                      onClick={() => setIsMobileSidebarOpen(false)}
                    >
                      <X className="h-5 w-5" />
                    </Button>
                  </div>

                  <div className="flex-1 space-y-1">
                    {sidebarItems.map((item, index) => (
                      <SidebarItem
                        key={index}
                        icon={item.icon}
                        label={item.label}
                        href={item.href}
                        isActive={pathname === item.href}
                        isCollapsed={false}
                        subItems={item.subItems}
                      />
                    ))}
                  </div>
                </div>
              </motion.aside>
            </>
          )}
        </AnimatePresence>

        {/* Main content */}
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  )
}

// Loading fallback component for Suspense
function AdminLayoutLoading() {
  return (
    <div className="min-h-screen bg-bright-black-light flex items-center justify-center">
      <div className="space-y-4 text-center">
        <div className="relative h-16 w-16 mx-auto">
          <Image src="/images/logo.png" alt="Bright Logo" fill className="object-contain animate-pulse" />
        </div>
        <p className="text-bright-white">Loading admin dashboard...</p>
      </div>
    </div>
  )
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <AdminProvider>
      <Suspense fallback={<AdminLayoutLoading />}>
        <AdminLayoutContent>{children}</AdminLayoutContent>
      </Suspense>
    </AdminProvider>
  )
}
