"use client"

import { useState } from "react"
import { Save, RefreshCw, Check, Eye, EyeOff, Camera, User, Lock, Bell, Shield } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAdmin } from "@/contexts/admin-context"

export default function ProfilePage() {
  const { user } = useAdmin()
  const [activeTab, setActiveTab] = useState("profile")
  const [isSaving, setIsSaving] = useState(false)
  const [isSaved, setIsSaved] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)

  // Profile settings state
  const [profileSettings, setProfileSettings] = useState({
    name: "Admin User",
    email: "admin@bright.com",
    phone: "+1 (123) 456-7890",
    jobTitle: "Administrator",
    bio: "Platform administrator responsible for managing content and users.",
    avatarUrl: "/images/logo.png",
  })

  // Password settings state
  const [passwordSettings, setPasswordSettings] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  // Notification settings state
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    browserNotifications: true,
    marketingEmails: false,
  })

  // Account settings state
  const [accountSettings, setAccountSettings] = useState({
    twoFactorAuth: false,
    sessionTimeout: "30min",
    loginAlerts: true,
  })

  const handleProfileChange = (e) => {
    const { name, value } = e.target
    setProfileSettings((prev) => ({
      ...prev,
      [name]: value,
    }))
    setIsSaved(false)
  }

  const handlePasswordChange = (e) => {
    const { name, value } = e.target
    setPasswordSettings((prev) => ({
      ...prev,
      [name]: value,
    }))
    setIsSaved(false)
  }

  const handleNotificationChange = (name, checked) => {
    setNotificationSettings((prev) => ({
      ...prev,
      [name]: checked,
    }))
    setIsSaved(false)
  }

  const handleAccountChange = (name, value) => {
    setAccountSettings((prev) => ({
      ...prev,
      [name]: value,
    }))
    setIsSaved(false)
  }

  const handleSave = () => {
    setIsSaving(true)

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      setIsSaved(true)

      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully.",
      })

      // Reset saved indicator after a few seconds
      setTimeout(() => {
        setIsSaved(false)
      }, 3000)
    }, 1500)
  }

  const handlePasswordSave = () => {
    // Validate passwords
    if (passwordSettings.newPassword !== passwordSettings.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "New password and confirmation password must match.",
        variant: "destructive",
      })
      return
    }

    if (passwordSettings.newPassword.length < 8) {
      toast({
        title: "Password too short",
        description: "Password must be at least 8 characters long.",
        variant: "destructive",
      })
      return
    }

    setIsSaving(true)

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      setIsSaved(true)

      toast({
        title: "Password updated",
        description: "Your password has been updated successfully.",
      })

      // Reset password fields and saved indicator
      setPasswordSettings({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      })

      setTimeout(() => {
        setIsSaved(false)
      }, 3000)
    }, 1500)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">My Profile</h1>
          <p className="text-bright-white/70">Manage your account settings and preferences</p>
        </div>

        <div className="mt-4 sm:mt-0">
          <Button
            className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90"
            onClick={handleSave}
            disabled={isSaving || isSaved}
          >
            {isSaving ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Saving...
              </>
            ) : isSaved ? (
              <>
                <Check className="h-4 w-4 mr-2" /> Saved
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" /> Save Changes
              </>
            )}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-bright-black/30">
          <TabsTrigger value="profile" className="flex items-center">
            <User className="h-4 w-4 mr-2" /> Profile
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center">
            <Lock className="h-4 w-4 mr-2" /> Security
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center">
            <Bell className="h-4 w-4 mr-2" /> Notifications
          </TabsTrigger>
          <TabsTrigger value="account" className="flex items-center">
            <Shield className="h-4 w-4 mr-2" /> Account
          </TabsTrigger>
        </TabsList>

        {/* Profile Tab */}
        <TabsContent value="profile" className="mt-6">
          <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-bright-white">Profile Information</CardTitle>
              <CardDescription>Update your personal information and profile settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col sm:flex-row items-center gap-6">
                <div className="relative">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src={profileSettings.avatarUrl} alt={profileSettings.name} />
                    <AvatarFallback className="bg-bright-yellow/20 text-bright-yellow text-2xl">
                      {profileSettings.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <Button
                    variant="outline"
                    size="icon"
                    className="absolute bottom-0 right-0 rounded-full h-8 w-8 bg-bright-black border-bright-yellow/20 text-bright-yellow"
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                </div>
                <div className="space-y-2 text-center sm:text-left">
                  <h3 className="text-lg font-medium text-bright-white">{profileSettings.name}</h3>
                  <p className="text-bright-white/70">{profileSettings.jobTitle}</p>
                  <p className="text-xs text-bright-white/50">
                    Member since {new Date().toLocaleDateString("en-US", { month: "long", year: "numeric" })}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-bright-white">
                    Full Name
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    value={profileSettings.name}
                    onChange={handleProfileChange}
                    className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-bright-white">
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={profileSettings.email}
                    onChange={handleProfileChange}
                    className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-bright-white">
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    name="phone"
                    value={profileSettings.phone}
                    onChange={handleProfileChange}
                    className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="jobTitle" className="text-bright-white">
                    Job Title
                  </Label>
                  <Input
                    id="jobTitle"
                    name="jobTitle"
                    value={profileSettings.jobTitle}
                    onChange={handleProfileChange}
                    className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio" className="text-bright-white">
                  Bio
                </Label>
                <Textarea
                  id="bio"
                  name="bio"
                  value={profileSettings.bio}
                  onChange={handleProfileChange}
                  className="bg-bright-black/30 border-bright-yellow/20 text-bright-white min-h-[100px]"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="mt-6">
          <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-bright-white">Change Password</CardTitle>
              <CardDescription>Update your password to keep your account secure</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="currentPassword" className="text-bright-white">
                  Current Password
                </Label>
                <div className="relative">
                  <Input
                    id="currentPassword"
                    name="currentPassword"
                    type={showPassword ? "text" : "password"}
                    value={passwordSettings.currentPassword}
                    onChange={handlePasswordChange}
                    className="bg-bright-black/30 border-bright-yellow/20 text-bright-white pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full px-3 text-bright-white/70 hover:text-bright-white"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="newPassword" className="text-bright-white">
                  New Password
                </Label>
                <div className="relative">
                  <Input
                    id="newPassword"
                    name="newPassword"
                    type={showNewPassword ? "text" : "password"}
                    value={passwordSettings.newPassword}
                    onChange={handlePasswordChange}
                    className="bg-bright-black/30 border-bright-yellow/20 text-bright-white pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full px-3 text-bright-white/70 hover:text-bright-white"
                    onClick={() => setShowNewPassword(!showNewPassword)}
                  >
                    {showNewPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="text-xs text-bright-white/50">
                  Password must be at least 8 characters long and include a mix of letters, numbers, and symbols.
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-bright-white">
                  Confirm New Password
                </Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  value={passwordSettings.confirmPassword}
                  onChange={handlePasswordChange}
                  className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                />
              </div>

              <Button
                className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90 w-full sm:w-auto"
                onClick={handlePasswordSave}
              >
                Update Password
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="mt-6">
          <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-bright-white">Notification Preferences</CardTitle>
              <CardDescription>Manage how you receive notifications</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="emailNotifications" className="text-bright-white">
                    Email Notifications
                  </Label>
                  <p className="text-sm text-bright-white/70">Receive notifications via email</p>
                </div>
                <Switch
                  id="emailNotifications"
                  checked={notificationSettings.emailNotifications}
                  onCheckedChange={(checked) => handleNotificationChange("emailNotifications", checked)}
                  className="data-[state=checked]:bg-bright-yellow"
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="browserNotifications" className="text-bright-white">
                    Browser Notifications
                  </Label>
                  <p className="text-sm text-bright-white/70">Receive notifications in your browser</p>
                </div>
                <Switch
                  id="browserNotifications"
                  checked={notificationSettings.browserNotifications}
                  onCheckedChange={(checked) => handleNotificationChange("browserNotifications", checked)}
                  className="data-[state=checked]:bg-bright-yellow"
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="marketingEmails" className="text-bright-white">
                    Marketing Emails
                  </Label>
                  <p className="text-sm text-bright-white/70">Receive marketing and promotional emails</p>
                </div>
                <Switch
                  id="marketingEmails"
                  checked={notificationSettings.marketingEmails}
                  onCheckedChange={(checked) => handleNotificationChange("marketingEmails", checked)}
                  className="data-[state=checked]:bg-bright-yellow"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Account Tab */}
        <TabsContent value="account" className="mt-6">
          <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-bright-white">Account Settings</CardTitle>
              <CardDescription>Manage your account security and preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="twoFactorAuth" className="text-bright-white">
                    Two-Factor Authentication
                  </Label>
                  <p className="text-sm text-bright-white/70">Add an extra layer of security to your account</p>
                </div>
                <Switch
                  id="twoFactorAuth"
                  checked={accountSettings.twoFactorAuth}
                  onCheckedChange={(checked) => handleAccountChange("twoFactorAuth", checked)}
                  className="data-[state=checked]:bg-bright-yellow"
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="loginAlerts" className="text-bright-white">
                    Login Alerts
                  </Label>
                  <p className="text-sm text-bright-white/70">Receive alerts for new login attempts</p>
                </div>
                <Switch
                  id="loginAlerts"
                  checked={accountSettings.loginAlerts}
                  onCheckedChange={(checked) => handleAccountChange("loginAlerts", checked)}
                  className="data-[state=checked]:bg-bright-yellow"
                />
              </div>

              <div className="pt-4 border-t border-bright-yellow/10">
                <h3 className="text-lg font-medium text-bright-white mb-4">Danger Zone</h3>
                <div className="space-y-4">
                  <Button
                    variant="outline"
                    className="border-red-500/20 text-red-500 hover:bg-red-500/10 hover:text-red-600"
                    onClick={() => {
                      toast({
                        title: "Account deactivation",
                        description: "Please contact an administrator to deactivate your account.",
                      })
                    }}
                  >
                    Deactivate Account
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
