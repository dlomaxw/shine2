"use client"

import { useState } from "react"
import Image from "next/image"
import { CuboidIcon as Cube, Trash2, Edit, Eye, Plus } from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"

// Sample 3D models data
const models = [
  {
    id: 1,
    name: "Modern Office Building",
    thumbnail: "/images/building2.webp",
    category: "Commercial",
    fileSize: "24.5 MB",
    format: "GLB",
    dateAdded: "Oct 2, 2023",
  },
  {
    id: 2,
    name: "Luxury Residential House",
    thumbnail: "/images/modern-house-1.jpeg",
    category: "Residential",
    fileSize: "18.2 MB",
    format: "GLB",
    dateAdded: "Oct 1, 2023",
  },
  {
    id: 3,
    name: "Apartment Complex",
    thumbnail: "/images/apartment-courtyard.jpeg",
    category: "Multi-family",
    fileSize: "32.7 MB",
    format: "GLB",
    dateAdded: "Sep 28, 2023",
  },
  {
    id: 4,
    name: "Waterfront Resort",
    thumbnail: "/images/waterfront-complex.jpeg",
    category: "Hospitality",
    fileSize: "29.3 MB",
    format: "GLB",
    dateAdded: "Sep 25, 2023",
  },
  {
    id: 5,
    name: "Brick Townhouse",
    thumbnail: "/images/brick-townhouse.jpeg",
    category: "Residential",
    fileSize: "15.8 MB",
    format: "GLB",
    dateAdded: "Sep 22, 2023",
  },
  {
    id: 6,
    name: "Modern Apartment Building",
    thumbnail: "/images/building6.webp",
    category: "Multi-family",
    fileSize: "27.1 MB",
    format: "GLB",
    dateAdded: "Sep 20, 2023",
  },
]

export default function ModelsPage() {
  const [activeTab, setActiveTab] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")

  // Filter models based on search query and active tab
  const filteredModels = models.filter((model) => {
    const matchesSearch =
      model.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      model.category.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = activeTab === "all" || model.category.toLowerCase() === activeTab.toLowerCase()

    return matchesSearch && matchesCategory
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">3D Models</h1>
          <p className="text-bright-white/70">Manage your 3D models for the website</p>
        </div>

        <div className="mt-4 sm:mt-0">
          <Button className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
            <Plus className="h-4 w-4 mr-2" /> Add New Model
          </Button>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Input
            placeholder="Search models..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
          />
        </div>

        <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
          <TabsList className="bg-bright-black/30 w-full sm:w-auto">
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="residential">Residential</TabsTrigger>
            <TabsTrigger value="commercial">Commercial</TabsTrigger>
            <TabsTrigger value="multi-family">Multi-family</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Models Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredModels.map((model, index) => (
          <motion.div
            key={model.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm overflow-hidden">
              <div className="relative aspect-video w-full overflow-hidden">
                <Image src={model.thumbnail || "/placeholder.svg"} alt={model.name} fill className="object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-bright-black/70 to-transparent opacity-0 hover:opacity-100 transition-opacity flex items-end justify-center p-4">
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-bright-white/30 text-bright-white bg-bright-black/50 backdrop-blur-sm hover:bg-bright-white/20"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-bright-white/30 text-bright-white bg-bright-black/50 backdrop-blur-sm hover:bg-bright-white/20"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-bright-white/30 text-bright-white bg-bright-black/50 backdrop-blur-sm hover:bg-bright-white/20"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <div className="absolute top-2 right-2">
                  <span className="px-2 py-1 bg-bright-black/70 backdrop-blur-sm text-bright-white text-xs rounded">
                    {model.format}
                  </span>
                </div>
              </div>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-medium text-bright-white">{model.name}</h3>
                    <p className="text-sm text-bright-white/70">{model.category}</p>
                  </div>
                  <div className="bg-bright-yellow/10 p-2 rounded-md">
                    <Cube className="h-5 w-5 text-bright-yellow" />
                  </div>
                </div>
                <div className="flex items-center justify-between mt-4 text-xs text-bright-white/50">
                  <span>Added: {model.dateAdded}</span>
                  <span>{model.fileSize}</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Empty State */}
      {filteredModels.length === 0 && (
        <div className="text-center py-12 bg-bright-black/30 rounded-lg border border-bright-yellow/10">
          <Cube className="h-12 w-12 text-bright-white/20 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-bright-white mb-2">No models found</h3>
          <p className="text-bright-white/70 mb-6">Try adjusting your search or filter criteria</p>
          <Button
            variant="outline"
            className="border-bright-yellow text-bright-yellow hover:bg-bright-yellow hover:text-bright-black"
            onClick={() => {
              setSearchQuery("")
              setActiveTab("all")
            }}
          >
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  )
}
