"use client"

import { useState } from "react"
import Image from "next/image"
import {
  Plus,
  Search,
  Grid,
  ListIcon,
  MoreHorizontal,
  Trash2,
  Download,
  Copy,
  Edit,
  ImageIcon,
  FileText,
  Video,
} from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample media items
const mediaItems = [
  {
    id: 1,
    type: "image",
    name: "building1.webp",
    url: "/images/building1.webp",
    size: "1.2 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-01",
  },
  {
    id: 2,
    type: "image",
    name: "building2.webp",
    url: "/images/building2.webp",
    size: "0.9 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-09-28",
  },
  {
    id: 3,
    type: "image",
    name: "building3.webp",
    url: "/images/building3.webp",
    size: "1.1 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-09-25",
  },
  {
    id: 4,
    type: "image",
    name: "building4.webp",
    url: "/images/building4.webp",
    size: "0.8 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-09-20",
  },
  {
    id: 5,
    type: "image",
    name: "building5.webp",
    url: "/images/building5.webp",
    size: "1.0 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-09-18",
  },
  {
    id: 6,
    type: "image",
    name: "modern-apartment.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a857e0f798a1373e05fde2481ecd6718_high-gcskXyL6UqIaTrKLUlIBaiOPAmxOwm.webp",
    size: "1.3 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-03",
  },
  {
    id: 7,
    type: "image",
    name: "curved-edge-house.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a0b636bae87bcc2975fca450f582d3fc_high-TlUhD7qnAPEvvgWaJMUdjAsLVapZRn.webp",
    size: "1.5 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-03",
  },
  {
    id: 8,
    type: "image",
    name: "circular-window-house.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a1823870bc6ac6aa38e4f0dbb81d9939_high-x1dgCbfVnigzQF0W7PqZ5LAy0W4wq2.webp",
    size: "1.4 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-03",
  },
  {
    id: 9,
    type: "image",
    name: "compact-modern-house.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/aa67ef8cee448ed470f7311e5773ad0d_high-rDL21lQPU8UM6iuDU7DctpIMCQ7ssa.webp",
    size: "1.2 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-03",
  },
  {
    id: 10,
    type: "image",
    name: "waterfront-highrise.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/b1bc8af70abb972d2dc86ce553c0f630_high-mKKCHBT8xcXlYlGv1UwfNVGZaf4iMK.webp",
    size: "1.6 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-03",
  },
  {
    id: 11,
    type: "image",
    name: "perforated-facade.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a57f83d6751c0593f6cb6dfc08b3f36e_high-xJa6fMMLfwpgS79VYkoe5k3hW0PYAi.webp",
    size: "1.3 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-03",
  },
  {
    id: 12,
    type: "image",
    name: "modern-apartment-tower.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a445adaf066b475c362fb2b508e2f3c6_high-uTeM1aV8RHxnjqPit6zCkeKmx8FWP5.webp",
    size: "1.7 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-03",
  },
  {
    id: 13,
    type: "image",
    name: "orange-curved-house.webp",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a73eace8e0fe3bc6126cae4885913eb1_high-yX8gv14HkIpCDE3sNs7iwpcU7UMjuz.webp",
    size: "1.4 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-03",
  },
  {
    id: 14,
    type: "image",
    name: "waterfront-resort.jpeg",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/A%20smooth%20gradient%20transition%20with%20bright%20lens%20flare%20renders%20a%20modern%20retirement%20building%20complex%20by%20a%20lake...and%20hospital%20components.%20%20Printed%20facades%2C%20large%20windows%2C%20decorative%20railings%2C%20balconies%2C%20green%20landscaping%2C%20palm%20trees%2C%20a.jpg-9ED00I4BQuFgCUuN2t5tFEk6XRbk25.jpeg",
    size: "1.8 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-03",
  },
  {
    id: 15,
    type: "image",
    name: "island-resort.jpeg",
    url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/An%20overhead%20bird%E2%80%99s%20eye%20view%20of%20a%20layered%20papier-ma%CC%82che%CC%81%20style%203D%20render%20depicting%20a%20modern%20retirement%20buil...h%20commercial%20and%20hospital%20sections.%20%20Printed%20facades%2C%20large%20windows%2C%20balconies%2C%20green%20landscaping%2C%20palm%20trees%20and%20pathwa.jpg-PJLIrtQVaZWTUOMfTXIqb5WEL29LKH.jpeg",
    size: "1.9 MB",
    dimensions: "1920x1080",
    uploadedAt: "2023-10-03",
  },
]

export default function MediaPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [mediaType, setMediaType] = useState("all")

  // Filter media items based on search query and type
  const filteredMedia = mediaItems.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = mediaType === "all" || item.type === mediaType
    return matchesSearch && matchesType
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">Media Library</h1>
          <p className="text-bright-white/70">Manage images, videos, and other media files</p>
        </div>

        <Button className="mt-4 sm:mt-0 bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
          <Plus className="h-4 w-4 mr-2" /> Upload Media
        </Button>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-bright-white/50" />
          <Input
            placeholder="Search media..."
            className="pl-9 bg-bright-black/30 border-bright-yellow/10 text-bright-white"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex gap-2">
          <Tabs defaultValue="all" value={mediaType} onValueChange={setMediaType}>
            <TabsList className="bg-bright-black/30 border border-bright-yellow/10">
              <TabsTrigger
                value="all"
                className="data-[state=active]:bg-bright-yellow data-[state=active]:text-bright-black"
              >
                All
              </TabsTrigger>
              <TabsTrigger
                value="image"
                className="data-[state=active]:bg-bright-yellow data-[state=active]:text-bright-black"
              >
                Images
              </TabsTrigger>
              <TabsTrigger
                value="video"
                className="data-[state=active]:bg-bright-yellow data-[state=active]:text-bright-black"
              >
                Videos
              </TabsTrigger>
              <TabsTrigger
                value="document"
                className="data-[state=active]:bg-bright-yellow data-[state=active]:text-bright-black"
              >
                Documents
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="flex border border-bright-yellow/10 rounded-md overflow-hidden">
            <Button
              variant="ghost"
              size="icon"
              className={`rounded-none ${
                viewMode === "grid"
                  ? "bg-bright-yellow text-bright-black"
                  : "bg-bright-black/30 text-bright-white/70 hover:text-bright-white"
              }`}
              onClick={() => setViewMode("grid")}
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className={`rounded-none ${
                viewMode === "list"
                  ? "bg-bright-yellow text-bright-black"
                  : "bg-bright-black/30 text-bright-white/70 hover:text-bright-white"
              }`}
              onClick={() => setViewMode("list")}
            >
              <ListIcon className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Media Grid/List View */}
      {filteredMedia.length > 0 ? (
        viewMode === "grid" ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {filteredMedia.map((item) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.2 }}
                className="group relative bg-bright-black/30 border border-bright-yellow/10 rounded-md overflow-hidden"
              >
                <div className="aspect-square relative">
                  {item.type === "image" ? (
                    <Image src={item.url || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                  ) : item.type === "video" ? (
                    <video src={item.url} alt={item.name} className="object-cover w-full h-full" controls />
                  ) : (
                    <div className="flex items-center justify-center h-full bg-bright-black/50">
                      <FileText className="h-12 w-12 text-bright-white/30" />
                    </div>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-bright-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-between p-2">
                    <span className="text-xs text-bright-white truncate max-w-[80%]">{item.name}</span>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-bright-white/70 hover:text-bright-white"
                        >
                          <MoreHorizontal className="h-3 w-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-bright-black border-bright-yellow/20">
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Edit className="h-4 w-4 mr-2" /> Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Copy className="h-4 w-4 mr-2" /> Copy URL
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Download className="h-4 w-4 mr-2" /> Download
                        </DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-bright-yellow/10" />
                        <DropdownMenuItem className="text-red-500 hover:text-red-600 hover:bg-red-500/10">
                          <Trash2 className="h-4 w-4 mr-2" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="border border-bright-yellow/10 rounded-md overflow-hidden">
            <table className="w-full">
              <thead className="bg-bright-black/50">
                <tr>
                  <th className="text-left py-3 px-4 text-bright-white/70 font-medium">File</th>
                  <th className="text-left py-3 px-4 text-bright-white/70 font-medium">Type</th>
                  <th className="text-left py-3 px-4 text-bright-white/70 font-medium">Size</th>
                  <th className="text-left py-3 px-4 text-bright-white/70 font-medium">Dimensions</th>
                  <th className="text-left py-3 px-4 text-bright-white/70 font-medium">Uploaded</th>
                  <th className="text-right py-3 px-4 text-bright-white/70 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredMedia.map((item) => (
                  <tr key={item.id} className="border-t border-bright-yellow/10 hover:bg-bright-black/30">
                    <td className="py-3 px-4">
                      <div className="flex items-center">
                        <div className="h-10 w-10 mr-3 relative rounded overflow-hidden bg-bright-black/30">
                          {item.type === "image" ? (
                            <Image src={item.url || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                          ) : item.type === "video" ? (
                            <Video className="h-6 w-6 m-2 text-bright-white/50" />
                          ) : (
                            <FileText className="h-6 w-6 m-2 text-bright-white/50" />
                          )}
                        </div>
                        <span className="text-bright-white">{item.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-bright-white/70 capitalize">{item.type}</td>
                    <td className="py-3 px-4 text-bright-white/70">{item.size}</td>
                    <td className="py-3 px-4 text-bright-white/70">{item.dimensions}</td>
                    <td className="py-3 px-4 text-bright-white/70">{item.uploadedAt}</td>
                    <td className="py-3 px-4 text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-bright-white/70 hover:text-bright-white">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-bright-black border-bright-yellow/20">
                          <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                            <Edit className="h-4 w-4 mr-2" /> Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                            <Copy className="h-4 w-4 mr-2" /> Copy URL
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                            <Download className="h-4 w-4 mr-2" /> Download
                          </DropdownMenuItem>
                          <DropdownMenuSeparator className="bg-bright-yellow/10" />
                          <DropdownMenuItem className="text-red-500 hover:text-red-600 hover:bg-red-500/10">
                            <Trash2 className="h-4 w-4 mr-2" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      ) : (
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <ImageIcon className="h-16 w-16 text-bright-white/20 mb-4" />
          <h3 className="text-xl font-medium text-bright-white mb-2">No media found</h3>
          <p className="text-bright-white/70 mb-6">No media files match your search criteria.</p>
          <Button className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
            <Plus className="h-4 w-4 mr-2" /> Upload Media
          </Button>
        </div>
      )}
    </div>
  )
}
