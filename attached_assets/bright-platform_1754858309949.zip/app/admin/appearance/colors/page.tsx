"use client"

import { useState } from "react"
import { Check, RefreshCw, Save } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

// Sample color schemes
const colorSchemes = {
  primary: {
    name: "Primary",
    colors: {
      main: "#FFE100",
      light: "#FFF176",
      dark: "#FFD600",
    },
  },
  secondary: {
    name: "Secondary",
    colors: {
      main: "#111111",
      light: "#333333",
      soft: "#222222",
    },
  },
  accent: {
    name: "Accent",
    colors: {
      blue: "#0070F3",
      green: "#10B981",
      purple: "#8B5CF6",
      red: "#EF4444",
      orange: "#F59E0B",
    },
  },
  ui: {
    name: "UI Elements",
    colors: {
      background: "#000000",
      foreground: "#FFFFFF",
      border: "#333333",
      input: "#222222",
    },
  },
}

export default function ColorsPage() {
  const [activeTab, setActiveTab] = useState("primary")
  const [colorValues, setColorValues] = useState(colorSchemes)
  const [isSaving, setIsSaving] = useState(false)
  const [isSaved, setIsSaved] = useState(false)

  const handleColorChange = (category, colorKey, value) => {
    setColorValues((prev) => ({
      ...prev,
      [category]: {
        ...prev[category],
        colors: {
          ...prev[category].colors,
          [colorKey]: value,
        },
      },
    }))

    // Reset saved state when changes are made
    setIsSaved(false)
  }

  const handleSave = () => {
    setIsSaving(true)

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      setIsSaved(true)

      // Reset saved indicator after a few seconds
      setTimeout(() => {
        setIsSaved(false)
      }, 3000)
    }, 1500)
  }

  const handleReset = () => {
    setColorValues(colorSchemes)
    setIsSaved(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">Color Scheme</h1>
          <p className="text-bright-white/70">Customize the color palette of your website</p>
        </div>

        <div className="mt-4 sm:mt-0 flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            className="text-bright-white border-bright-yellow/20"
            onClick={handleReset}
          >
            <RefreshCw className="h-4 w-4 mr-2" /> Reset
          </Button>
          <Button
            className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90"
            onClick={handleSave}
            disabled={isSaving || isSaved}
          >
            {isSaving ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Saving...
              </>
            ) : isSaved ? (
              <>
                <Check className="h-4 w-4 mr-2" /> Saved
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" /> Save Changes
              </>
            )}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="primary" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-bright-black/30">
          <TabsTrigger value="primary">Primary</TabsTrigger>
          <TabsTrigger value="secondary">Secondary</TabsTrigger>
          <TabsTrigger value="accent">Accent</TabsTrigger>
          <TabsTrigger value="ui">UI Elements</TabsTrigger>
        </TabsList>

        {Object.keys(colorValues).map((category) => (
          <TabsContent key={category} value={category} className="mt-6">
            <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-bright-white">{colorValues[category].name} Colors</CardTitle>
                <CardDescription>
                  Customize the {colorValues[category].name.toLowerCase()} color palette of your website
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Object.entries(colorValues[category].colors).map(([colorKey, colorValue]) => (
                    <div key={colorKey} className="space-y-2">
                      <Label htmlFor={`${category}-${colorKey}`} className="capitalize text-bright-white">
                        {colorKey}
                      </Label>
                      <div className="flex space-x-2">
                        <div
                          className="w-10 h-10 rounded border border-bright-white/20"
                          style={{ backgroundColor: colorValue }}
                        />
                        <Input
                          id={`${category}-${colorKey}`}
                          value={colorValue}
                          onChange={(e) => handleColorChange(category, colorKey, e.target.value)}
                          className="bg-bright-black/30 border-bright-yellow/20 text-bright-white font-mono"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between border-t border-bright-yellow/10 pt-6">
                <div className="text-sm text-bright-white/70">Changes will be applied to the entire website</div>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-bright-yellow text-bright-yellow hover:bg-bright-yellow hover:text-bright-black"
                  onClick={() => handleReset()}
                >
                  Reset {colorValues[category].name}
                </Button>
              </CardFooter>
            </Card>

            <div className="mt-8">
              <h3 className="text-lg font-medium text-bright-white mb-4">Preview</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="border-bright-yellow/10 overflow-hidden">
                  <div
                    className="h-32"
                    style={{
                      backgroundColor:
                        category === "primary" ? colorValues.primary.colors.main : colorValues.secondary.colors.main,
                      color:
                        category === "primary" ? colorValues.secondary.colors.main : colorValues.primary.colors.main,
                    }}
                  >
                    <div className="p-4">
                      <h4 className="text-lg font-bold">Header Example</h4>
                      <p>This shows how your colors will look on the website</p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <h4 className="font-medium">Content Example</h4>
                      <p className="text-sm">
                        Regular text with a{" "}
                        <span style={{ color: colorValues.primary.colors.main }}>primary color</span> accent.
                      </p>
                      <Button
                        style={{
                          backgroundColor: colorValues.primary.colors.main,
                          color: colorValues.secondary.colors.main,
                        }}
                      >
                        Button Example
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <div className="space-y-4">
                  <div
                    className="p-4 rounded-lg"
                    style={{
                      backgroundColor: colorValues.ui.colors.background,
                      color: colorValues.ui.colors.foreground,
                      borderColor: colorValues.ui.colors.border,
                      borderWidth: "1px",
                      borderStyle: "solid",
                    }}
                  >
                    <h4 className="font-medium mb-2">UI Background</h4>
                    <p className="text-sm">This shows how your UI elements will look.</p>
                  </div>

                  <div className="grid grid-cols-5 gap-2">
                    {Object.values(colorValues.accent.colors).map((color, index) => (
                      <div
                        key={index}
                        className="h-12 rounded-md flex items-center justify-center text-xs font-medium"
                        style={{ backgroundColor: color, color: "#FFFFFF" }}
                      >
                        Accent
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
