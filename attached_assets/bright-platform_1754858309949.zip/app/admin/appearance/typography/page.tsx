"use client"

import { useState } from "react"
import { Save, RefreshCw, Check, Type, Heading1, Heading2, Heading3, AlignLeft, Bold, Italic } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { toast } from "@/components/ui/use-toast"

export default function TypographyPage() {
  const [isSaving, setIsSaving] = useState(false)
  const [isSaved, setIsSaved] = useState(false)

  // Typography settings state
  const [typographySettings, setTypographySettings] = useState({
    headingFont: "Inter",
    bodyFont: "Inter",
    monoFont: "Roboto Mono",
    baseSize: 16,
    scaleRatio: 1.2,
    headingWeight: "600",
    bodyWeight: "400",
    lineHeight: 1.5,
    letterSpacing: 0,
  })

  const handleInputChange = (field: string, value: string | number) => {
    setTypographySettings((prev) => ({
      ...prev,
      [field]: value,
    }))
    setIsSaved(false)
  }

  const handleSave = () => {
    setIsSaving(true)

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      setIsSaved(true)

      toast({
        title: "Typography settings saved",
        description: "Your typography settings have been updated successfully.",
      })

      // Reset saved indicator after a few seconds
      setTimeout(() => {
        setIsSaved(false)
      }, 3000)
    }, 1500)
  }

  const handleReset = () => {
    setTypographySettings({
      headingFont: "Inter",
      bodyFont: "Inter",
      monoFont: "Roboto Mono",
      baseSize: 16,
      scaleRatio: 1.2,
      headingWeight: "600",
      bodyWeight: "400",
      lineHeight: 1.5,
      letterSpacing: 0,
    })

    toast({
      title: "Typography settings reset",
      description: "Your typography settings have been reset to default values.",
    })

    setIsSaved(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">Typography</h1>
          <p className="text-bright-white/70">Customize the typography of your website</p>
        </div>

        <div className="mt-4 sm:mt-0 flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            className="text-bright-white border-bright-yellow/20"
            onClick={handleReset}
          >
            <RefreshCw className="h-4 w-4 mr-2" /> Reset
          </Button>
          <Button
            className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90"
            onClick={handleSave}
            disabled={isSaving || isSaved}
          >
            {isSaving ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Saving...
              </>
            ) : isSaved ? (
              <>
                <Check className="h-4 w-4 mr-2" /> Saved
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" /> Save Changes
              </>
            )}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Font Settings */}
        <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-bright-white">Font Settings</CardTitle>
            <CardDescription>Choose fonts for different elements of your website</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="headingFont" className="text-bright-white">
                Heading Font
              </Label>
              <Select
                value={typographySettings.headingFont}
                onValueChange={(value) => handleInputChange("headingFont", value)}
              >
                <SelectTrigger
                  id="headingFont"
                  className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                >
                  <SelectValue placeholder="Select font" />
                </SelectTrigger>
                <SelectContent className="bg-bright-black border-bright-yellow/20">
                  <SelectItem value="Inter" className="text-bright-white">
                    Inter
                  </SelectItem>
                  <SelectItem value="Roboto" className="text-bright-white">
                    Roboto
                  </SelectItem>
                  <SelectItem value="Montserrat" className="text-bright-white">
                    Montserrat
                  </SelectItem>
                  <SelectItem value="Poppins" className="text-bright-white">
                    Poppins
                  </SelectItem>
                  <SelectItem value="Open Sans" className="text-bright-white">
                    Open Sans
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="bodyFont" className="text-bright-white">
                Body Font
              </Label>
              <Select
                value={typographySettings.bodyFont}
                onValueChange={(value) => handleInputChange("bodyFont", value)}
              >
                <SelectTrigger id="bodyFont" className="bg-bright-black/30 border-bright-yellow/20 text-bright-white">
                  <SelectValue placeholder="Select font" />
                </SelectTrigger>
                <SelectContent className="bg-bright-black border-bright-yellow/20">
                  <SelectItem value="Inter" className="text-bright-white">
                    Inter
                  </SelectItem>
                  <SelectItem value="Roboto" className="text-bright-white">
                    Roboto
                  </SelectItem>
                  <SelectItem value="Montserrat" className="text-bright-white">
                    Montserrat
                  </SelectItem>
                  <SelectItem value="Poppins" className="text-bright-white">
                    Poppins
                  </SelectItem>
                  <SelectItem value="Open Sans" className="text-bright-white">
                    Open Sans
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="monoFont" className="text-bright-white">
                Monospace Font
              </Label>
              <Select
                value={typographySettings.monoFont}
                onValueChange={(value) => handleInputChange("monoFont", value)}
              >
                <SelectTrigger id="monoFont" className="bg-bright-black/30 border-bright-yellow/20 text-bright-white">
                  <SelectValue placeholder="Select font" />
                </SelectTrigger>
                <SelectContent className="bg-bright-black border-bright-yellow/20">
                  <SelectItem value="Roboto Mono" className="text-bright-white">
                    Roboto Mono
                  </SelectItem>
                  <SelectItem value="JetBrains Mono" className="text-bright-white">
                    JetBrains Mono
                  </SelectItem>
                  <SelectItem value="Fira Code" className="text-bright-white">
                    Fira Code
                  </SelectItem>
                  <SelectItem value="Source Code Pro" className="text-bright-white">
                    Source Code Pro
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Size and Scale */}
        <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-bright-white">Size and Scale</CardTitle>
            <CardDescription>Adjust the base size and scale of your typography</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="baseSize" className="text-bright-white">
                  Base Size: {typographySettings.baseSize}px
                </Label>
              </div>
              <Slider
                id="baseSize"
                min={12}
                max={24}
                step={1}
                value={[typographySettings.baseSize]}
                onValueChange={(value) => handleInputChange("baseSize", value[0])}
                className="data-[state=active]:bg-bright-yellow"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="scaleRatio" className="text-bright-white">
                  Scale Ratio: {typographySettings.scaleRatio.toFixed(1)}
                </Label>
              </div>
              <Slider
                id="scaleRatio"
                min={1.0}
                max={1.5}
                step={0.1}
                value={[typographySettings.scaleRatio]}
                onValueChange={(value) => handleInputChange("scaleRatio", value[0])}
                className="data-[state=active]:bg-bright-yellow"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="headingWeight" className="text-bright-white">
                  Heading Weight
                </Label>
                <Select
                  value={typographySettings.headingWeight}
                  onValueChange={(value) => handleInputChange("headingWeight", value)}
                >
                  <SelectTrigger
                    id="headingWeight"
                    className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                  >
                    <SelectValue placeholder="Select weight" />
                  </SelectTrigger>
                  <SelectContent className="bg-bright-black border-bright-yellow/20">
                    <SelectItem value="400" className="text-bright-white">
                      Regular (400)
                    </SelectItem>
                    <SelectItem value="500" className="text-bright-white">
                      Medium (500)
                    </SelectItem>
                    <SelectItem value="600" className="text-bright-white">
                      Semibold (600)
                    </SelectItem>
                    <SelectItem value="700" className="text-bright-white">
                      Bold (700)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bodyWeight" className="text-bright-white">
                  Body Weight
                </Label>
                <Select
                  value={typographySettings.bodyWeight}
                  onValueChange={(value) => handleInputChange("bodyWeight", value)}
                >
                  <SelectTrigger
                    id="bodyWeight"
                    className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                  >
                    <SelectValue placeholder="Select weight" />
                  </SelectTrigger>
                  <SelectContent className="bg-bright-black border-bright-yellow/20">
                    <SelectItem value="300" className="text-bright-white">
                      Light (300)
                    </SelectItem>
                    <SelectItem value="400" className="text-bright-white">
                      Regular (400)
                    </SelectItem>
                    <SelectItem value="500" className="text-bright-white">
                      Medium (500)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Line Height and Spacing */}
        <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-bright-white">Line Height and Spacing</CardTitle>
            <CardDescription>Adjust the spacing between lines and letters</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="lineHeight" className="text-bright-white">
                  Line Height: {typographySettings.lineHeight.toFixed(1)}
                </Label>
              </div>
              <Slider
                id="lineHeight"
                min={1.0}
                max={2.0}
                step={0.1}
                value={[typographySettings.lineHeight]}
                onValueChange={(value) => handleInputChange("lineHeight", value[0])}
                className="data-[state=active]:bg-bright-yellow"
              />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="letterSpacing" className="text-bright-white">
                  Letter Spacing: {typographySettings.letterSpacing.toFixed(1)}px
                </Label>
              </div>
              <Slider
                id="letterSpacing"
                min={-1}
                max={2}
                step={0.1}
                value={[typographySettings.letterSpacing]}
                onValueChange={(value) => handleInputChange("letterSpacing", value[0])}
                className="data-[state=active]:bg-bright-yellow"
              />
            </div>
          </CardContent>
        </Card>

        {/* Preview */}
        <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-bright-white">Preview</CardTitle>
            <CardDescription>See how your typography settings look</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4 p-4 bg-bright-black/30 rounded-md border border-bright-yellow/10">
              <div className="flex items-center space-x-2">
                <Heading1 className="h-5 w-5 text-bright-yellow" />
                <h1
                  className="text-3xl font-semibold text-bright-white"
                  style={{
                    fontFamily: typographySettings.headingFont,
                    fontWeight: typographySettings.headingWeight,
                    lineHeight: typographySettings.lineHeight,
                    letterSpacing: `${typographySettings.letterSpacing}px`,
                  }}
                >
                  Heading 1
                </h1>
              </div>

              <div className="flex items-center space-x-2">
                <Heading2 className="h-5 w-5 text-bright-yellow" />
                <h2
                  className="text-2xl font-semibold text-bright-white"
                  style={{
                    fontFamily: typographySettings.headingFont,
                    fontWeight: typographySettings.headingWeight,
                    lineHeight: typographySettings.lineHeight,
                    letterSpacing: `${typographySettings.letterSpacing}px`,
                  }}
                >
                  Heading 2
                </h2>
              </div>

              <div className="flex items-center space-x-2">
                <Heading3 className="h-5 w-5 text-bright-yellow" />
                <h3
                  className="text-xl font-semibold text-bright-white"
                  style={{
                    fontFamily: typographySettings.headingFont,
                    fontWeight: typographySettings.headingWeight,
                    lineHeight: typographySettings.lineHeight,
                    letterSpacing: `${typographySettings.letterSpacing}px`,
                  }}
                >
                  Heading 3
                </h3>
              </div>

              <div className="flex items-start space-x-2">
                <AlignLeft className="h-5 w-5 text-bright-yellow mt-1" />
                <p
                  className="text-bright-white/70"
                  style={{
                    fontFamily: typographySettings.bodyFont,
                    fontWeight: typographySettings.bodyWeight,
                    fontSize: `${typographySettings.baseSize}px`,
                    lineHeight: typographySettings.lineHeight,
                    letterSpacing: `${typographySettings.letterSpacing}px`,
                  }}
                >
                  This is a paragraph of text that demonstrates how your body text will look with the current settings.
                  The quick brown fox jumps over the lazy dog.
                </p>
              </div>

              <div className="flex items-center space-x-2">
                <Bold className="h-5 w-5 text-bright-yellow" />
                <strong
                  className="text-bright-white"
                  style={{
                    fontFamily: typographySettings.bodyFont,
                    fontSize: `${typographySettings.baseSize}px`,
                    lineHeight: typographySettings.lineHeight,
                    letterSpacing: `${typographySettings.letterSpacing}px`,
                  }}
                >
                  This is bold text
                </strong>
              </div>

              <div className="flex items-center space-x-2">
                <Italic className="h-5 w-5 text-bright-yellow" />
                <em
                  className="text-bright-white"
                  style={{
                    fontFamily: typographySettings.bodyFont,
                    fontSize: `${typographySettings.baseSize}px`,
                    lineHeight: typographySettings.lineHeight,
                    letterSpacing: `${typographySettings.letterSpacing}px`,
                  }}
                >
                  This is italic text
                </em>
              </div>

              <div className="flex items-center space-x-2">
                <Type className="h-5 w-5 text-bright-yellow" />
                <code
                  className="bg-bright-black/50 px-1 py-0.5 rounded text-bright-white"
                  style={{
                    fontFamily: typographySettings.monoFont,
                    fontSize: `${typographySettings.baseSize}px`,
                    lineHeight: typographySettings.lineHeight,
                    letterSpacing: `${typographySettings.letterSpacing}px`,
                  }}
                >
                  console.log("Hello World");
                </code>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
