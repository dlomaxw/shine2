"use client"

import { SelectItem } from "@/components/ui/select"

import { SelectContent } from "@/components/ui/select"

import { SelectValue } from "@/components/ui/select"

import { SelectTrigger } from "@/components/ui/select"

import { Select } from "@/components/ui/select"

import { useState } from "react"
import { Save, RefreshCw, Check, Layers, Box, SquareStack, Sliders } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/use-toast"

export default function ComponentsPage() {
  const [activeTab, setActiveTab] = useState("buttons")
  const [isSaving, setIsSaving] = useState(false)
  const [isSaved, setIsSaved] = useState(false)

  // Component settings state
  const [componentSettings, setComponentSettings] = useState({
    buttons: {
      borderRadius: 8,
      paddingX: 16,
      paddingY: 8,
      fontSize: 14,
      primaryColor: "#FFE100",
      secondaryColor: "#111111",
      outlineWidth: 1,
      hoverEffect: "background",
      animation: true,
    },
    cards: {
      borderRadius: 12,
      borderWidth: 1,
      borderColor: "rgba(255, 225, 0, 0.1)",
      shadowOpacity: 0.1,
      shadowBlur: 10,
      shadowColor: "#000000",
      backgroundColor: "rgba(17, 17, 17, 0.5)",
      backdropBlur: true,
    },
    inputs: {
      borderRadius: 6,
      borderWidth: 1,
      borderColor: "rgba(255, 225, 0, 0.2)",
      backgroundColor: "rgba(17, 17, 17, 0.3)",
      textColor: "#FFFFFF",
      placeholderColor: "rgba(255, 255, 255, 0.5)",
      focusRingColor: "rgba(255, 225, 0, 0.5)",
      focusRingWidth: 2,
    },
    navigation: {
      style: "floating",
      transparency: 0.9,
      blurEffect: true,
      borderBottom: true,
      borderColor: "rgba(255, 225, 0, 0.1)",
      dropdownStyle: "fade",
      mobileMenuStyle: "slide",
    },
  })

  const handleButtonChange = (field: string, value: any) => {
    setComponentSettings((prev) => ({
      ...prev,
      buttons: {
        ...prev.buttons,
        [field]: value,
      },
    }))
    setIsSaved(false)
  }

  const handleCardChange = (field: string, value: any) => {
    setComponentSettings((prev) => ({
      ...prev,
      cards: {
        ...prev.cards,
        [field]: value,
      },
    }))
    setIsSaved(false)
  }

  const handleInputChange = (field: string, value: any) => {
    setComponentSettings((prev) => ({
      ...prev,
      inputs: {
        ...prev.inputs,
        [field]: value,
      },
    }))
    setIsSaved(false)
  }

  const handleNavigationChange = (field: string, value: any) => {
    setComponentSettings((prev) => ({
      ...prev,
      navigation: {
        ...prev.navigation,
        [field]: value,
      },
    }))
    setIsSaved(false)
  }

  const handleSave = () => {
    setIsSaving(true)

    // Simulate API call
    setTimeout(() => {
      setIsSaving(false)
      setIsSaved(true)

      toast({
        title: "Component settings saved",
        description: "Your component settings have been updated successfully.",
      })

      // Reset saved indicator after a few seconds
      setTimeout(() => {
        setIsSaved(false)
      }, 3000)
    }, 1500)
  }

  const handleReset = () => {
    setComponentSettings({
      buttons: {
        borderRadius: 8,
        paddingX: 16,
        paddingY: 8,
        fontSize: 14,
        primaryColor: "#FFE100",
        secondaryColor: "#111111",
        outlineWidth: 1,
        hoverEffect: "background",
        animation: true,
      },
      cards: {
        borderRadius: 12,
        borderWidth: 1,
        borderColor: "rgba(255, 225, 0, 0.1)",
        shadowOpacity: 0.1,
        shadowBlur: 10,
        shadowColor: "#000000",
        backgroundColor: "rgba(17, 17, 17, 0.5)",
        backdropBlur: true,
      },
      inputs: {
        borderRadius: 6,
        borderWidth: 1,
        borderColor: "rgba(255, 225, 0, 0.2)",
        backgroundColor: "rgba(17, 17, 17, 0.3)",
        textColor: "#FFFFFF",
        placeholderColor: "rgba(255, 255, 255, 0.5)",
        focusRingColor: "rgba(255, 225, 0, 0.5)",
        focusRingWidth: 2,
      },
      navigation: {
        style: "floating",
        transparency: 0.9,
        blurEffect: true,
        borderBottom: true,
        borderColor: "rgba(255, 225, 0, 0.1)",
        dropdownStyle: "fade",
        mobileMenuStyle: "slide",
      },
    })

    toast({
      title: "Component settings reset",
      description: "Your component settings have been reset to default values.",
    })

    setIsSaved(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">Components</h1>
          <p className="text-bright-white/70">Customize the appearance of UI components</p>
        </div>

        <div className="mt-4 sm:mt-0 flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            className="text-bright-white border-bright-yellow/20"
            onClick={handleReset}
          >
            <RefreshCw className="h-4 w-4 mr-2" /> Reset
          </Button>
          <Button
            className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90"
            onClick={handleSave}
            disabled={isSaving || isSaved}
          >
            {isSaving ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> Saving...
              </>
            ) : isSaved ? (
              <>
                <Check className="h-4 w-4 mr-2" /> Saved
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" /> Save Changes
              </>
            )}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="buttons" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-bright-black/30">
          <TabsTrigger value="buttons" className="flex items-center">
            <Box className="h-4 w-4 mr-2" /> Buttons
          </TabsTrigger>
          <TabsTrigger value="cards" className="flex items-center">
            <Layers className="h-4 w-4 mr-2" /> Cards
          </TabsTrigger>
          <TabsTrigger value="inputs" className="flex items-center">
            <SquareStack className="h-4 w-4 mr-2" /> Inputs
          </TabsTrigger>
          <TabsTrigger value="navigation" className="flex items-center">
            <Sliders className="h-4 w-4 mr-2" /> Navigation
          </TabsTrigger>
        </TabsList>

        {/* Buttons Tab */}
        <TabsContent value="buttons" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-bright-white">Button Appearance</CardTitle>
                <CardDescription>Customize the appearance of buttons</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="buttonBorderRadius" className="text-bright-white">
                      Border Radius: {componentSettings.buttons.borderRadius}px
                    </Label>
                  </div>
                  <Slider
                    id="buttonBorderRadius"
                    min={0}
                    max={24}
                    step={1}
                    value={[componentSettings.buttons.borderRadius]}
                    onValueChange={(value) => handleButtonChange("borderRadius", value[0])}
                    className="data-[state=active]:bg-bright-yellow"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="buttonPaddingX" className="text-bright-white">
                        Padding X: {componentSettings.buttons.paddingX}px
                      </Label>
                    </div>
                    <Slider
                      id="buttonPaddingX"
                      min={4}
                      max={32}
                      step={1}
                      value={[componentSettings.buttons.paddingX]}
                      onValueChange={(value) => handleButtonChange("paddingX", value[0])}
                      className="data-[state=active]:bg-bright-yellow"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <Label htmlFor="buttonPaddingY" className="text-bright-white">
                        Padding Y: {componentSettings.buttons.paddingY}px
                      </Label>
                    </div>
                    <Slider
                      id="buttonPaddingY"
                      min={2}
                      max={20}
                      step={1}
                      value={[componentSettings.buttons.paddingY]}
                      onValueChange={(value) => handleButtonChange("paddingY", value[0])}
                      className="data-[state=active]:bg-bright-yellow"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="buttonFontSize" className="text-bright-white">
                      Font Size: {componentSettings.buttons.fontSize}px
                    </Label>
                  </div>
                  <Slider
                    id="buttonFontSize"
                    min={10}
                    max={20}
                    step={1}
                    value={[componentSettings.buttons.fontSize]}
                    onValueChange={(value) => handleButtonChange("fontSize", value[0])}
                    className="data-[state=active]:bg-bright-yellow"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="buttonPrimaryColor" className="text-bright-white">
                      Primary Color
                    </Label>
                    <div className="flex gap-2">
                      <div
                        className="w-10 h-10 rounded border border-bright-white/20"
                        style={{ backgroundColor: componentSettings.buttons.primaryColor }}
                      />
                      <Input
                        id="buttonPrimaryColor"
                        value={componentSettings.buttons.primaryColor}
                        onChange={(e) => handleButtonChange("primaryColor", e.target.value)}
                        className="bg-bright-black/30 border-bright-yellow/20 text-bright-white font-mono"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="buttonSecondaryColor" className="text-bright-white">
                      Secondary Color
                    </Label>
                    <div className="flex gap-2">
                      <div
                        className="w-10 h-10 rounded border border-bright-white/20"
                        style={{ backgroundColor: componentSettings.buttons.secondaryColor }}
                      />
                      <Input
                        id="buttonSecondaryColor"
                        value={componentSettings.buttons.secondaryColor}
                        onChange={(e) => handleButtonChange("secondaryColor", e.target.value)}
                        className="bg-bright-black/30 border-bright-yellow/20 text-bright-white font-mono"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="buttonOutlineWidth" className="text-bright-white">
                      Outline Width: {componentSettings.buttons.outlineWidth}px
                    </Label>
                  </div>
                  <Slider
                    id="buttonOutlineWidth"
                    min={0}
                    max={4}
                    step={1}
                    value={[componentSettings.buttons.outlineWidth]}
                    onValueChange={(value) => handleButtonChange("outlineWidth", value[0])}
                    className="data-[state=active]:bg-bright-yellow"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="buttonAnimation" className="text-bright-white">
                    Enable Animation
                  </Label>
                  <Switch
                    id="buttonAnimation"
                    checked={componentSettings.buttons.animation}
                    onCheckedChange={(checked) => handleButtonChange("animation", checked)}
                    className="data-[state=checked]:bg-bright-yellow"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-bright-white">Button Preview</CardTitle>
                <CardDescription>See how your buttons will look</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-6 bg-bright-black/30 rounded-md border border-bright-yellow/10 flex flex-col items-center gap-4">
                  <div className="flex gap-4">
                    <button
                      style={{
                        backgroundColor: componentSettings.buttons.primaryColor,
                        color: componentSettings.buttons.secondaryColor,
                        borderRadius: `${componentSettings.buttons.borderRadius}px`,
                        padding: `${componentSettings.buttons.paddingY}px ${componentSettings.buttons.paddingX}px`,
                        fontSize: `${componentSettings.buttons.fontSize}px`,
                        transition: componentSettings.buttons.animation ? "all 0.3s ease" : "none",
                      }}
                      className="font-medium"
                    >
                      Primary Button
                    </button>

                    <button
                      style={{
                        backgroundColor: "transparent",
                        color: componentSettings.buttons.primaryColor,
                        borderRadius: `${componentSettings.buttons.borderRadius}px`,
                        padding: `${componentSettings.buttons.paddingY}px ${componentSettings.buttons.paddingX}px`,
                        fontSize: `${componentSettings.buttons.fontSize}px`,
                        border: `${componentSettings.buttons.outlineWidth}px solid ${componentSettings.buttons.primaryColor}`,
                        transition: componentSettings.buttons.animation ? "all 0.3s ease" : "none",
                      }}
                      className="font-medium"
                    >
                      Secondary Button
                    </button>
                  </div>

                  <div className="flex gap-4">
                    <button
                      style={{
                        backgroundColor: componentSettings.buttons.primaryColor,
                        color: componentSettings.buttons.secondaryColor,
                        borderRadius: `${componentSettings.buttons.borderRadius}px`,
                        padding: `${componentSettings.buttons.paddingY - 2}px ${componentSettings.buttons.paddingX - 4}px`,
                        fontSize: `${componentSettings.buttons.fontSize - 2}px`,
                        transition: componentSettings.buttons.animation ? "all 0.3s ease" : "none",
                      }}
                      className="font-medium"
                    >
                      Small Button
                    </button>

                    <button
                      style={{
                        backgroundColor: componentSettings.buttons.primaryColor,
                        color: componentSettings.buttons.secondaryColor,
                        borderRadius: `${componentSettings.buttons.borderRadius}px`,
                        padding: `${componentSettings.buttons.paddingY + 4}px ${componentSettings.buttons.paddingX + 8}px`,
                        fontSize: `${componentSettings.buttons.fontSize + 2}px`,
                        transition: componentSettings.buttons.animation ? "all 0.3s ease" : "none",
                      }}
                      className="font-medium"
                    >
                      Large Button
                    </button>
                  </div>

                  <button
                    style={{
                      backgroundColor: "transparent",
                      color: componentSettings.buttons.primaryColor,
                      borderRadius: `${componentSettings.buttons.borderRadius}px`,
                      padding: `${componentSettings.buttons.paddingY}px ${componentSettings.buttons.paddingX}px`,
                      fontSize: `${componentSettings.buttons.fontSize}px`,
                      transition: componentSettings.buttons.animation ? "all 0.3s ease" : "none",
                    }}
                    className="font-medium"
                  >
                    Text Button
                  </button>

                  <button
                    style={{
                      backgroundColor: "#6E6E6E",
                      color: "#FFFFFF",
                      borderRadius: `${componentSettings.buttons.borderRadius}px`,
                      padding: `${componentSettings.buttons.paddingY}px ${componentSettings.buttons.paddingX}px`,
                      fontSize: `${componentSettings.buttons.fontSize}px`,
                      opacity: 0.6,
                      cursor: "not-allowed",
                      transition: componentSettings.buttons.animation ? "all 0.3s ease" : "none",
                    }}
                    className="font-medium"
                    disabled
                  >
                    Disabled Button
                  </button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Cards Tab */}
        <TabsContent value="cards" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-bright-white">Card Appearance</CardTitle>
                <CardDescription>Customize the appearance of cards</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="cardBorderRadius" className="text-bright-white">
                      Border Radius: {componentSettings.cards.borderRadius}px
                    </Label>
                  </div>
                  <Slider
                    id="cardBorderRadius"
                    min={0}
                    max={24}
                    step={1}
                    value={[componentSettings.cards.borderRadius]}
                    onValueChange={(value) => handleCardChange("borderRadius", value[0])}
                    className="data-[state=active]:bg-bright-yellow"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="cardBorderWidth" className="text-bright-white">
                      Border Width: {componentSettings.cards.borderWidth}px
                    </Label>
                  </div>
                  <Slider
                    id="cardBorderWidth"
                    min={0}
                    max={4}
                    step={1}
                    value={[componentSettings.cards.borderWidth]}
                    onValueChange={(value) => handleCardChange("borderWidth", value[0])}
                    className="data-[state=active]:bg-bright-yellow"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cardBorderColor" className="text-bright-white">
                    Border Color
                  </Label>
                  <div className="flex gap-2">
                    <div
                      className="w-10 h-10 rounded border border-bright-white/20"
                      style={{ backgroundColor: componentSettings.cards.borderColor }}
                    />
                    <Input
                      id="cardBorderColor"
                      value={componentSettings.cards.borderColor}
                      onChange={(e) => handleCardChange("borderColor", e.target.value)}
                      className="bg-bright-black/30 border-bright-yellow/20 text-bright-white font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="cardBackgroundColor" className="text-bright-white">
                    Background Color
                  </Label>
                  <div className="flex gap-2">
                    <div
                      className="w-10 h-10 rounded border border-bright-white/20"
                      style={{ backgroundColor: componentSettings.cards.backgroundColor }}
                    />
                    <Input
                      id="cardBackgroundColor"
                      value={componentSettings.cards.backgroundColor}
                      onChange={(e) => handleCardChange("backgroundColor", e.target.value)}
                      className="bg-bright-black/30 border-bright-yellow/20 text-bright-white font-mono"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="cardBackdropBlur" className="text-bright-white">
                    Backdrop Blur
                  </Label>
                  <Switch
                    id="cardBackdropBlur"
                    checked={componentSettings.cards.backdropBlur}
                    onCheckedChange={(checked) => handleCardChange("backdropBlur", checked)}
                    className="data-[state=checked]:bg-bright-yellow"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-bright-white">Card Preview</CardTitle>
                <CardDescription>See how your cards will look</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-6 bg-bright-black/30 rounded-md border border-bright-yellow/10">
                  <div
                    style={{
                      borderRadius: `${componentSettings.cards.borderRadius}px`,
                      borderWidth: `${componentSettings.cards.borderWidth}px`,
                      borderStyle: "solid",
                      borderColor: componentSettings.cards.borderColor,
                      backgroundColor: componentSettings.cards.backgroundColor,
                      backdropFilter: componentSettings.cards.backdropBlur ? "blur(10px)" : "none",
                      padding: "24px",
                    }}
                    className="overflow-hidden"
                  >
                    <h3 className="text-xl font-semibold text-bright-white mb-2">Card Title</h3>
                    <p className="text-bright-white/70 mb-4">
                      This is a preview of how your cards will look with the current settings. You can customize the
                      appearance to match your design preferences.
                    </p>
                    <button
                      style={{
                        backgroundColor: componentSettings.buttons.primaryColor,
                        color: componentSettings.buttons.secondaryColor,
                        borderRadius: `${componentSettings.buttons.borderRadius}px`,
                        padding: `${componentSettings.buttons.paddingY}px ${componentSettings.buttons.paddingX}px`,
                        fontSize: `${componentSettings.buttons.fontSize}px`,
                      }}
                      className="font-medium"
                    >
                      Card Button
                    </button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Inputs Tab */}
        <TabsContent value="inputs" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-bright-white">Input Appearance</CardTitle>
                <CardDescription>Customize the appearance of input fields</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="inputBorderRadius" className="text-bright-white">
                      Border Radius: {componentSettings.inputs.borderRadius}px
                    </Label>
                  </div>
                  <Slider
                    id="inputBorderRadius"
                    min={0}
                    max={20}
                    step={1}
                    value={[componentSettings.inputs.borderRadius]}
                    onValueChange={(value) => handleInputChange("borderRadius", value[0])}
                    className="data-[state=active]:bg-bright-yellow"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="inputBorderWidth" className="text-bright-white">
                      Border Width: {componentSettings.inputs.borderWidth}px
                    </Label>
                  </div>
                  <Slider
                    id="inputBorderWidth"
                    min={0}
                    max={4}
                    step={1}
                    value={[componentSettings.inputs.borderWidth]}
                    onValueChange={(value) => handleInputChange("borderWidth", value[0])}
                    className="data-[state=active]:bg-bright-yellow"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="inputBorderColor" className="text-bright-white">
                    Border Color
                  </Label>
                  <div className="flex gap-2">
                    <div
                      className="w-10 h-10 rounded border border-bright-white/20"
                      style={{ backgroundColor: componentSettings.inputs.borderColor }}
                    />
                    <Input
                      id="inputBorderColor"
                      value={componentSettings.inputs.borderColor}
                      onChange={(e) => handleInputChange("borderColor", e.target.value)}
                      className="bg-bright-black/30 border-bright-yellow/20 text-bright-white font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="inputBackgroundColor" className="text-bright-white">
                    Background Color
                  </Label>
                  <div className="flex gap-2">
                    <div
                      className="w-10 h-10 rounded border border-bright-white/20"
                      style={{ backgroundColor: componentSettings.inputs.backgroundColor }}
                    />
                    <Input
                      id="inputBackgroundColor"
                      value={componentSettings.inputs.backgroundColor}
                      onChange={(e) => handleInputChange("backgroundColor", e.target.value)}
                      className="bg-bright-black/30 border-bright-yellow/20 text-bright-white font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="inputFocusRingWidth" className="text-bright-white">
                      Focus Ring Width: {componentSettings.inputs.focusRingWidth}px
                    </Label>
                  </div>
                  <Slider
                    id="inputFocusRingWidth"
                    min={0}
                    max={4}
                    step={1}
                    value={[componentSettings.inputs.focusRingWidth]}
                    onValueChange={(value) => handleInputChange("focusRingWidth", value[0])}
                    className="data-[state=active]:bg-bright-yellow"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-bright-white">Input Preview</CardTitle>
                <CardDescription>See how your input fields will look</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-6 bg-bright-black/30 rounded-md border border-bright-yellow/10 space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="previewInput" className="text-bright-white">
                      Text Input
                    </Label>
                    <input
                      id="previewInput"
                      placeholder="Enter text here..."
                      style={{
                        borderRadius: `${componentSettings.inputs.borderRadius}px`,
                        borderWidth: `${componentSettings.inputs.borderWidth}px`,
                        borderStyle: "solid",
                        borderColor: componentSettings.inputs.borderColor,
                        backgroundColor: componentSettings.inputs.backgroundColor,
                        color: componentSettings.inputs.textColor,
                        padding: "8px 12px",
                        width: "100%",
                        outline: "none",
                      }}
                      className="placeholder:text-bright-white/50 focus:ring-2 focus:ring-bright-yellow/50"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="previewTextarea" className="text-bright-white">
                      Textarea
                    </Label>
                    <textarea
                      id="previewTextarea"
                      placeholder="Enter multiple lines of text..."
                      rows={3}
                      style={{
                        borderRadius: `${componentSettings.inputs.borderRadius}px`,
                        borderWidth: `${componentSettings.inputs.borderWidth}px`,
                        borderStyle: "solid",
                        borderColor: componentSettings.inputs.borderColor,
                        backgroundColor: componentSettings.inputs.backgroundColor,
                        color: componentSettings.inputs.textColor,
                        padding: "8px 12px",
                        width: "100%",
                        outline: "none",
                      }}
                      className="placeholder:text-bright-white/50 focus:ring-2 focus:ring-bright-yellow/50"
                    ></textarea>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="previewSelect" className="text-bright-white">
                      Select
                    </Label>
                    <select
                      id="previewSelect"
                      style={{
                        borderRadius: `${componentSettings.inputs.borderRadius}px`,
                        borderWidth: `${componentSettings.inputs.borderWidth}px`,
                        borderStyle: "solid",
                        borderColor: componentSettings.inputs.borderColor,
                        backgroundColor: componentSettings.inputs.backgroundColor,
                        color: componentSettings.inputs.textColor,
                        padding: "8px 12px",
                        width: "100%",
                        outline: "none",
                      }}
                      className="focus:ring-2 focus:ring-bright-yellow/50"
                    >
                      <option value="">Select an option</option>
                      <option value="option1">Option 1</option>
                      <option value="option2">Option 2</option>
                      <option value="option3">Option 3</option>
                    </select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Navigation Tab */}
        <TabsContent value="navigation" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-bright-white">Navigation Appearance</CardTitle>
                <CardDescription>Customize the appearance of navigation elements</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="navStyle" className="text-bright-white">
                    Navigation Style
                  </Label>
                  <Select
                    value={componentSettings.navigation.style}
                    onValueChange={(value) => handleNavigationChange("style", value)}
                  >
                    <SelectTrigger
                      id="navStyle"
                      className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                    >
                      <SelectValue placeholder="Select style" />
                    </SelectTrigger>
                    <SelectContent className="bg-bright-black border-bright-yellow/20">
                      <SelectItem value="floating" className="text-bright-white">
                        Floating
                      </SelectItem>
                      <SelectItem value="fixed" className="text-bright-white">
                        Fixed
                      </SelectItem>
                      <SelectItem value="sticky" className="text-bright-white">
                        Sticky
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label htmlFor="navTransparency" className="text-bright-white">
                      Transparency: {componentSettings.navigation.transparency.toFixed(1)}
                    </Label>
                  </div>
                  <Slider
                    id="navTransparency"
                    min={0}
                    max={1}
                    step={0.1}
                    value={[componentSettings.navigation.transparency]}
                    onValueChange={(value) => handleNavigationChange("transparency", value[0])}
                    className="data-[state=active]:bg-bright-yellow"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="navBlurEffect" className="text-bright-white">
                    Blur Effect
                  </Label>
                  <Switch
                    id="navBlurEffect"
                    checked={componentSettings.navigation.blurEffect}
                    onCheckedChange={(checked) => handleNavigationChange("blurEffect", checked)}
                    className="data-[state=checked]:bg-bright-yellow"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="navBorderBottom" className="text-bright-white">
                    Border Bottom
                  </Label>
                  <Switch
                    id="navBorderBottom"
                    checked={componentSettings.navigation.borderBottom}
                    onCheckedChange={(checked) => handleNavigationChange("borderBottom", checked)}
                    className="data-[state=checked]:bg-bright-yellow"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="navBorderColor" className="text-bright-white">
                    Border Color
                  </Label>
                  <div className="flex gap-2">
                    <div
                      className="w-10 h-10 rounded border border-bright-white/20"
                      style={{ backgroundColor: componentSettings.navigation.borderColor }}
                    />
                    <Input
                      id="navBorderColor"
                      value={componentSettings.navigation.borderColor}
                      onChange={(e) => handleNavigationChange("borderColor", e.target.value)}
                      className="bg-bright-black/30 border-bright-yellow/20 text-bright-white font-mono"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="navDropdownStyle" className="text-bright-white">
                    Dropdown Style
                  </Label>
                  <Select
                    value={componentSettings.navigation.dropdownStyle}
                    onValueChange={(value) => handleNavigationChange("dropdownStyle", value)}
                  >
                    <SelectTrigger
                      id="navDropdownStyle"
                      className="bg-bright-black/30 border-bright-yellow/20 text-bright-white"
                    >
                      <SelectValue placeholder="Select style" />
                    </SelectTrigger>
                    <SelectContent className="bg-bright-black border-bright-yellow/20">
                      <SelectItem value="fade" className="text-bright-white">
                        Fade
                      </SelectItem>
                      <SelectItem value="slide" className="text-bright-white">
                        Slide
                      </SelectItem>
                      <SelectItem value="scale" className="text-bright-white">
                        Scale
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card className="border-bright-yellow/10 bg-bright-black/50 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-bright-white">Navigation Preview</CardTitle>
                <CardDescription>See how your navigation will look</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="p-6 bg-bright-black/30 rounded-md border border-bright-yellow/10">
                  <div
                    style={{
                      backgroundColor: `rgba(17, 17, 17, ${componentSettings.navigation.transparency})`,
                      backdropFilter: componentSettings.navigation.blurEffect ? "blur(10px)" : "none",
                      borderBottom: componentSettings.navigation.borderBottom
                        ? `1px solid ${componentSettings.navigation.borderColor}`
                        : "none",
                      padding: "16px",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                    className="rounded-t-lg"
                  >
                    <div className="flex items-center">
                      <div className="w-8 h-8 bg-bright-yellow rounded-full mr-2"></div>
                      <span className="font-bold text-bright-white">LOGO</span>
                    </div>

                    <div className="hidden sm:flex space-x-4">
                      <span className="text-bright-white">Home</span>
                      <span className="text-bright-white">About</span>
                      <span className="text-bright-yellow">Services</span>
                      <span className="text-bright-white">Contact</span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        style={{
                          backgroundColor: componentSettings.buttons.primaryColor,
                          color: componentSettings.buttons.secondaryColor,
                          borderRadius: `${componentSettings.buttons.borderRadius}px`,
                          padding: `${componentSettings.buttons.paddingY - 2}px ${componentSettings.buttons.paddingX - 4}px`,
                          fontSize: `${componentSettings.buttons.fontSize - 2}px`,
                        }}
                        className="font-medium"
                      >
                        Login
                      </button>
                      <div className="sm:hidden">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          className="text-bright-white"
                        >
                          <line x1="4" x2="20" y1="12" y2="12" />
                          <line x1="4" x2="20" y1="6" y2="6" />
                          <line x1="4" x2="20" y1="18" y2="18" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  <div className="bg-bright-black/50 p-4 rounded-b-lg">
                    <p className="text-bright-white/70 text-sm">
                      This is a preview of how your navigation will look with the current settings.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
