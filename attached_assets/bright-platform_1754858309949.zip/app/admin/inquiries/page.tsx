"use client"

import { useState } from "react"
import { Search, Filter, MoreHorizontal, Mail, Check, X, MessageSquare, ArrowUpDown } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

// Sample inquiries data
const inquiries = [
  {
    id: 1,
    name: "John Smith",
    email: "john@example.com",
    subject: "Real Estate VR Tour Inquiry",
    message:
      "I'm interested in creating virtual tours for my real estate listings. Can you provide more information about your services and pricing?",
    date: "2023-10-05 14:32:45",
    status: "new",
    service: "Real Estate",
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah@example.com",
    subject: "Architectural Visualization Quote",
    message:
      "I'm an architect looking for visualization services for an upcoming project. Please send me details about your architectural visualization services.",
    date: "2023-10-03 09:15:22",
    status: "responded",
    service: "Architecture",
  },
  {
    id: 3,
    name: "Michael Brown",
    email: "michael@example.com",
    subject: "Interior Design Visualization",
    message:
      "I need interior visualization services for a new residential project. What options do you offer for interior design visualization?",
    date: "2023-09-28 16:45:12",
    status: "closed",
    service: "Interior Design",
  },
  {
    id: 4,
    name: "Emily Davis",
    email: "emily@example.com",
    subject: "Media Production Services",
    message:
      "I'm looking for a company to help with video production for my business. Can you tell me more about your media production services?",
    date: "2023-09-25 11:30:45",
    status: "new",
    service: "Media",
  },
  {
    id: 5,
    name: "David Wilson",
    email: "david@example.com",
    subject: "Corporate Training Solutions",
    message:
      "Our company is interested in VR training solutions for our employees. Please provide information about your corporate training offerings.",
    date: "2023-09-20 10:15:33",
    status: "responded",
    service: "Training",
  },
]

export default function InquiriesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedInquiry, setSelectedInquiry] = useState<any>(null)
  const [isViewOpen, setIsViewOpen] = useState(false)
  const [isReplyOpen, setIsReplyOpen] = useState(false)
  const [replyMessage, setReplyMessage] = useState("")
  const [sortField, setSortField] = useState<string | null>(null)
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")

  // Filter inquiries based on search query
  const filteredInquiries = inquiries.filter(
    (inquiry) =>
      inquiry.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inquiry.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inquiry.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      inquiry.service.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  // Sort inquiries
  const sortedInquiries = [...filteredInquiries].sort((a, b) => {
    if (!sortField) return 0

    const aValue = a[sortField as keyof typeof a]
    const bValue = b[sortField as keyof typeof b]

    if (typeof aValue === "string" && typeof bValue === "string") {
      return sortDirection === "asc" ? aValue.localeCompare(bValue) : bValue.localeCompare(aValue)
    }

    return sortDirection === "asc" ? (aValue > bValue ? 1 : -1) : aValue < bValue ? 1 : -1
  })

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("asc")
    }
  }

  const handleViewInquiry = (inquiry: any) => {
    setSelectedInquiry(inquiry)
    setIsViewOpen(true)
  }

  const handleReplyInquiry = (inquiry: any) => {
    setSelectedInquiry(inquiry)
    setIsReplyOpen(true)
    setReplyMessage(
      `Dear ${inquiry.name},\n\nThank you for your inquiry about our ${inquiry.service} services. \n\n[Your response here]\n\nBest regards,\nThe Bright Team`,
    )
  }

  const handleSendReply = () => {
    if (!replyMessage.trim()) {
      toast({
        title: "Empty message",
        description: "Please enter a reply message.",
        variant: "destructive",
      })
      return
    }

    // Simulate sending reply
    toast({
      title: "Reply sent",
      description: `Your reply to ${selectedInquiry?.name} has been sent.`,
    })

    // Reset and close dialog
    setReplyMessage("")
    setIsReplyOpen(false)
  }

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "new":
        return "bg-green-500/20 text-green-500 hover:bg-green-500/30"
      case "responded":
        return "bg-blue-500/20 text-blue-500 hover:bg-blue-500/30"
      case "closed":
        return "bg-gray-500/20 text-gray-500 hover:bg-gray-500/30"
      default:
        return "bg-gray-500/20 text-gray-500 hover:bg-gray-500/30"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">Inquiries</h1>
          <p className="text-bright-white/70">Manage customer inquiries and messages</p>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-bright-white/50" />
          <Input
            placeholder="Search inquiries..."
            className="pl-9 bg-bright-black/30 border-bright-yellow/10 text-bright-white"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="border-bright-yellow/20 text-bright-white">
              <Filter className="h-4 w-4 mr-2" /> Filter
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-bright-black border-bright-yellow/20">
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              All Inquiries
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              New
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Responded
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Closed
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-bright-yellow/10" />
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Real Estate
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Architecture
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Media
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Training
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Inquiries Table */}
      <div className="border border-bright-yellow/10 rounded-md overflow-hidden">
        <Table>
          <TableHeader className="bg-bright-black/50">
            <TableRow className="hover:bg-bright-black/30 border-bright-yellow/10">
              <TableHead className="text-bright-white/70">
                <div className="flex items-center cursor-pointer" onClick={() => handleSort("name")}>
                  Name <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-bright-white/70">
                <div className="flex items-center cursor-pointer" onClick={() => handleSort("subject")}>
                  Subject <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-bright-white/70">
                <div className="flex items-center cursor-pointer" onClick={() => handleSort("service")}>
                  Service <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-bright-white/70">
                <div className="flex items-center cursor-pointer" onClick={() => handleSort("date")}>
                  Date <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-bright-white/70">
                <div className="flex items-center cursor-pointer" onClick={() => handleSort("status")}>
                  Status <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-right text-bright-white/70">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedInquiries.length > 0 ? (
              sortedInquiries.map((inquiry) => (
                <TableRow key={inquiry.id} className="hover:bg-bright-black/30 border-bright-yellow/10">
                  <TableCell className="font-medium text-bright-white">
                    <div>
                      <p>{inquiry.name}</p>
                      <p className="text-xs text-bright-white/50">{inquiry.email}</p>
                    </div>
                  </TableCell>
                  <TableCell className="text-bright-white">{inquiry.subject}</TableCell>
                  <TableCell className="text-bright-white">{inquiry.service}</TableCell>
                  <TableCell className="text-bright-white/70">{inquiry.date}</TableCell>
                  <TableCell>
                    <Badge className={getStatusBadgeColor(inquiry.status)}>
                      {inquiry.status.charAt(0).toUpperCase() + inquiry.status.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-bright-white/70 hover:text-bright-white"
                        onClick={() => handleViewInquiry(inquiry)}
                      >
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-bright-white/70 hover:text-bright-white"
                        onClick={() => handleReplyInquiry(inquiry)}
                      >
                        <Mail className="h-4 w-4" />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-bright-white/70 hover:text-bright-white">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-bright-black border-bright-yellow/20">
                          <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                            <Check className="h-4 w-4 mr-2" /> Mark as Responded
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                            <X className="h-4 w-4 mr-2" /> Mark as Closed
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-bright-white/50">
                  No inquiries found matching your search.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* View Inquiry Dialog */}
      <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
        <DialogContent className="bg-bright-black border-bright-yellow/20 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-bright-white">{selectedInquiry?.subject}</DialogTitle>
            <DialogDescription>
              From: {selectedInquiry?.name} ({selectedInquiry?.email})
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex justify-between text-sm text-bright-white/70">
              <div>Service: {selectedInquiry?.service}</div>
              <div>Date: {selectedInquiry?.date}</div>
            </div>
            <div className="p-4 bg-bright-black/30 rounded-md border border-bright-yellow/10 text-bright-white whitespace-pre-line">
              {selectedInquiry?.message}
            </div>
          </div>
          <DialogFooter className="flex space-x-2">
            <Button
              variant="outline"
              onClick={() => setIsViewOpen(false)}
              className="border-bright-yellow/20 text-bright-white"
            >
              Close
            </Button>
            <Button
              className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90"
              onClick={() => {
                setIsViewOpen(false)
                handleReplyInquiry(selectedInquiry)
              }}
            >
              <Mail className="h-4 w-4 mr-2" /> Reply
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reply Dialog */}
      <Dialog open={isReplyOpen} onOpenChange={setIsReplyOpen}>
        <DialogContent className="bg-bright-black border-bright-yellow/20 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-bright-white">Reply to {selectedInquiry?.name}</DialogTitle>
            <DialogDescription>Re: {selectedInquiry?.subject}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Textarea
                value={replyMessage}
                onChange={(e) => setReplyMessage(e.target.value)}
                className="bg-bright-black/30 border-bright-yellow/20 text-bright-white min-h-[200px]"
                placeholder="Type your reply here..."
              />
            </div>
          </div>
          <DialogFooter className="flex space-x-2">
            <Button
              variant="outline"
              onClick={() => setIsReplyOpen(false)}
              className="border-bright-yellow/20 text-bright-white"
            >
              Cancel
            </Button>
            <Button className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90" onClick={handleSendReply}>
              <Mail className="h-4 w-4 mr-2" /> Send Reply
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
