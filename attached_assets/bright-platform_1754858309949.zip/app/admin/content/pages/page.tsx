"use client"

import { useState } from "react"
import { Plus, Search, Filter, MoreHorizontal, Edit, Trash2, Eye, ArrowUpDown, FileText } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

// Sample data for pages
const pages = [
  {
    id: 1,
    title: "Home",
    slug: "/",
    lastUpdated: "2023-10-01",
    status: "Published",
    author: "Admin",
  },
  {
    id: 2,
    title: "About",
    slug: "/about",
    lastUpdated: "2023-09-28",
    status: "Published",
    author: "Admin",
  },
  {
    id: 3,
    title: "Contact",
    slug: "/contact",
    lastUpdated: "2023-09-25",
    status: "Published",
    author: "Admin",
  },
  {
    id: 4,
    title: "Real Estate",
    slug: "/real-estate",
    lastUpdated: "2023-09-20",
    status: "Published",
    author: "Admin",
  },
  {
    id: 5,
    title: "Architecture",
    slug: "/architecture",
    lastUpdated: "2023-09-18",
    status: "Published",
    author: "Admin",
  },
  {
    id: 6,
    title: "Interior Design",
    slug: "/interior-design",
    lastUpdated: "2023-09-15",
    status: "Published",
    author: "Admin",
  },
  {
    id: 7,
    title: "Media",
    slug: "/media",
    lastUpdated: "2023-09-10",
    status: "Published",
    author: "Admin",
  },
  {
    id: 8,
    title: "Training",
    slug: "/training",
    lastUpdated: "2023-09-05",
    status: "Published",
    author: "Admin",
  },
  {
    id: 9,
    title: "Corporate",
    slug: "/corporate",
    lastUpdated: "2023-09-01",
    status: "Published",
    author: "Admin",
  },
  {
    id: 10,
    title: "Digital",
    slug: "/digital",
    lastUpdated: "2023-08-28",
    status: "Published",
    author: "Admin",
  },
  {
    id: 11,
    title: "Custom Solutions",
    slug: "/custom",
    lastUpdated: "2023-08-25",
    status: "Published",
    author: "Admin",
  },
  {
    id: 12,
    title: "New Service Page",
    slug: "/new-service",
    lastUpdated: "2023-10-02",
    status: "Draft",
    author: "Admin",
  },
]

export default function ContentPagesPage() {
  const [searchQuery, setSearchQuery] = useState("")

  // Filter pages based on search query
  const filteredPages = pages.filter(
    (page) =>
      page.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      page.slug.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">Pages</h1>
          <p className="text-bright-white/70">Manage website pages and content</p>
        </div>

        <Button className="mt-4 sm:mt-0 bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
          <Plus className="h-4 w-4 mr-2" /> Add New Page
        </Button>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-bright-white/50" />
          <Input
            placeholder="Search pages..."
            className="pl-9 bg-bright-black/30 border-bright-yellow/10 text-bright-white"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="border-bright-yellow/20 text-bright-white">
              <Filter className="h-4 w-4 mr-2" /> Filter
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-bright-black border-bright-yellow/20">
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              All Pages
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Published
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Drafts
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Pages Table */}
      <div className="border border-bright-yellow/10 rounded-md overflow-hidden">
        <Table>
          <TableHeader className="bg-bright-black/50">
            <TableRow className="hover:bg-bright-black/30 border-bright-yellow/10">
              <TableHead className="text-bright-white/70">
                <div className="flex items-center">
                  Title <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-bright-white/70">Slug</TableHead>
              <TableHead className="text-bright-white/70">
                <div className="flex items-center">
                  Last Updated <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-bright-white/70">Status</TableHead>
              <TableHead className="text-bright-white/70">Author</TableHead>
              <TableHead className="text-right text-bright-white/70">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredPages.length > 0 ? (
              filteredPages.map((page, index) => (
                <TableRow key={page.id} className="hover:bg-bright-black/30 border-bright-yellow/10">
                  <TableCell className="font-medium text-bright-white">
                    <div className="flex items-center">
                      <FileText className="h-4 w-4 mr-2 text-bright-yellow/70" />
                      {page.title}
                    </div>
                  </TableCell>
                  <TableCell className="text-bright-white/70">{page.slug}</TableCell>
                  <TableCell className="text-bright-white/70">{page.lastUpdated}</TableCell>
                  <TableCell>
                    <Badge
                      className={
                        page.status === "Published"
                          ? "bg-green-500/20 text-green-500 hover:bg-green-500/30"
                          : "bg-yellow-500/20 text-yellow-500 hover:bg-yellow-500/30"
                      }
                    >
                      {page.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-bright-white/70">{page.author}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-bright-white/70 hover:text-bright-white">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-bright-black border-bright-yellow/20">
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Edit className="h-4 w-4 mr-2" /> Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Eye className="h-4 w-4 mr-2" /> View
                        </DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-bright-yellow/10" />
                        <DropdownMenuItem className="text-red-500 hover:text-red-600 hover:bg-red-500/10">
                          <Trash2 className="h-4 w-4 mr-2" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-bright-white/50">
                  No pages found matching your search.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
