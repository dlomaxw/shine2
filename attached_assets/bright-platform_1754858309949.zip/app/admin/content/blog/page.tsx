"use client"

import { useState } from "react"
import { Plus, Search, Filter, MoreHorizontal, Edit, Trash2, Eye, ArrowUpDown, FileText } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"

// Sample data for blog posts
const blogPosts = [
  {
    id: 1,
    title: "The Future of Virtual Reality in Real Estate Marketing",
    slug: "future-of-vr-in-real-estate",
    category: "Real Estate",
    status: "Published",
    author: "Sarah Johnson",
    publishDate: "2023-10-01",
  },
  {
    id: 2,
    title: "How Immersive Training is Revolutionizing Employee Development",
    slug: "immersive-training-employee-development",
    category: "Training",
    status: "Published",
    author: "Michael Chen",
    publishDate: "2023-09-28",
  },
  {
    id: 3,
    title: "The Rise of Virtual Production in Film and Media",
    slug: "virtual-production-film-media",
    category: "Media",
    status: "Published",
    author: "Priya Patel",
    publishDate: "2023-09-25",
  },
  {
    id: 4,
    title: "Creating Effective Virtual Collaboration Spaces for Remote Teams",
    slug: "virtual-collaboration-remote-teams",
    category: "Corporate",
    status: "Draft",
    author: "David Wilson",
    publishDate: null,
  },
  {
    id: 5,
    title: "The Psychology of Immersive Experiences: Why VR Works",
    slug: "psychology-immersive-experiences",
    category: "Research",
    status: "Published",
    author: "Emma Rodriguez",
    publishDate: "2023-09-15",
  },
  {
    id: 6,
    title: "Augmented Reality in Retail: Enhancing the Shopping Experience",
    slug: "ar-in-retail-shopping-experience",
    category: "Digital",
    status: "Draft",
    author: "James Kim",
    publishDate: null,
  },
]

export default function BlogPostsPage() {
  const [searchQuery, setSearchQuery] = useState("")

  // Filter blog posts based on search query
  const filteredPosts = blogPosts.filter(
    (post) =>
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.author.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleDeletePost = (id: number) => {
    toast({
      title: "Post deleted",
      description: "The blog post has been deleted successfully.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">Blog Posts</h1>
          <p className="text-bright-white/70">Manage your blog content</p>
        </div>

        <Button className="mt-4 sm:mt-0 bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
          <Plus className="h-4 w-4 mr-2" /> Add New Post
        </Button>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-bright-white/50" />
          <Input
            placeholder="Search posts..."
            className="pl-9 bg-bright-black/30 border-bright-yellow/10 text-bright-white"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="border-bright-yellow/20 text-bright-white">
              <Filter className="h-4 w-4 mr-2" /> Filter
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-bright-black border-bright-yellow/20">
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              All Posts
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Published
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Drafts
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-bright-yellow/10" />
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Real Estate
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Training
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Media
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Blog Posts Table */}
      <div className="border border-bright-yellow/10 rounded-md overflow-hidden">
        <Table>
          <TableHeader className="bg-bright-black/50">
            <TableRow className="hover:bg-bright-black/30 border-bright-yellow/10">
              <TableHead className="text-bright-white/70">
                <div className="flex items-center">
                  Title <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-bright-white/70">Category</TableHead>
              <TableHead className="text-bright-white/70">Author</TableHead>
              <TableHead className="text-bright-white/70">
                <div className="flex items-center">
                  Date <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-bright-white/70">Status</TableHead>
              <TableHead className="text-right text-bright-white/70">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredPosts.length > 0 ? (
              filteredPosts.map((post) => (
                <TableRow key={post.id} className="hover:bg-bright-black/30 border-bright-yellow/10">
                  <TableCell className="font-medium text-bright-white">
                    <div className="flex items-center">
                      <FileText className="h-4 w-4 mr-2 text-bright-yellow/70" />
                      {post.title}
                    </div>
                  </TableCell>
                  <TableCell className="text-bright-white/70">{post.category}</TableCell>
                  <TableCell className="text-bright-white/70">{post.author}</TableCell>
                  <TableCell className="text-bright-white/70">
                    {post.publishDate || <span className="text-bright-white/30">Draft</span>}
                  </TableCell>
                  <TableCell>
                    <Badge
                      className={
                        post.status === "Published"
                          ? "bg-green-500/20 text-green-500 hover:bg-green-500/30"
                          : "bg-yellow-500/20 text-yellow-500 hover:bg-yellow-500/30"
                      }
                    >
                      {post.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-bright-white/70 hover:text-bright-white">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-bright-black border-bright-yellow/20">
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Edit className="h-4 w-4 mr-2" /> Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Eye className="h-4 w-4 mr-2" /> View
                        </DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-bright-yellow/10" />
                        <DropdownMenuItem
                          className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                          onClick={() => handleDeletePost(post.id)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-bright-white/50">
                  No blog posts found matching your search.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
