"use client"

import { useState } from "react"
import {
  Save,
  Eye,
  ArrowLeft,
  ImageIcon,
  LinkIcon,
  List,
  ListOrdered,
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Heading1,
  Heading2,
  Heading3,
  Code,
  Undo,
  Redo,
  PanelLeft,
} from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export default function ContentEditorPage() {
  const [activeTab, setActiveTab] = useState("editor")
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [pageTitle, setPageTitle] = useState("Home Page")
  const [pageContent, setPageContent] = useState(`
# Welcome to Bright

Bright delivers seamless experiences that bridge physical spaces and digital innovation across industries.

## Our Services

- Real Estate
- Architecture
- Interior Design
- Media & Entertainment
- Training
- Corporate
- Digital
  `)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Button variant="ghost" size="icon" className="mr-2 text-bright-white/70 hover:text-bright-white">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-2xl font-bold text-bright-white">Edit Page</h1>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="outline" className="border-bright-yellow/20 text-bright-white">
            <Eye className="h-4 w-4 mr-2" /> Preview
          </Button>
          <Button className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
            <Save className="h-4 w-4 mr-2" /> Save
          </Button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Main Editor */}
        <div className={`flex-1 transition-all duration-300 ${sidebarOpen ? "lg:w-2/3" : "lg:w-full"}`}>
          <div className="space-y-4">
            <div>
              <Label htmlFor="page-title" className="text-bright-white">
                Page Title
              </Label>
              <Input
                id="page-title"
                value={pageTitle}
                onChange={(e) => setPageTitle(e.target.value)}
                className="bg-bright-black/30 border-bright-yellow/10 text-bright-white mt-1"
              />
            </div>

            <div className="border border-bright-yellow/10 rounded-md overflow-hidden">
              <div className="bg-bright-black/50 p-2 border-b border-bright-yellow/10 flex flex-wrap gap-1">
                <TooltipProvider>
                  {[
                    { icon: <Bold className="h-4 w-4" />, tooltip: "Bold" },
                    { icon: <Italic className="h-4 w-4" />, tooltip: "Italic" },
                    { icon: <Underline className="h-4 w-4" />, tooltip: "Underline" },
                    { divider: true },
                    { icon: <Heading1 className="h-4 w-4" />, tooltip: "Heading 1" },
                    { icon: <Heading2 className="h-4 w-4" />, tooltip: "Heading 2" },
                    { icon: <Heading3 className="h-4 w-4" />, tooltip: "Heading 3" },
                    { divider: true },
                    { icon: <AlignLeft className="h-4 w-4" />, tooltip: "Align Left" },
                    { icon: <AlignCenter className="h-4 w-4" />, tooltip: "Align Center" },
                    { icon: <AlignRight className="h-4 w-4" />, tooltip: "Align Right" },
                    { divider: true },
                    { icon: <List className="h-4 w-4" />, tooltip: "Bullet List" },
                    { icon: <ListOrdered className="h-4 w-4" />, tooltip: "Numbered List" },
                    { divider: true },
                    { icon: <LinkIcon className="h-4 w-4" />, tooltip: "Insert Link" },
                    { icon: <ImageIcon className="h-4 w-4" />, tooltip: "Insert Image" },
                    { icon: <Code className="h-4 w-4" />, tooltip: "Insert Code" },
                    { divider: true },
                    { icon: <Undo className="h-4 w-4" />, tooltip: "Undo" },
                    { icon: <Redo className="h-4 w-4" />, tooltip: "Redo" },
                  ].map((item, index) =>
                    item.divider ? (
                      <div key={`divider-${index}`} className="h-6 w-px bg-bright-yellow/10 mx-1" />
                    ) : (
                      <Tooltip key={index}>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-bright-white/70 hover:text-bright-white hover:bg-bright-yellow/10"
                          >
                            {item.icon}
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent className="bg-bright-black border-bright-yellow/20 text-bright-white">
                          {item.tooltip}
                        </TooltipContent>
                      </Tooltip>
                    ),
                  )}
                </TooltipProvider>

                <div className="ml-auto">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-bright-white/70 hover:text-bright-white hover:bg-bright-yellow/10 lg:hidden"
                    onClick={() => setSidebarOpen(!sidebarOpen)}
                  >
                    <PanelLeft className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <Tabs defaultValue="editor" value={activeTab} onValueChange={setActiveTab}>
                <div className="bg-bright-black/30 border-b border-bright-yellow/10 px-4">
                  <TabsList className="bg-transparent h-10">
                    <TabsTrigger
                      value="editor"
                      className="data-[state=active]:bg-transparent data-[state=active]:text-bright-yellow data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-bright-yellow rounded-none"
                    >
                      Editor
                    </TabsTrigger>
                    <TabsTrigger
                      value="preview"
                      className="data-[state=active]:bg-transparent data-[state=active]:text-bright-yellow data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-bright-yellow rounded-none"
                    >
                      Preview
                    </TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="editor" className="m-0">
                  <Textarea
                    value={pageContent}
                    onChange={(e) => setPageContent(e.target.value)}
                    className="min-h-[500px] bg-bright-black/20 border-0 rounded-none text-bright-white font-mono resize-none focus-visible:ring-0 focus-visible:ring-offset-0"
                  />
                </TabsContent>

                <TabsContent value="preview" className="m-0 p-6 min-h-[500px] bg-bright-black/20 text-bright-white">
                  <div className="prose prose-invert max-w-none">
                    <h1>Welcome to Bright</h1>
                    <p>
                      Bright delivers seamless experiences that bridge physical spaces and digital innovation across
                      industries.
                    </p>

                    <h2>Our Services</h2>
                    <ul>
                      <li>Real Estate</li>
                      <li>Architecture</li>
                      <li>Interior Design</li>
                      <li>Media & Entertainment</li>
                      <li>Training</li>
                      <li>Corporate</li>
                      <li>Digital</li>
                    </ul>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        {sidebarOpen && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="lg:w-1/3 space-y-4">
            <div className="bg-bright-black/30 border border-bright-yellow/10 rounded-md p-4">
              <h3 className="text-bright-white font-medium mb-4">Page Settings</h3>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="page-slug" className="text-bright-white">
                    URL Slug
                  </Label>
                  <Input
                    id="page-slug"
                    value="/"
                    className="bg-bright-black/30 border-bright-yellow/10 text-bright-white mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="page-template" className="text-bright-white">
                    Page Template
                  </Label>
                  <Select defaultValue="default">
                    <SelectTrigger className="bg-bright-black/30 border-bright-yellow/10 text-bright-white mt-1">
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent className="bg-bright-black border-bright-yellow/20">
                      <SelectItem value="default" className="text-bright-white">
                        Default
                      </SelectItem>
                      <SelectItem value="full-width" className="text-bright-white">
                        Full Width
                      </SelectItem>
                      <SelectItem value="sidebar" className="text-bright-white">
                        With Sidebar
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="page-status" className="text-bright-white">
                    Published
                  </Label>
                  <Switch id="page-status" defaultChecked />
                </div>
              </div>
            </div>

            <div className="bg-bright-black/30 border border-bright-yellow/10 rounded-md p-4">
              <h3 className="text-bright-white font-medium mb-4">SEO Settings</h3>

              <div className="space-y-4">
                <div>
                  <Label htmlFor="meta-title" className="text-bright-white">
                    Meta Title
                  </Label>
                  <Input
                    id="meta-title"
                    value="Home - Bright Platform"
                    className="bg-bright-black/30 border-bright-yellow/10 text-bright-white mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="meta-description" className="text-bright-white">
                    Meta Description
                  </Label>
                  <Textarea
                    id="meta-description"
                    value="Bright delivers seamless experiences that bridge physical spaces and digital innovation across industries."
                    className="bg-bright-black/30 border-bright-yellow/10 text-bright-white mt-1 resize-none h-20"
                  />
                </div>
              </div>
            </div>

            <div className="bg-bright-black/30 border border-bright-yellow/10 rounded-md p-4">
              <h3 className="text-bright-white font-medium mb-4">Featured Image</h3>

              <div className="border-2 border-dashed border-bright-yellow/20 rounded-md p-8 text-center">
                <ImageIcon className="h-10 w-10 text-bright-white/30 mx-auto mb-2" />
                <p className="text-bright-white/70 text-sm mb-4">
                  Drag and drop an image here, or click to select a file
                </p>
                <Button variant="outline" className="border-bright-yellow/20 text-bright-white">
                  Select Image
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}
