"use client"

import { useState } from "react"
import { Plus, Search, Filter, MoreHorizontal, Edit, Trash2, Eye, ArrowUpDown, Zap } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { toast } from "@/components/ui/use-toast"

// Sample data for services
const services = [
  {
    id: 1,
    name: "Virtual Property Tours",
    category: "Real Estate",
    status: "Active",
    featured: true,
    lastUpdated: "2023-10-01",
  },
  {
    id: 2,
    title: "3D Architectural Visualization",
    category: "Architecture",
    status: "Active",
    featured: true,
    lastUpdated: "2023-09-28",
  },
  {
    id: 3,
    title: "Interior Design Visualization",
    category: "Interior Design",
    status: "Active",
    featured: false,
    lastUpdated: "2023-09-25",
  },
  {
    id: 4,
    title: "VR Training Solutions",
    category: "Training",
    status: "Active",
    featured: true,
    lastUpdated: "2023-09-20",
  },
  {
    id: 5,
    title: "Media Production",
    category: "Media",
    status: "Active",
    featured: false,
    lastUpdated: "2023-09-15",
  },
  {
    id: 6,
    title: "Virtual Events",
    category: "Corporate",
    status: "Draft",
    featured: false,
    lastUpdated: "2023-09-10",
  },
  {
    id: 7,
    title: "Custom Web Development",
    category: "Digital",
    status: "Active",
    featured: false,
    lastUpdated: "2023-09-05",
  },
  {
    id: 8,
    title: "AR Applications",
    category: "Digital",
    status: "Draft",
    featured: false,
    lastUpdated: "2023-09-01",
  },
]

export default function ServicesPage() {
  const [searchQuery, setSearchQuery] = useState("")

  // Filter services based on search query
  const filteredServices = services.filter(
    (service) =>
      service.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      service.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleDeleteService = (id: number) => {
    toast({
      title: "Service deleted",
      description: "The service has been deleted successfully.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-bright-white">Services</h1>
          <p className="text-bright-white/70">Manage your service offerings</p>
        </div>

        <Button className="mt-4 sm:mt-0 bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
          <Plus className="h-4 w-4 mr-2" /> Add New Service
        </Button>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-bright-white/50" />
          <Input
            placeholder="Search services..."
            className="pl-9 bg-bright-black/30 border-bright-yellow/10 text-bright-white"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="border-bright-yellow/20 text-bright-white">
              <Filter className="h-4 w-4 mr-2" /> Filter
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="bg-bright-black border-bright-yellow/20">
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              All Services
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Active
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Drafts
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Featured
            </DropdownMenuItem>
            <DropdownMenuSeparator className="bg-bright-yellow/10" />
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Real Estate
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Architecture
            </DropdownMenuItem>
            <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
              Digital
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Services Table */}
      <div className="border border-bright-yellow/10 rounded-md overflow-hidden">
        <Table>
          <TableHeader className="bg-bright-black/50">
            <TableRow className="hover:bg-bright-black/30 border-bright-yellow/10">
              <TableHead className="text-bright-white/70">
                <div className="flex items-center">
                  Service <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-bright-white/70">Category</TableHead>
              <TableHead className="text-bright-white/70">
                <div className="flex items-center">
                  Last Updated <ArrowUpDown className="ml-1 h-3 w-3" />
                </div>
              </TableHead>
              <TableHead className="text-bright-white/70">Status</TableHead>
              <TableHead className="text-bright-white/70">Featured</TableHead>
              <TableHead className="text-right text-bright-white/70">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredServices.length > 0 ? (
              filteredServices.map((service) => (
                <TableRow key={service.id} className="hover:bg-bright-black/30 border-bright-yellow/10">
                  <TableCell className="font-medium text-bright-white">
                    <div className="flex items-center">
                      <Zap className="h-4 w-4 mr-2 text-bright-yellow/70" />
                      {service.title || service.name}
                    </div>
                  </TableCell>
                  <TableCell className="text-bright-white/70">{service.category}</TableCell>
                  <TableCell className="text-bright-white/70">{service.lastUpdated}</TableCell>
                  <TableCell>
                    <Badge
                      className={
                        service.status === "Active"
                          ? "bg-green-500/20 text-green-500 hover:bg-green-500/30"
                          : "bg-yellow-500/20 text-yellow-500 hover:bg-yellow-500/30"
                      }
                    >
                      {service.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {service.featured ? (
                      <Badge className="bg-bright-yellow/20 text-bright-yellow hover:bg-bright-yellow/30">
                        Featured
                      </Badge>
                    ) : (
                      <span className="text-bright-white/30">-</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="text-bright-white/70 hover:text-bright-white">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-bright-black border-bright-yellow/20">
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Edit className="h-4 w-4 mr-2" /> Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-bright-white hover:text-bright-yellow hover:bg-bright-yellow/10">
                          <Eye className="h-4 w-4 mr-2" /> View
                        </DropdownMenuItem>
                        <DropdownMenuSeparator className="bg-bright-yellow/10" />
                        <DropdownMenuItem
                          className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                          onClick={() => handleDeleteService(service.id)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-bright-white/50">
                  No services found matching your search.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
