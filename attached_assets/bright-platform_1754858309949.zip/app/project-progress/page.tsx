import ProjectProgressTracker from "@/components/project-progress-tracker"

export default function ProjectProgressPage() {
  return (
    <main className="min-h-screen bg-white">
      <ProjectProgressTracker />
    </main>
  )
}
