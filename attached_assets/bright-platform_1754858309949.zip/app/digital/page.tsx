import Image from "next/image"
import Link from "next/link"
import { ArrowRight, CheckCircle, Code, Globe, Smartphone, Zap } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import ContactCTA from "@/components/contact-cta"

export default function DigitalPage() {
  return (
    <main className="flex-1">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-slate-900 to-slate-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Digital Solutions Background"
            fill
            className="object-cover"
          />
        </div>
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Digital Solutions for Modern Businesses
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Custom web development, mobile applications, and interactive digital experiences that drive engagement and
              results.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-bright-yellow to-bright-yellow-dark hover:from-bright-yellow-dark hover:to-bright-yellow text-bright-black"
              >
                <Link href="/contact" className="flex items-center">
                  Start Your Project <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-white/20 hover:bg-white/10">
                <Link href="/portfolio?category=digital">View Digital Projects</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Digital Services</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Comprehensive digital solutions designed to enhance your online presence and user experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: <Globe className="h-10 w-10" />,
                title: "Web Development",
                description:
                  "Custom websites and web applications built with modern technologies and optimized for performance and user experience.",
              },
              {
                icon: <Smartphone className="h-10 w-10" />,
                title: "Mobile Applications",
                description:
                  "Native and cross-platform mobile apps that deliver seamless experiences across iOS and Android devices.",
              },
              {
                icon: <Code className="h-10 w-10" />,
                title: "E-commerce Solutions",
                description:
                  "Custom online stores and marketplaces with secure payment processing and inventory management.",
              },
              {
                icon: <Zap className="h-10 w-10" />,
                title: "Interactive Experiences",
                description:
                  "Engaging web-based interactive content, from configurators to games and educational tools.",
              },
              {
                icon: <Globe className="h-10 w-10" />,
                title: "Content Management",
                description: "Custom CMS solutions that make it easy to update and manage your digital content.",
              },
              {
                icon: <Smartphone className="h-10 w-10" />,
                title: "AR Web Applications",
                description:
                  "Web-based augmented reality experiences that work directly in the browser without app downloads.",
              },
            ].map((service, index) => (
              <Card key={index} className="border-none shadow-lg">
                <CardContent className="p-6">
                  <div className="mb-4 p-2 rounded-lg bg-bright-yellow/10 w-fit text-bright-yellow">{service.icon}</div>
                  <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-muted-foreground">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-slate-50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Development Process</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              A transparent, collaborative approach to bringing your digital vision to life.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                number: "01",
                title: "Discovery",
                description:
                  "We start by understanding your business goals, target audience, and project requirements.",
              },
              {
                number: "02",
                title: "Design",
                description:
                  "Our designers create wireframes and visual designs that align with your brand and user needs.",
              },
              {
                number: "03",
                title: "Development",
                description: "Our developers build your solution using modern technologies and best practices.",
              },
              {
                number: "04",
                title: "Deployment & Support",
                description: "We launch your project and provide ongoing support and maintenance.",
              },
            ].map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-white p-6 rounded-lg shadow-md h-full">
                  <div className="text-4xl font-bold text-bright-yellow mb-4">{step.number}</div>
                  <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </div>
                {index < 3 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                    <ArrowRight className="h-8 w-8 text-bright-yellow" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technologies Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Technologies We Use</h2>
              <p className="text-lg text-muted-foreground mb-8">
                We leverage the latest technologies and frameworks to build scalable, high-performance digital
                solutions.
              </p>

              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {[
                  "React",
                  "Next.js",
                  "Vue.js",
                  "Node.js",
                  "Python",
                  "PHP",
                  "React Native",
                  "Flutter",
                  "Swift",
                  "AWS",
                  "Google Cloud",
                  "Azure",
                  "MongoDB",
                  "PostgreSQL",
                  "Firebase",
                  "Three.js",
                  "WebGL",
                  "WebXR",
                ].map((tech, index) => (
                  <div key={index} className="flex items-center">
                    <div className="mr-2 bg-bright-yellow/10 rounded-full p-1">
                      <CheckCircle className="h-4 w-4 text-bright-yellow" />
                    </div>
                    <p>{tech}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="relative rounded-xl overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Digital Development"
                  width={800}
                  height={600}
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 w-48 h-48 rounded-lg overflow-hidden shadow-lg hidden md:block">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Mobile App Development"
                  width={200}
                  height={200}
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Case Study Preview */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-slate-50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Success Stories</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              See how our digital solutions have helped businesses achieve their goals.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "E-commerce Platform",
                description: "Custom online store increased sales by 150% in the first six months",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Mobile App",
                description: "Fitness app achieved 100,000+ downloads and 4.8-star rating",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Web Application",
                description: "SaaS platform reduced customer onboarding time by 60%",
                image: "/placeholder.svg?height=400&width=600",
              },
            ].map((caseStudy, index) => (
              <Link href={`/portfolio/case-study-${index + 1}`} key={index} className="group">
                <div className="overflow-hidden rounded-lg bg-white shadow-md transition-all duration-300 hover:shadow-xl">
                  <div className="relative h-64 w-full overflow-hidden">
                    <Image
                      src={caseStudy.image || "/placeholder.svg"}
                      alt={caseStudy.title}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2">{caseStudy.title}</h3>
                    <p className="text-muted-foreground mb-4">{caseStudy.description}</p>
                    <span className="text-sm font-medium text-bright-yellow flex items-center">
                      Read Case Study <ArrowRight className="ml-1 h-3 w-3" />
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <ContactCTA />
    </main>
  )
}
