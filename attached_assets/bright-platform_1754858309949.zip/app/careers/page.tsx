import Image from "next/image"
import Link from "next/link"
import { ArrowRight, CheckCircle, MapPin } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CareersPage() {
  // Sample job listings
  const jobListings = [
    {
      id: 1,
      title: "VR Developer",
      department: "Engineering",
      location: "Kampala, Uganda",
      type: "Full-time",
      description: "Design and develop immersive VR experiences using Unity and Unreal Engine.",
      requirements: [
        "3+ years of experience in VR/AR development",
        "Proficiency in Unity or Unreal Engine",
        "Strong C# or C++ programming skills",
        "Experience with VR hardware platforms (Oculus, HTC Vive, etc.)",
        "Portfolio demonstrating VR/AR projects",
      ],
    },
    {
      id: 2,
      title: "3D Artist",
      department: "Creative",
      location: "Kampala, Uganda",
      type: "Full-time",
      description: "Create high-quality 3D models, textures, and environments for VR/AR applications.",
      requirements: [
        "3+ years of experience in 3D modeling and texturing",
        "Proficiency in Blender, Maya, or 3ds Max",
        "Strong understanding of PBR workflows",
        "Experience with real-time rendering for games or VR",
        "Portfolio demonstrating 3D art skills",
      ],
    },
    {
      id: 3,
      title: "UX Designer",
      department: "Design",
      location: "Remote",
      type: "Full-time",
      description: "Design intuitive and engaging user experiences for immersive applications.",
      requirements: [
        "3+ years of UX design experience",
        "Experience designing for VR/AR or spatial computing",
        "Proficiency in design tools (Figma, Sketch, etc.)",
        "Understanding of human factors in immersive environments",
        "Portfolio demonstrating UX design work",
      ],
    },
    {
      id: 4,
      title: "Project Manager",
      department: "Operations",
      location: "Kampala, Uganda",
      type: "Full-time",
      description: "Lead immersive technology projects from concept to delivery, ensuring client satisfaction.",
      requirements: [
        "5+ years of project management experience",
        "Experience with immersive technology projects",
        "Strong client communication skills",
        "Familiarity with agile methodologies",
        "PMP certification preferred",
      ],
    },
    {
      id: 5,
      title: "Business Development Manager",
      department: "Sales",
      location: "Kampala, Uganda",
      type: "Full-time",
      description: "Identify and pursue new business opportunities for immersive technology solutions.",
      requirements: [
        "5+ years of sales or business development experience",
        "Understanding of immersive technology applications",
        "Strong network in relevant industries",
        "Excellent presentation and negotiation skills",
        "Track record of meeting or exceeding sales targets",
      ],
    },
    {
      id: 6,
      title: "Marketing Specialist",
      department: "Marketing",
      location: "Remote",
      type: "Full-time",
      description: "Develop and execute marketing strategies for immersive technology solutions.",
      requirements: [
        "3+ years of marketing experience",
        "Experience marketing technology products or services",
        "Strong content creation and social media skills",
        "Data-driven approach to marketing",
        "Experience with digital marketing tools and analytics",
      ],
    },
  ]

  // Departments for filter
  const departments = ["All", "Engineering", "Creative", "Design", "Operations", "Sales", "Marketing"]

  return (
    <main className="flex-1">
      <section className="relative bg-gradient-to-r from-slate-900 to-slate-800 text-white overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <Image src="/placeholder.svg?height=1080&width=1920" alt="Careers Background" fill className="object-cover" />
        </div>
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">Join Our Team</h1>
            <p className="text-xl text-gray-300 mb-8">
              Help us build the future of immersive technology and create experiences that transform how people work,
              learn, and connect.
            </p>
            <Button size="lg" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
              <a href="#open-positions" className="flex items-center">
                View Open Positions <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Why Join Us Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Join Bright?</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We're building a team of passionate innovators who are excited about the potential of immersive technology
              to transform industries.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Innovative Work",
                description:
                  "Work on cutting-edge immersive technology projects that push the boundaries of what's possible.",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Growth Opportunities",
                description:
                  "Continuous learning and development in a rapidly evolving field with clear career progression paths.",
                image: "/placeholder.svg?height=400&width=600",
              },
              {
                title: "Collaborative Culture",
                description:
                  "Join a diverse team of experts who collaborate across disciplines to solve complex challenges.",
                image: "/placeholder.svg?height=400&width=600",
              },
            ].map((benefit, index) => (
              <Card key={index} className="overflow-hidden border-none shadow-lg">
                <div className="relative h-48 w-full overflow-hidden">
                  <Image src={benefit.image || "/placeholder.svg"} alt={benefit.title} fill className="object-cover" />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-muted-foreground">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-slate-50">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Benefits</h2>
              <p className="text-lg text-muted-foreground mb-8">
                We offer a comprehensive benefits package designed to support your well-being and professional growth.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  "Competitive salary and equity options",
                  "Flexible work arrangements",
                  "Health, dental, and vision insurance",
                  "Paid time off and parental leave",
                  "Professional development budget",
                  "Latest VR/AR hardware access",
                  "Regular team events and activities",
                  "Wellness programs and gym membership",
                  "Retirement savings plan",
                  "Remote work stipend",
                ].map((benefit, index) => (
                  <div key={index} className="flex items-start">
                    <div className="mr-3 mt-1 bg-bright-yellow/10 rounded-full p-1">
                      <CheckCircle className="h-4 w-4 text-bright-yellow" />
                    </div>
                    <p>{benefit}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="relative rounded-xl overflow-hidden shadow-xl">
                <Image
                  src="/placeholder.svg?height=600&width=800"
                  alt="Team Collaboration"
                  width={800}
                  height={600}
                  className="object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 w-48 h-48 rounded-lg overflow-hidden shadow-lg hidden md:block">
                <Image
                  src="/placeholder.svg?height=200&width=200"
                  alt="Team Building"
                  width={200}
                  height={200}
                  className="object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Open Positions Section */}
      <section id="open-positions" className="py-16 px-4 md:px-6 lg:px-8">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Open Positions</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Join our team and help shape the future of immersive technology.
            </p>
          </div>

          <Tabs defaultValue="All" className="w-full">
            <div className="flex justify-center mb-8">
              <TabsList>
                {departments.map((department) => (
                  <TabsTrigger key={department} value={department}>
                    {department}
                  </TabsTrigger>
                ))}
              </TabsList>
            </div>

            {departments.map((department) => (
              <TabsContent key={department} value={department}>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {jobListings
                    .filter((job) => department === "All" || job.department === department)
                    .map((job) => (
                      <Card key={job.id} className="overflow-hidden border-none shadow-md h-full">
                        <CardContent className="p-6">
                          <div className="mb-4">
                            <h3 className="text-xl font-semibold">{job.title}</h3>
                            <div className="flex items-center text-muted-foreground mt-1">
                              <MapPin className="h-4 w-4 mr-1" />
                              <span>{job.location}</span>
                              <span className="mx-2">•</span>
                              <span>{job.type}</span>
                            </div>
                          </div>
                          <p className="text-muted-foreground mb-4">{job.description}</p>
                          <h4 className="font-medium mb-2">Requirements:</h4>
                          <ul className="list-disc list-inside text-muted-foreground mb-6">
                            {job.requirements.slice(0, 3).map((req, index) => (
                              <li key={index} className="mb-1">
                                {req}
                              </li>
                            ))}
                          </ul>
                          <Link href={`/careers/${job.id}`}>
                            <Button className="w-full bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
                              View Details
                            </Button>
                          </Link>
                        </CardContent>
                      </Card>
                    ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </section>

      {/* Application Process */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-slate-50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Application Process</h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              We've designed a straightforward process to help us find the right candidates.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                number: "01",
                title: "Application",
                description: "Submit your resume and answer a few questions about your experience and interests.",
              },
              {
                number: "02",
                title: "Initial Interview",
                description: "Chat with our recruiting team about your background and why you're interested in Bright.",
              },
              {
                number: "03",
                title: "Technical Assessment",
                description: "Complete a relevant task to showcase your skills and approach to problem-solving.",
              },
              {
                number: "04",
                title: "Final Interviews",
                description: "Meet with team members and leadership to discuss the role in depth.",
              },
            ].map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-white p-6 rounded-lg shadow-md h-full">
                  <div className="text-4xl font-bold text-bright-yellow mb-4">{step.number}</div>
                  <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </div>
                {index < 3 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                    <ArrowRight className="h-8 w-8 text-bright-yellow" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 md:px-6 lg:px-8 bg-bright-black text-bright-white">
        <div className="container mx-auto">
          <div className="text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-bright-yellow">Don't See the Right Fit?</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              We're always looking for talented individuals to join our team. Send us your resume and we'll keep you in
              mind for future opportunities.
            </p>
            <Button size="lg" className="bg-bright-yellow text-bright-black hover:bg-bright-yellow/90">
              <Link href="/contact" className="flex items-center">
                Contact Us <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </main>
  )
}
