"use client"

import type React from "react"

import { useState } from "react"
import { Check, Mail, MapPin, Phone } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

export default function ContactPage() {
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    industry: "",
    interest: "general",
    message: "",
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormState((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormState((prev) => ({ ...prev, industry: value }))
  }

  const handleRadioChange = (value: string) => {
    setFormState((prev) => ({ ...prev, interest: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    setIsSubmitting(false)
    setIsSuccess(true)
    toast({
      title: "Form submitted successfully",
      description: "We'll be in touch with you shortly.",
    })

    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSuccess(false)
      setFormState({
        name: "",
        email: "",
        phone: "",
        company: "",
        industry: "",
        interest: "general",
        message: "",
      })
    }, 3000)
  }

  return (
    <main className="flex-1">
      <section className="bg-slate-50 py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Contact Us</h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                Have a question or ready to explore how Bright can transform your business? Get in touch with our team.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-24">
        <div className="container px-4 md:px-6">
          <div className="grid gap-10 lg:grid-cols-2">
            <div>
              <h2 className="text-2xl font-bold mb-8">Get in Touch</h2>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      name="name"
                      placeholder="John Doe"
                      required
                      value={formState.name}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="john@example.com"
                      required
                      value={formState.email}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      name="phone"
                      placeholder="+1 (555) 000-0000"
                      value={formState.phone}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="company">Company</Label>
                    <Input
                      id="company"
                      name="company"
                      placeholder="Acme Inc."
                      value={formState.company}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="industry">Industry</Label>
                  <Select value={formState.industry} onValueChange={handleSelectChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select an industry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="real-estate">Real Estate</SelectItem>
                      <SelectItem value="media">Media & Entertainment</SelectItem>
                      <SelectItem value="education">Education & Training</SelectItem>
                      <SelectItem value="corporate">Corporate</SelectItem>
                      <SelectItem value="retail">Retail</SelectItem>
                      <SelectItem value="healthcare">Healthcare</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>I'm interested in:</Label>
                  <RadioGroup
                    defaultValue="general"
                    value={formState.interest}
                    onValueChange={handleRadioChange}
                    className="grid gap-2 sm:grid-cols-2"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="vr-solutions" id="vr-solutions" />
                      <Label htmlFor="vr-solutions">VR Solutions</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="media-production" id="media-production" />
                      <Label htmlFor="media-production">Media Production</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="training" id="training" />
                      <Label htmlFor="training">Training Solutions</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="general" id="general" />
                      <Label htmlFor="general">General Inquiry</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">Message</Label>
                  <Textarea
                    id="message"
                    name="message"
                    placeholder="Tell us about your project or inquiry..."
                    className="min-h-[120px]"
                    value={formState.message}
                    onChange={handleChange}
                  />
                </div>

                <Button type="submit" className="w-full" disabled={isSubmitting || isSuccess}>
                  {isSubmitting ? (
                    "Submitting..."
                  ) : isSuccess ? (
                    <span className="flex items-center">
                      <Check className="mr-2 h-4 w-4" /> Submitted
                    </span>
                  ) : (
                    "Submit"
                  )}
                </Button>
              </form>
            </div>

            <div>
              <h2 className="text-2xl font-bold mb-8">Contact Information</h2>

              <div className="grid gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <MapPin className="h-6 w-6 text-primary mt-1" />
                      <div>
                        <h3 className="font-medium">Our Location</h3>
                        <address className="not-italic text-muted-foreground mt-1">
                          1St Floor Shop 4, The Square, Plot 10 Third St
                          <br />
                          Kampala, Uganda
                        </address>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <Mail className="h-6 w-6 text-primary mt-1" />
                      <div>
                        <h3 className="font-medium">Email Us</h3>
                        <p className="text-muted-foreground mt-1">
                          <a href="mailto:brightthoughtsservices@gmail.com" className="hover:underline">
                            brightthoughtsservices@gmail.com
                          </a>
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <Phone className="h-6 w-6 text-primary mt-1" />
                      <div>
                        <h3 className="font-medium">Call Us</h3>
                        <p className="text-muted-foreground mt-1">
                          <a href="tel:+256750421224" className="hover:underline">
                            +256 750 421 224
                          </a>
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="rounded-lg overflow-hidden h-[300px] relative">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3989.7573969501847!2d32.58345937469566!3d0.31355179973882!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x177dbb8080b39c11%3A0x1f66b9b8d9e5e0d!2sThe%20Square%2C%20Plot%2010%20Third%20Street%2C%20Industrial%20Area%2C%20Kampala!5e0!3m2!1sen!2sug!4v1712151287889!5m2!1sen!2sug"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    title="Map"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
